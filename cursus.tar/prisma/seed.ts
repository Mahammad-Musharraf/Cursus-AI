/**
 * Cursus AI — seed script.
 * Run with: npm run db:seed   (or: bun prisma/seed.ts)
 *
 * Creates demo users (student / college / recruiter), all 14 software career
 * paths with skills & roadmaps & problems, foundation careers for younger
 * students, and sample student assessments + progress so every dashboard has
 * real data on first run.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { CAREERS, FOUNDATION_CAREERS } from "../src/lib/careers-data";

const prisma = new PrismaClient();

type StudentSeed = {
  name: string;
  email: string;
  careerSlug: string;
  collegeCodeRef: string;
  scores: Record<string, number>;
  solvedProblemSlugs?: number[];
};

const STUDENTS: StudentSeed[] = [
  {
    name: "Aarav Sharma",
    email: "student@cursus.ai",
    careerSlug: "backend-developer",
    collegeCodeRef: "NIT-DEMO",
    scores: { "Data Structures": 60, "Algorithms": 55, "DBMS": 50, "Operating Systems": 45, "System Design": 30, "Backend Development": 65 },
    solvedProblemSlugs: [0, 1, 2],
  },
  {
    name: "Priya Patel",
    email: "priya@cursus.ai",
    careerSlug: "frontend-developer",
    collegeCodeRef: "NIT-DEMO",
    scores: { "HTML & CSS": 85, "JavaScript": 80, "React": 78, "TypeScript": 70, "UI/UX Basics": 68, "Testing": 60 },
    solvedProblemSlugs: [0, 1, 2],
  },
  {
    name: "Rohan Gupta",
    email: "rohan@cursus.ai",
    careerSlug: "full-stack-developer",
    collegeCodeRef: "NIT-DEMO",
    scores: { "HTML & CSS": 40, "JavaScript": 35, "React": 30, "Node.js": 25, "Databases": 30, "Data Structures": 38 },
    solvedProblemSlugs: [0],
  },
  {
    name: "Sneha Reddy",
    email: "sneha@cursus.ai",
    careerSlug: "data-scientist",
    collegeCodeRef: "NIT-DEMO",
    scores: { "Python": 70, "Statistics": 60, "SQL": 65, "Machine Learning": 50, "Data Visualization": 55, "Linear Algebra": 58 },
    solvedProblemSlugs: [0, 1],
  },
  {
    name: "Vikram Singh",
    email: "vikram@cursus.ai",
    careerSlug: "backend-developer",
    collegeCodeRef: "NIT-DEMO",
    scores: {},
  },
  {
    name: "Ananya Iyer",
    email: "ananya@cursus.ai",
    careerSlug: "frontend-developer",
    collegeCodeRef: "NIT-DEMO",
    scores: { "HTML & CSS": 88, "JavaScript": 82, "React": 80, "TypeScript": 72, "UI/UX Basics": 70, "Testing": 65 },
    solvedProblemSlugs: [0, 1, 2],
  },
];

async function main() {
  console.log("🌱 Seeding Cursus AI…");

  await prisma.notification.deleteMany();
  await prisma.examAttempt.deleteMany();
  await prisma.examQuestion.deleteMany();
  await prisma.exam.deleteMany();
  await prisma.jobApplication.deleteMany();
  await prisma.job.deleteMany();
  await prisma.problemAssignment.deleteMany();
  await prisma.certificate.deleteMany();
  await prisma.onboardingResult.deleteMany();
  await prisma.chatMessage.deleteMany();
  await prisma.shortlist.deleteMany();
  await prisma.problemProgress.deleteMany();
  await prisma.assessment.deleteMany();
  await prisma.problem.deleteMany();
  await prisma.career.deleteMany();
  await prisma.user.deleteMany();

  const passwordHash = await bcrypt.hash("password123", 10);

  const college = await prisma.user.create({
    data: {
      email: "college@cursus.ai",
      name: "Dr. Meera Iyer",
      passwordHash,
      role: "COLLEGE",
      collegeName: "National Institute of Technology",
      collegeCode: "NIT-DEMO",
    },
  });

  const recruiter = await prisma.user.create({
    data: {
      email: "recruiter@cursus.ai",
      name: "Karan Mehta",
      passwordHash,
      role: "RECRUITER",
      companyName: "Turing Labs",
    },
  });

  // ---- All careers (14 software paths + 2 foundation) ----
  const allCareers = [...CAREERS, ...FOUNDATION_CAREERS];
  const careerBySlug = new Map<string, string>();
  for (const c of allCareers) {
    const career = await prisma.career.create({
      data: {
        slug: c.slug,
        title: c.title,
        category: c.category,
        stages: c.stages,
        summary: c.summary,
        avgSalary: c.avgSalary,
        icon: c.icon,
        requiredSkills: c.requiredSkills as unknown as object,
        roadmap: c.roadmap as unknown as object,
      },
    });
    careerBySlug.set(c.slug, career.id);

    for (const p of c.problems) {
      await prisma.problem.create({
        data: {
          title: p.title,
          platform: p.platform,
          difficulty: p.difficulty,
          topic: p.topic,
          url: p.url,
          skillSlug: p.skillSlug,
          careerId: career.id,
        },
      });
    }
  }
  console.log(`  ✓ Created ${allCareers.length} careers with problems`);

  // ---- Students ----
  for (const s of STUDENTS) {
    const careerId = careerBySlug.get(s.careerSlug);
    if (!careerId) throw new Error(`Career not found: ${s.careerSlug}`);

    const user = await prisma.user.create({
      data: {
        email: s.email,
        name: s.name,
        passwordHash,
        role: "STUDENT",
        stage: "IN_BTECH",
        targetCareerId: careerId,
        collegeCodeRef: s.collegeCodeRef,
        streakCount: Math.floor(Math.random() * 7) + 1,
        lastActiveDate: new Date().toISOString().slice(0, 10),
      },
    });

    if (Object.keys(s.scores).length > 0) {
      await prisma.assessment.create({
        data: {
          userId: user.id,
          careerId,
          scores: s.scores as unknown as object,
        },
      });
    }

    if (s.solvedProblemSlugs?.length) {
      const problems = await prisma.problem.findMany({
        where: { careerId },
        orderBy: { title: "asc" },
      });
      for (const idx of s.solvedProblemSlugs) {
        const problem = problems[idx];
        if (problem) {
          await prisma.problemProgress.create({
            data: {
              userId: user.id,
              problemId: problem.id,
              done: true,
              completedAt: new Date(),
            },
          });
        }
      }
    }
  }

  // ---- Recruiter shortlist (demo) ----
  const priya = await prisma.user.findUnique({ where: { email: "priya@cursus.ai" } });
  const ananya = await prisma.user.findUnique({ where: { email: "ananya@cursus.ai" } });
  if (priya && ananya) {
    await prisma.shortlist.create({
      data: { recruiterId: recruiter.id, studentId: priya.id, note: "Strong frontend skills." },
    });
    await prisma.shortlist.create({
      data: { recruiterId: recruiter.id, studentId: ananya.id, note: "High readiness, fast tracker." },
    });
  }

  // ---- A sample pending certificate for the college to review ----
  const aarav = await prisma.user.findUnique({ where: { email: "student@cursus.ai" } });
  if (aarav) {
    await prisma.certificate.create({
      data: {
        userId: aarav.id,
        title: "Full Stack Web Development",
        issuer: "Coursera",
        issuedDate: "2026-08-15",
        credentialUrl: "https://coursera.org/verify/ABC123",
        filePath: "/uploads/certificates/sample.pdf",
        fileType: "pdf",
        fileSizeKb: 240,
        status: "PENDING",
      },
    });
    // Notify college
    await prisma.notification.create({
      data: {
        userId: college.id,
        type: "info",
        title: "Certificate needs review",
        body: "Aarav Sharma uploaded \"Full Stack Web Development\" from Coursera.",
        link: "/dashboard/college",
      },
    });
  }

  // ---- A sample job + exam from the recruiter ----
  const job = await prisma.job.create({
    data: {
      recruiterId: recruiter.id,
      title: "Graduate Engineer Trainee — Backend",
      description:
        "Join our backend team to build scalable APIs and microservices. You'll work on real production systems from day one.",
      location: "Bengaluru / Remote",
      jobType: "FULL_TIME",
      requiredSkills: "Data Structures,Algorithms,DBMS,Backend Development",
      minAvgScore: 50,
      packageLpa: "₹8–12 LPA",
    },
  });

  const exam = await prisma.exam.create({
    data: {
      recruiterId: recruiter.id,
      jobId: job.id,
      title: "Backend Fundamentals — Screening Test",
      description:
        "A 30-minute screening exam covering data structures, algorithms and DBMS fundamentals.",
      durationMin: 30,
      questionsToPick: 5,
      passScorePct: 60,
      isActive: true,
      questions: {
        create: [
          {
            type: "MCQ",
            prompt: "What is the time complexity of binary search on a sorted array?",
            options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
            answer: "1",
            skillSlug: "Algorithms",
            difficulty: "EASY",
            points: 1,
          },
          {
            type: "MCQ",
            prompt: "Which data structure uses FIFO ordering?",
            options: ["Stack", "Queue", "Heap", "Tree"],
            answer: "1",
            skillSlug: "Data Structures",
            difficulty: "EASY",
            points: 1,
          },
          {
            type: "MCQ",
            prompt: "In a relational database, which key uniquely identifies a row?",
            options: ["Foreign key", "Candidate key", "Primary key", "Super key"],
            answer: "2",
            skillSlug: "DBMS",
            difficulty: "EASY",
            points: 1,
          },
          {
            type: "MCQ",
            prompt: "Which HTTP method is idempotent and safe?",
            options: ["POST", "PUT", "DELETE", "GET"],
            answer: "3",
            skillSlug: "Backend Development",
            difficulty: "MEDIUM",
            points: 2,
          },
          {
            type: "MCQ",
            prompt: "What does ACID stand for in databases?",
            options: [
              "Atomicity, Consistency, Isolation, Durability",
              "Availability, Consistency, Integration, Distribution",
              "Atomicity, Caching, Isolation, Data",
              "Access, Control, Indexing, Data",
            ],
            answer: "0",
            skillSlug: "DBMS",
            difficulty: "MEDIUM",
            points: 2,
          },
          {
            type: "SHORT_ANSWER",
            prompt: "What data structure would you use to implement a LRU cache? (one word)",
            answer: "hashtable",
            skillSlug: "Data Structures",
            difficulty: "MEDIUM",
            points: 2,
          },
          {
            type: "CODING",
            prompt: "Write a function to reverse a linked list. (pseudo-code or any language)",
            answer: "PENDING_MANUAL_REVIEW",
            skillSlug: "Data Structures",
            difficulty: "HARD",
            points: 5,
          },
        ],
      },
    },
  });

  // Priya applies to the job (demo pipeline)
  if (priya) {
    await prisma.jobApplication.create({
      data: {
        jobId: job.id,
        studentId: priya.id,
        stage: "SHORTLISTED",
        coverNote: "Excited to join the backend team!",
      },
    });
  }

  console.log("✅ Seed complete.");
  console.log("   Demo logins (password: password123):");
  console.log("   • student@cursus.ai  (Student — Backend Developer track)");
  console.log("   • college@cursus.ai   (College T&P — code NIT-DEMO)");
  console.log("   • recruiter@cursus.ai (Recruiter — Turing Labs)");
  console.log(`   • ${allCareers.length} careers seeded`);
  console.log("   • 1 job + 1 exam (7 questions) + 1 application seeded");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
