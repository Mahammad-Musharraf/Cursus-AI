# Cursus AI

> Forge a clear path from campus to career.

**Cursus AI** is an AI career-to-placement platform for engineering students. It
helps students find their skill gaps, follow a personalized roadmap, practice
with curated problems, and get mentored by an AI that knows their progress —
while giving college placement cells and recruiters real, data-backed visibility
into candidate readiness.

Built with **Next.js 16 (App Router)**, **TypeScript**, **Tailwind CSS v4** +
**shadcn/ui**, **Prisma**, **NextAuth (email/password)**, and a **server-side LLM
assistant**.

---

## ✨ Features

### For Students
- **Stage & career onboarding** — After 10th / After 12th / In B.Tech → pick a
  target career (Software Engineer, Frontend, Data Scientist, Full Stack, and
  more).
- **Skill assessment** — rate your current skills (0–100) per career; saved to
  the database.
- **Skill-gap analysis** — current vs. target per skill, readiness %, and a
  visual bar chart of where you stand.
- **Personalized roadmap** — milestone-by-milestone path to placement-ready.
- **Curated practice problems** — from **LeetCode**, **GeeksforGeeks** and
  **CodeChef** (title, platform, difficulty, topic, external link) with
  **mark-as-done** saved to the DB and a live progress bar.
- **AI mentor** — a chat that reads your saved data (scores, gaps, roadmap,
  problems solved) and suggests the next step. Server-side LLM via the
  `z-ai-web-dev-sdk`, with a rule-based fallback when no API key is set.

### For College T&P
- **Batch readiness dashboard** — total / placement-ready / on-track / at-risk,
  plus an overall readiness %.
- **Skill heatmap** — average score per skill across the batch (bars colored by
  readiness band).
- **At-risk students list** — students below the threshold or without an
  assessment.
- **Detailed students table** — expandable per-skill scores.
- **CSV export** — one click, computed live from real student records.

### For Recruiters
- **Candidate discovery** — filter by name/email, minimum average score, stage,
  and sort (avg / name / recent). Candidates are ranked by verified skill
  scores.
- **Shortlist** — save/remove candidates (persisted to the DB) with optional
  notes.
- **Shortlist view** — your saved candidates with full skill breakdowns.

---

## 🧱 Tech Stack

| Area | Choice |
| --- | --- |
| Framework | Next.js 16 (App Router) + TypeScript 5 |
| Styling | Tailwind CSS v4 + shadcn/ui (New York) |
| Database | Prisma ORM (SQLite for local dev; **PostgreSQL** for Vercel) |
| Auth | NextAuth.js v4 (email/password credentials, JWT sessions) |
| Password hashing | bcryptjs |
| Charts | Recharts |
| AI | `z-ai-web-dev-sdk` (server-side) with rule-based fallback |
| Validation | Zod |

### Design
- White + soft-neutral background with a **single deep-blue accent**.
- **Inter** font, generous spacing, consistent cards.
- Simple top navbar + role sidebar, clear page titles.
- Helpful **loading / empty / error** states everywhere.
- One obvious primary button per screen.
- Responsive (mobile-first) with a sticky footer on public pages.

---

## 🚀 Local setup

> Requires Node 18+ (and optionally Bun). The app runs on port 3000.

```bash
# 1. Install dependencies
npm install        # or: bun install

# 2. Configure environment
cp .env.example .env
#   - For local dev, DATABASE_URL is already a SQLite file path — no extra setup.
#   - Set NEXTAUTH_SECRET (any long random string).
#   - (Optional) Set ZAI_API_KEY to enable the full AI mentor. If unset, the
#     mentor runs in "guidance mode" with rule-based advice so the app keeps working.

# 3. Create the database & generate the Prisma client
npx prisma db push

# 4. Seed demo data (users, careers, problems, assessments, shortlists)
npm run db:seed      # or: npx prisma db seed

# 5. Start the dev server
npm run dev          # or: bun run dev
```

Open <http://localhost:3000>.

### Demo accounts (password: `password123`)

| Role | Email | Notes |
| --- | --- | --- |
| Student | `student@cursus.ai` | Onboarded (B.Tech → Software Engineer), has assessment + progress |
| College T&P | `college@cursus.ai` | College code `NIT-DEMO` — 6 students in batch |
| Recruiter | `recruiter@cursus.ai` | Turing Labs — 2 demo shortlists |

Students join a college's batch by entering the college's **join code** at signup.

---

## ☁️ Deploy to Vercel (PostgreSQL on Neon / Supabase)

The Prisma schema is written to be **portable** — it uses no SQLite-specific
features, so switching to PostgreSQL is a one-line change.

1. **Create a Postgres database** on [Neon](https://neon.tech) or
   [Supabase](https://supabase.com) and copy the connection string.

2. **Switch the Prisma provider** to PostgreSQL in `prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "postgresql"   // was "sqlite"
     url      = env("DATABASE_URL")
   }
   ```

3. **Set environment variables** in Vercel (Project → Settings → Environment Variables):
   ```
   DATABASE_URL="postgresql://user:password@host/db?sslmode=require"
   NEXTAUTH_SECRET="<long-random-string>"
   NEXTAUTH_URL="https://your-app.vercel.app"
   ZAI_API_KEY="<optional, enables full AI mentor>"
   ```
   (`ZAI_API_KEY` is optional — the mentor falls back to rule-based advice if unset.)

4. **Run migrations** against the new database (locally, with the production
   `DATABASE_URL` set, or via a one-off Vercel command):
   ```bash
   npx prisma migrate deploy
   npx prisma db seed
   ```
   An initial migration is included at `prisma/migrations/0001_init/migration.sql`.

5. **Deploy** on Vercel. The build uses `next build` (standalone output).

> For local dev you can keep SQLite (`provider = "sqlite"`) and use
> `npx prisma db push`. Use `prisma migrate deploy` only against your
> production Postgres database.

---

## 🗂️ Project structure

```
prisma/
  schema.prisma          # portable schema (sqlite dev / postgres prod)
  migrations/0001_init/  # baseline migration for production
  seed.ts                # demo users, careers, problems, assessments

src/
  app/
    page.tsx             # marketing landing page
    login/ signup/       # auth pages
    onboarding/          # student stage → career flow
    dashboard/
      layout.tsx         # AppShell (navbar + sidebar) + auth gate
      student/           # dashboard, assessment, skill-gap, roadmap, problems, ai-chat
      college/           # dashboard, students, export, settings
      recruiter/         # candidates, shortlist, settings
    api/
      auth/               # NextAuth + signup
      careers/ onboarding/
      assessment/ student/summary/ problems/ progress/ ai-chat/
      college/            # dashboard, students, export (CSV)
      recruiter/          # candidates, shortlist
  components/
    app-shell.tsx navbar.tsx role-sidebar.tsx   # dashboard chrome
    public-header.tsx site-footer.tsx          # public chrome
    page-header.tsx states.tsx stat-card.tsx   # shared UI
    ui/                                         # shadcn/ui components
  lib/
    auth.ts session.ts middleware              # NextAuth + role gates
    ai.ts                                     # server-side LLM + fallback
    student-stats.ts                          # skill-gap & aggregates
    constants.ts api.ts db.ts                  # enums, fetch helper, prisma
```

### Data model (Prisma)
- `User` — email/password, role (STUDENT/COLLEGE/RECRUITER), college code,
  company name, student stage + target career.
- `Career` — title, stages, required skills (JSON), roadmap (JSON).
- `Assessment` — a student's skill scores snapshot per career.
- `Problem` — curated problem (platform, difficulty, topic, url, skillSlug).
- `ProblemProgress` — mark-as-done (unique per user/problem).
- `Shortlist` — recruiter ↔ student (with optional note).
- `ChatMessage` — AI mentor conversation history.

---

## 🔌 Environment variables

| Var | Required | Description |
| --- | --- | --- |
| `DATABASE_URL` | yes | SQLite file path (dev) or Postgres URL (prod) |
| `NEXTAUTH_SECRET` | yes | Used to sign the session JWT |
| `NEXTAUTH_URL` | yes (prod) | App URL (`http://localhost:3000` locally) |
| `ZAI_API_KEY` | no | Enables the full LLM mentor. If unset, rule-based fallback. |

See [`.env.example`](./.env.example).

---

## 🛡️ Backend rules (how the app is wired)

- Every form, button and chart reads from / writes to the **real database**
  through validated, **auth-protected** API routes.
- **No hardcoded mock data** in working flows — only the seed script provides
  demo data.
- All mutating endpoints validate input with **Zod** and return structured
  errors (including field-level validation errors).
- Role-based access control: `middleware.ts` protects `/dashboard/*` and
  `/onboarding`; each role's layout enforces the correct role and (for students)
  onboarding completion.
- The AI mentor calls the LLM **server-side only** (`src/lib/ai.ts`) — the key
  never reaches the client.

---

## 📜 Scripts

| Script | Description |
| --- | --- |
| `npm run dev` | Start the dev server on port 3000 |
| `npm run lint` | ESLint |
| `npm run db:push` | Sync schema to the dev DB (SQLite) |
| `npm run db:seed` | Seed demo data |
| `npm run build` | Production build |

---

## 🧪 Testing the flows

After seeding, sign in with each demo account and try:

- **Student** → take/retake the assessment → view skill gap → open the roadmap →
  solve & mark problems done → chat with the AI mentor ("What should I focus on
  next?").
- **College** → view batch readiness + heatmap → open the students table →
  export CSV.
- **Recruiter** → filter & rank candidates → shortlist one → view your shortlist
  → remove it.

---

© Cursus AI. Built for engineering students, colleges and recruiters.
