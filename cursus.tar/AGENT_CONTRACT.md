# Cursus AI — Agent Contract for Dashboard Builders

This document is the **single source of truth** for building the role dashboards.
Read it fully before writing any code. The foundation, auth, shared components,
and ALL API routes already exist and compile cleanly. You only build **page UI**
in your assigned directory. Do NOT modify any file outside your assigned directory
(except appending to `/home/z/my-project/worklog.md`).

---

## 0. Project facts

- Next.js 16 App Router + TypeScript + Tailwind v4 + shadcn/ui.
- Path alias: `@/*` → `src/*`.
- Design: white/soft-neutral background, **single deep-blue accent** (`bg-primary` /
  `text-primary`, already wired via CSS vars). Inter font already loaded.
- The dashboard chrome (top navbar + role sidebar + mobile drawer) is already
  rendered by `src/app/dashboard/layout.tsx` via `<AppShell>`. **You do NOT add a
  navbar/sidebar/footer** — your page renders inside `<main>`.
- One primary action per screen (a single solid `bg-primary` button; other actions
  use `variant="outline"` or `variant="ghost"`).
- Responsive, generous spacing, consistent cards (`<Card><CardContent className="p-5">
  / p-6`). Long lists: `max-h-96 overflow-y-auto scrollbar-thin`.
- Every screen must have helpful **loading**, **empty**, and **error** states using
  the shared components.
- All data comes from the real API — **no hardcoded mock data** in working flows.

---

## 1. Shared components & helpers you MUST reuse

Import from these — do not reinvent:

```
@/components/page-header   -> <PageHeader title description>{action children}</PageHeader>
@/components/states         -> <EmptyState title description icon action />
                              <LoadingState label />
                              <ErrorState message action />
@/components/stat-card      -> <StatCard label value hint icon tone />
                              tone: "default"|"primary"|"success"|"warning"|"danger"
@/components/logo           -> <Logo /> (optional)
@/components/ui/*           -> full shadcn set: button, card, input, label, select,
                              badge, progress, tabs, table, dialog, dropdown-menu,
                              tooltip, separator, skeleton, avatar, checkbox, etc.
@/lib/api                   -> api<T>(url, options?)  // client fetch helper
@/lib/constants             -> STAGE_LABELS, PLATFORM_LABELS, DIFFICULTY_LABELS,
                              scoreBand(score)->{label,tone}, READY_THRESHOLD,
                              AT_RISK_THRESHOLD, ROLES, PLATFORMS, DIFFICULTIES
```

### `api<T>(url, options?)` helper (client)
Returns `{ data?: T; error?: string; status: number }`. Usage:
```ts
import { api } from "@/lib/api";
const { data, error } = await api<MyType>("/api/...", { method:"POST", body: JSON.stringify({...}) });
```

### Toast notifications
```ts
import { toast } from "sonner";
toast.success("Saved"); toast.error("Failed");
```

---

## 2. API contract (all auth-protected; current user inferred from session)

### Student
- `GET /api/student/summary` →
  ```ts
  {
    stage: "AFTER_10TH"|"AFTER_12TH"|"IN_BTECH"|null,
    stageLabel: string|null,
    career: { id, title, category, summary, avgSalary } | null,
    requiredSkills: { skill: string; target: number; weight?: number }[],
    roadmap: { title: string; description: string; skills?: string[] }[],
    aggregates: {
      hasAssessment: boolean, avgCurrent: number, avgTarget: number,
      readinessPct: number /*0-100*/, gapCount: number,
      solvedProblems: number, totalProblems: number, availableProblems: number,
      status: "no-assessment"|"at-risk"|"on-track"|"ready"
    },
    skillGaps: { skill: string; target: number; current: number; gap: number;
                band: { label: string; tone: "low"|"mid"|"high" } }[],
    scores: Record<string, number>
  }
  ```
- `GET /api/assessment` → `{ career:{id,title}|null, requiredSkills:[{skill,target}], scores:Record, lastTakenAt:string|null }`
- `POST /api/assessment` body `{ careerId, scores: Record<string, number(0-100)> }` → `{ ok, takenAt }`
  - On validation error: status 422, body `{ error, fields: Record<string,string[]> }`
- `GET /api/problems?skill=&difficulty=&platform=&status=done|undone` →
  `{ problems: { id, title, platform, difficulty, topic, url, skillSlug, done }[], career:{id} }`
  - platform in `LEETCODE|GEEKSFORGEEKS|CODECHEF`, difficulty in `EASY|MEDIUM|HARD`
- `POST /api/progress` body `{ problemId, done: boolean }` → `{ ok, solved, total }`
- `GET /api/ai-chat` → `{ messages: { id, role:"user"|"assistant", content, createdAt }[], aiEnabled: boolean }`
- `POST /api/ai-chat` body `{ message }` → `{ reply: string, usedAI: boolean }`

### College (T&P)
- `GET /api/college/dashboard` →
  ```ts
  {
    collegeCode: string|null, collegeName: string|null,
    thresholds: { ready: 70, atRisk: 40 },
    batch: { total, ready, onTrack, atRisk, readinessPct },
    heatmap: { skill: string; avg: number; students: number }[],  // sorted asc by avg
    atRisk: { id, name, email, stageLabel, careerTitle, avgCurrent, readinessPct,
              status, solvedProblems }[],
    students: { id, name, email, stageLabel, careerTitle, hasAssessment, avgCurrent,
                readinessPct, status, solvedProblems }[],
    skills: string[]
  }
  ```
- `GET /api/college/students` →
  `{ collegeCode, students: { id, name, email, stageLabel, careerTitle, hasAssessment, avgCurrent, readinessPct, status, solvedProblems, totalProblems, skills: { skill, current, target, gap }[] }[] }`
- `GET /api/college/export` → `text/csv` file (Content-Disposition attachment). Trigger a browser download (see note below).

**CSV download note:** simplest is a link/button that sets `window.location.href = "/api/college/export"` (browser downloads the file). Or fetch as blob. Both work.

### Recruiter
- `GET /api/recruiter/candidates?q=&minAvg=&careerId=&stage=&skill=&minSkillScore=&sort=avg|name|recent` →
  `{ candidates: { id, name, email, stageLabel, careerTitle, careerId, avgCurrent, readinessPct, status, solvedProblems, shortlisted: boolean, skills: { skill, current, target }[] }[], recruiterId }`
- `GET /api/recruiter/shortlist` → `{ candidates: { id, name, email, stageLabel, careerTitle, avgCurrent, readinessPct, status, solvedProblems, note, shortlistedAt, skills }[] }`
- `POST /api/recruiter/shortlist` body `{ studentId, note? }` → `{ ok, shortlisted:true }`
- `DELETE /api/recruiter/shortlist?studentId=X` → `{ ok, shortlisted:false }`

### Status badge tone mapping
`status` values: `no-assessment`, `at-risk`, `on-track`, `ready`. Suggested badges:
- ready → green, on-track → blue (primary), at-risk → amber, no-assessment → gray.

---

## 3. Worklog protocol (MANDATORY)

1. Before working, read `/home/z/my-project/worklog.md` to see what's done.
2. After finishing, **append** (do not overwrite) a section starting with `---`:
   ```
   ---
   Task ID: <your id>
   Agent: <name>
   Task: <what you did>
   Work Log:
   - step 1
   - step 2
   Stage Summary:
   - key results / files created
   ```

---

## 4. Universal page pattern (client component)

```tsx
"use client";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";

type Summary = { /* ... */ };

export default function MyPage() {
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Summary>("/api/...").then((res) => {
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load");
    });
  }, []);

  if (loading) return <PageLayout><LoadingState /></PageLayout>;
  if (error) return <PageLayout><ErrorState message={error} /></PageLayout>;
  if (!data) return <PageLayout><EmptyState title="No data yet" /></PageLayout>;
  return <PageLayout>{/* real content */}</PageLayout>;
}
```

(Use a small local `PageLayout` wrapper or just `<><PageHeader.../><...></>` inline.)

---

## 5. Charts

`recharts` is installed. Use it for the skill heatmap and readiness visuals.
Colors: primary blue `var(--primary)` → in JSX use `"hsl(var(--primary))"` won't work
with oklch; instead import the chart color tokens. **Simplest:** pass explicit colors
like `"#1d4ed8"` (deep blue) and grays. Use ResponsiveContainer with explicit height.

---

Good luck. Build clean, complete, working pages. Every button must hit a real API.
