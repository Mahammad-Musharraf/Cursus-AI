import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

// Stable fallback secret (mirrors src/lib/auth.ts) so the middleware can
// decode the JWT even if NEXTAUTH_SECRET env var is missing in dev.
const DEV_FALLBACK_SECRET =
  "cursus-ai-dev-fallback-secret-do-not-use-in-prod-9f3k2l5m8n1q7r4t6w0y";

// Role-aware middleware. Protects /dashboard and /onboarding.
// - Unauthenticated users are sent to /login (relative redirect so it works
//   on any host — localhost OR preview domains).
// - Authenticated users hitting a route not meant for their role are bounced
//   to their own dashboard, avoiding redirect loops.
export default withAuth({
  pages: { signIn: "/login" },
  secret:
    (process.env.NEXTAUTH_SECRET && process.env.NEXTAUTH_SECRET.length > 10
      ? process.env.NEXTAUTH_SECRET
      : DEV_FALLBACK_SECRET),
  callbacks: {
    authorized: ({ token, req }) => {
      const path = req.nextUrl.pathname;
      const role = (token?.role as string) || null;

      // Not signed in -> NextAuth will redirect to /login (authorized=false).
      if (!token) return false;

      // Onboarding is only for students who haven't completed it.
      if (path.startsWith("/onboarding")) {
        return role === "STUDENT";
      }

      // /dashboard/<role>/* must match the user's role.
      const dashMatch = path.match(/^\/dashboard\/([a-z]+)/);
      if (dashMatch) {
        const routeRole = dashMatch[1].toUpperCase();
        // /dashboard (index) is allowed for all roles; it redirects by role.
        if (routeRole === "") return true;
        return role === routeRole;
      }

      // Fallback: allow.
      return true;
    },
    // Use RELATIVE redirects so they work on any host (localhost + preview
    // domains). Returning a path starting with "/" makes withAuth redirect
    // relative to the current host, avoiding ERR_TOO_MANY_REDIRECTS caused by
    // baseUrl mismatches when NEXTAUTH_URL is localhost but the user is on a
    // preview domain.
    async redirect({ url, token }) {
      const role = (token?.role as string) || null;
      // Authenticated but bounced (role mismatch) -> their own dashboard.
      if (token) {
        if (role === "STUDENT") return "/dashboard/student";
        if (role === "COLLEGE") return "/dashboard/college";
        if (role === "RECRUITER") return "/dashboard/recruiter";
        return "/dashboard";
      }
      // Not authenticated -> /login with a callbackUrl. Keep it relative.
      // If url is an absolute URL to the same host, extract the path.
      try {
        const u = new URL(url);
        return `/login?callbackUrl=${encodeURIComponent(u.pathname + u.search)}`;
      } catch {
        return "/login";
      }
    },
  },
});

export const config = {
  // Protect all dashboard & onboarding routes. Everything else is public.
  matcher: ["/dashboard/:path*", "/dashboard", "/onboarding/:path*"],
};
