# Task 13-a — Certificates UI Agent

## Task
Build the Certificates UI for Cursus AI:
- `src/app/dashboard/student/certificates/page.tsx` (student: list + FormData upload form)
- `src/app/dashboard/college/certificates/page.tsx` (college T&P: approval queue)

## Files Created
- `src/app/dashboard/student/certificates/page.tsx`
- `src/app/dashboard/college/certificates/page.tsx`

## Context Reused
- Read `worklog.md` (Tasks 0-12) to confirm the foundation: dashboard chrome (`dashboard/layout.tsx`), per-role layouts (role gating), shared components (`PageHeader`, `EmptyState/LoadingState/ErrorState`, full shadcn/ui set), `api<T>(url, options?)` helper from `@/lib/api`, `toast` from `sonner`.
- Read both certificate API route files to lock the exact contract:
  - `GET /api/certificates` → `{ certificates: Certificate[] }` (student) OR `{ certificates: (Certificate & { user })[] }` (college).
  - `POST /api/certificates` multipart/form-data with `title`, `issuer`, `issuedDate` (YYYY-MM-DD), `credentialUrl?`, `file` (PDF/PNG/JPG/WEBP, max 8MB). Returns `{ ok, certificate }` (201) or `{ error }` (422/429).
  - `POST /api/certificates/[id]/review` body `{ status: "APPROVED"|"REJECTED", reviewerNote? }` → `{ ok, certificate }`.
- Read existing college dashboard page.tsx + status-badge.tsx to match design conventions (semantic colors, layout patterns, retry button shape).

## Key Decisions
- **FormData upload uses raw `fetch` (NOT the `api()` helper)** — the shared `api<T>()` helper hardcodes `Content-Type: application/json` which would override the multipart/form-data boundary the browser needs to set. Using `fetch` directly with a `FormData` body lets the browser set the correct Content-Type automatically.
- Client-side validation mirrors server rules (title ≥2, issuer ≥2, YYYY-MM-DD date, file required, ≤8MB). All errors surfaced via `toast.error`. On success: `toast.success` + prepend returned cert + reset the form.
- Status badge colors: PENDING=amber, APPROVED=emerald, REJECTED=red — applied via `Badge variant="outline"` with Tailwind background/text color classes (matching the existing college `_components/status-badge.tsx` palette).
- Initial-load effect inlines the `api()` call and only calls setState inside the `.then()` callback (the initial state is already `loading:true / error:null`). The standalone `load()` function (which DOES call `setLoading(true)` synchronously) is kept only for the "Try again" event handler. This avoids the `react-hooks/set-state-in-effect` lint rule and matches the existing college dashboard pattern.
- College queue sorted PENDING-first, then by createdAt desc — so pending items always surface to the top within any filter, even when the filter is "Approved" or "All".
- College review dialog uses shadcn `Dialog` with a `Textarea` (280 char limit + live counter). Approve action uses `variant="default"` (primary blue); Reject uses `variant="destructive"` (red) in the dialog footer for clear intent. Reviewer note is optional per the server schema.
- After a successful review, the college page merges the returned certificate into the existing row while preserving the nested `user` object (the review API only returns the certificate, not the user).
- Lists use `max-h-[28rem] overflow-y-auto scrollbar-thin pr-1` (matches the existing student problems page convention).
- Did NOT touch any shared components, API routes, lib, or other dashboards. No navbar/sidebar/footer added (dashboard chrome is rendered by `dashboard/layout.tsx`).

## Verification
- `bun run lint` → 0 errors across the whole project (was 1 before fixing the `react-hooks/set-state-in-effect` issue on the college page; same fix applied to the student page proactively).
- `bunx tsc --noEmit` → 0 errors in either certificates file. (All remaining project-wide TS errors are pre-existing in OTHER files: middleware.ts, notifications/route.ts, weekly-plan.ts, onboarding-engine.ts, student/page.tsx — all outside scope.)
- All imports resolve: `@/components/page-header`, `@/components/states`, `@/components/ui/{card,button,badge,input,label,dialog,textarea,select}`, `@/lib/api`, `sonner`, `lucide-react`.
- Real API integrations only: GET `/api/certificates`, POST `/api/certificates` (FormData), POST `/api/certificates/[id]/review`. No mock data.

## Stage Summary
Both certificates pages are complete, lint-clean, and TypeScript-clean. The student page lets students upload certificates via a multipart form (with client-side validation + success/error toasts + live list prepend), and the college page gives T&P a filterable approval queue with an inline review dialog (optional reviewer note, approve/reject actions, local state update on success). The pages consume the existing certificate API routes without modification and follow the project's design system (single deep-blue accent, semantic status colors only on badges, full Loading/Empty/Error states, responsive).
