# Task 7-b — College T&P Dashboard UI

**Agent:** college-ui-builder

## Task
Build the College T&P dashboard UI for Cursus AI (Next.js 16 App Router):
- `src/app/dashboard/college/page.tsx` — dashboard overview
- `src/app/dashboard/college/students/page.tsx` — detailed student table
- `src/app/dashboard/college/export/page.tsx` — CSV export page
- `src/app/dashboard/college/settings/page.tsx` — college profile + join code

Plus small shared helper client components inside the same directory.

## Work Log
- Read `AGENT_CONTRACT.md` and `worklog.md` to confirm shared components, API contract, and design rules.
- Inspected existing shared components (`PageHeader`, `states`, `StatCard`, `Card`, `Badge`, `Table`, `Progress`, `Button`, `Separator`) and the three college API routes (`/api/college/dashboard`, `/api/college/students`, `/api/college/export`).
- Created `src/app/dashboard/college/_components/` directory with three small client helpers:
  - `status-badge.tsx` — color-coded status badge (ready=green, on-track=blue/primary, at-risk=amber, no-assessment=gray).
  - `readiness-ring.tsx` — circular SVG progress ring with explicit hex colors so it renders identically in light/dark.
  - `skill-bar.tsx` — compact horizontal bar showing current vs target with band-colored fill and a target marker.
- Built `page.tsx` (dashboard overview):
  - Fetches `GET /api/college/dashboard`.
  - Empty-state branch when `batch.total === 0` shows college code prominently (dashed primary-tinted box) + "Copy college code" primary button + toast.
  - Hero "Batch readiness" card with the SVG ring + summary line ("X of Y students placement-ready") + status badges.
  - Stat cards row (Total, Ready, On-track, At-risk) using `StatCard` with appropriate tones + icons.
  - Skill heatmap: recharts horizontal `BarChart` with per-`Cell` color (red <40, amber 40-69, green ≥70); inline EmptyState when `heatmap` is empty.
  - At-risk students list inside `max-h-96 overflow-y-auto scrollbar-thin`; positive EmptyState "No at-risk students 🎉" when empty.
  - Primary button: "Export CSV" → `window.location.href = "/api/college/export"`. Secondary: "View all students" link.
  - Loading and Error states both wired.
- Built `students/page.tsx` (detailed table):
  - Fetches `GET /api/college/students`.
  - shadcn `Table` (already wrapped in `overflow-x-auto`) with columns: Name (+email), Career, Stage, Assessment taken (Yes/No badge with icons), Avg, Readiness %, Status badge, Problems solved (with /total).
  - Expandable rows: clicking a row toggles a details row showing per-skill scores (current/target/gap) as `SkillBar` components in a 2-col grid. Used keyed `<Fragment>` to avoid React key warnings.
  - Empty state when batch is empty.
  - Primary button: "Export CSV". Secondary: "Back to dashboard".
  - Loading + Error states.
- Built `export/page.tsx` (CSV export):
  - Fetches `GET /api/college/students` to show a preview count ("N students will be exported").
  - Explains what's included via a 2-column grid of fields with check icons.
  - Big `size="lg"` primary "Download CSV" button → `window.location.href = "/api/college/export"`. Shows the resulting filename.
  - Empty state if batch is empty.
  - Loading + Error states. Secondary: "Back to dashboard".
- Built `settings/page.tsx` (college profile):
  - Uses `useSession()` from `next-auth/react` for name/email. Fetches `/api/college/dashboard` for `collegeName` + `collegeCode`.
  - Read-only account details card (Name, Email, College name).
  - College join code card with highlighted dashed box + big mono code + "Copy code" primary button + toast.
  - Loading + Error states. Secondary: "Back to dashboard".
- Ran `bun run lint` (eslint) on the college directory only — clean (0 errors). The two eslint errors reported project-wide are in OTHER agents' files (`recruiter/page.tsx`, `onboarding-client.tsx`) which are out of scope.
- Ran `bunx tsc --noEmit` — initially caught an import path mistake in `page.tsx` (used `../_components/...` instead of `./_components/...` since `page.tsx` lives in `college/` directly). Fixed and re-ran — clean.

## Stage Summary
- 4 page files + 3 helper components delivered, all under `src/app/dashboard/college/` (nothing outside the assigned directory was touched).
- All pages are `"use client"`, use the shared `PageHeader` / `states` / `StatCard` / shadcn components, single deep-blue accent, semantic green/amber/red only for status, responsive, with Loading/Error/Empty states everywhere.
- All actions hit real APIs (`/api/college/dashboard`, `/api/college/students`, `/api/college/export` via `window.location.href`).
- ESLint + TypeScript checks clean for the college scope.
