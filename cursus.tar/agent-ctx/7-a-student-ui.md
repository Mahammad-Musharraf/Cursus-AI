# Task 7-a — Student Dashboard UI Agent

## Task
Build all 7 student dashboard pages under `src/app/dashboard/student/` per AGENT_CONTRACT.md:
- `page.tsx` (dashboard overview)
- `assessment/page.tsx` (skill assessment form)
- `skill-gap/page.tsx` (skill-gap analysis + recharts bar chart)
- `roadmap/page.tsx` (vertical stepper roadmap)
- `problems/page.tsx` (curated problems + filters + mark-done + progress)
- `ai-chat/page.tsx` (AI mentor chat)
- `settings/page.tsx` (read-only profile)

## Files Created
- `src/app/dashboard/student/page.tsx`
- `src/app/dashboard/student/assessment/page.tsx`
- `src/app/dashboard/student/skill-gap/page.tsx`
- `src/app/dashboard/student/roadmap/page.tsx`
- `src/app/dashboard/student/problems/page.tsx`
- `src/app/dashboard/student/ai-chat/page.tsx`
- `src/app/dashboard/student/settings/page.tsx`

## Key Decisions
- All pages are `"use client"` per the contract's universal page pattern.
- Reuse shared components only — `PageHeader`, `LoadingState/ErrorState/EmptyState`, `StatCard`, full shadcn/ui set.
- Single primary action per page (`bg-primary` Button). All other actions use `variant="outline"` or `variant="ghost"`.
- Status semantic colors (emerald / amber / red) used sparingly on badges per design rules — no other accents.
- Readiness ring rendered as inline SVG circle (oklch colors with explicit hex fallback for the dynamic stroke).
- `useSession()` from `next-auth/react` used on the dashboard greeting and on the settings profile page.
- Assessment POST uses raw `fetch` (not `api()`) so we can read the 422 `fields` payload for inline field errors — the shared `api()` helper only exposes `error` and `status`.
- Problems page: filter changes set `loading=true` inside the change handler (event-driven) so the refetch `useEffect` doesn't violate the `react-hooks/set-state-in-effect` rule.
- AI chat: optimistic user message + "Thinking…" typing indicator while waiting for the assistant reply; auto-scroll to bottom via `useRef` + `scrollIntoView`.
- Roadmap: vertical stepper with numbered circles connected by a 1px border line; steps without skills render a "Milestone" badge.

## Verification
- `bun run lint` — no errors in any student page (only remaining project-level error is in `onboarding-client.tsx`, which is the orchestrator's file and outside scope).
- `bunx tsc --noEmit` — no errors in any student page.
- All 7 student routes compile cleanly in `dev.log` (verified by triggering each route via curl and checking for compile errors).
- Each page hits a real API endpoint (`/api/student/summary`, `/api/assessment`, `/api/problems`, `/api/progress`, `/api/ai-chat`).

## Stage Summary
All 7 student dashboard pages are complete and pass lint + type checks. They use the real API, shared components, and follow the design system (single deep-blue accent, consistent cards, loading/empty/error states everywhere).
