# Task 7-c — recruiter-ui

## Task
Build the Recruiter dashboard UI (3 pages) for Cursus AI Next.js 16 app:
- `src/app/dashboard/recruiter/page.tsx` — Candidates (filter + rank + shortlist)
- `src/app/dashboard/recruiter/shortlist/page.tsx` — Shortlisted candidates
- `src/app/dashboard/recruiter/settings/page.tsx` — Recruiter profile (read-only)

## Scope
ONLY created files under `src/app/dashboard/recruiter/`. Did NOT touch shared components, API routes, lib, or layouts.

## Files created
1. `src/app/dashboard/recruiter/shared.tsx` — shared client types + helpers:
   - `Candidate`, `ShortlistedCandidate`, `CandidateStatus`, `CandidateSkill` types (matching the API contract).
   - `StatusBadge` — semantic colors (ready=green, on-track=primary blue, at-risk=amber, no-assessment=gray).
   - `SkillBars` — top-N skill bars with current/target using shadcn `Progress`.
   - `MetricBlock` — label/value/hint block.
   - `initialsOf(name)`, `formatDate(iso)` helpers.

2. `src/app/dashboard/recruiter/page.tsx` — Candidates page:
   - PageHeader with "View shortlist" primary button → `/dashboard/recruiter/shortlist`.
   - Filter bar Card: text search (`q`, 300ms debounce), min avg Select (Any/40/60/70), stage Select (All + STAGE_LABELS), sort Select (avg/name/recent). "Clear" ghost button when filters active.
   - Fetches `GET /api/recruiter/candidates?<params>` on filter change.
   - Result count ("N candidates"). List scrolls with `max-h-[32rem] overflow-y-auto scrollbar-thin`.
   - Candidate cards: avatar+initials, name, status badge, email, careerTitle • stageLabel, big avg score + problems-solved hint, readiness % + Progress, top 3 skill bars.
   - Shortlist toggle: primary "Shortlist" button POSTs `{ studentId }`; outline "Shortlisted ✓" DELETEs `?studentId=`. Optimistic UI + toast + rollback.
   - Optional note dialog: ghost `StickyNote` icon button (only when shortlisted) opens Dialog with Textarea (280 char). POSTs `{ studentId, note }` (upserts). Toast on success/error.
   - Empty states: "No candidates yet" vs "No matches for these filters" (with Clear filters action).
   - Loading state, Error state with "Try again" (uses refreshKey state to refetch).

3. `src/app/dashboard/recruiter/shortlist/page.tsx` — Shortlist page:
   - Fetches `GET /api/recruiter/shortlist`.
   - Grid of cards (md:grid-cols-2): avatar+initials, name, status badge, email, careerTitle • stageLabel, avg score, readiness % + Progress, top 3 skills, note (in callout), shortlisted date (formatted).
   - "Contact" mailto button + "Remove" outline button (DELETE `?studentId=`) with optimistic removal + restore + toast.
   - Empty state: "Your shortlist is empty" with primary "Find candidates" → `/dashboard/recruiter`.
   - Primary header button (when non-empty): "Find more candidates".
   - Loading/Error states.

4. `src/app/dashboard/recruiter/settings/page.tsx` — Settings page:
   - `useSession()` from `next-auth/react` for name + email. Shows "Recruiter" role badge. Company "—" with hint.
   - Two cards: Account (avatar, name, email, role badge, grid of fields: Full name / Email / Company / Role) and Permissions (3 permission rows).
   - Disabled "Edit profile" outline button wrapped in Tooltip ("Profile editing isn't available yet."). Button wrapped in span with tabIndex so hover still triggers tooltip on disabled control.
   - Loading state while session loads.

## Verification
- `npx eslint src/app/dashboard/recruiter/` → exit 0 (no errors, no warnings).
- `npx tsc --noEmit -p tsconfig.json | grep "src/app/dashboard/recruiter"` → no matches (0 TS errors in my files).
- Dev server compiled all three routes cleanly:
  - `GET /dashboard/recruiter` 307 (compile: 2.0s) — auth redirect, no compile errors.
  - `GET /dashboard/recruiter/shortlist` 307 (compile: 611ms) — clean compile.
  - `GET /dashboard/recruiter/settings` 307 (compile: 504ms) — clean compile.

## Notes for downstream agents
- The recruiter sidebar (`src/components/role-sidebar.tsx`) only links to Candidates and Shortlist; the Settings page is reachable via the navbar's "Profile" dropdown link (already wired in `src/components/navbar.tsx` → `/dashboard/{role}/settings`).
- 2 pre-existing lint errors outside my scope remain in: `src/app/dashboard/student/problems/page.tsx` (agent 7-a) and `src/app/onboarding/onboarding-client.tsx` (orchestrator). These are NOT mine to fix per the contract.
- Shared recruiter types live in `src/app/dashboard/recruiter/shared.tsx`. If another agent (e.g. 7-d) wants to reuse `Candidate`/`ShortlistedCandidate` types, import from there.
