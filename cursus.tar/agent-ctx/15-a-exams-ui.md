# Task 15-a — Exams UI (recruiter + student)

**Agent:** exams-ui
**Task ID:** 15-a
**Scope:** Build the 4 exam pages for both recruiter and student dashboards.

## Files created (this task)

1. `src/app/dashboard/recruiter/exams/page.tsx`
   - Recruiter exam list + create-exam form (single primary action).
   - PageHeader "Exams" + description "Create screening exams from a question bank."
   - **Create exam card** (toggleable): title (Input), description (Textarea), durationMin (default 60), questionsToPick (default 10), passScorePct (default 60).
   - **Question builder**: dynamic list where recruiter adds questions. Each row has type (Select: MCQ/SHORT_ANSWER/CODING), prompt (Input), difficulty (Select: EASY/MEDIUM/HARD), points (1–10).
     - MCQ: 4 option Inputs + a `RadioGroup` to pick the correct one (the chosen index is sent as `answer` string e.g. "1").
     - SHORT_ANSWER: an "expected answer" Input — sent as `answer`.
     - CODING: prompt only — `answer` defaults to "PENDING_MANUAL_REVIEW".
   - Optional `skillSlug` field per question.
   - Submit uses **raw `fetch`** (NOT `api()`) so we can read the `fields` map returned on 422 — the `api()` helper drops everything except `error`. On 422, field errors are surfaced inline + as toasts.
   - On success (201): toast + prepend new exam to the list + reset form + collapse the create card.
   - Exam list cards: title + active/inactive badge, optional job badge, description (2-line clamp), duration / questions-in-bank+picks / attempts / pass % / created date, and a "View & results" outline link to the detail page.
   - Loading/Empty/Error states.

2. `src/app/dashboard/recruiter/exams/[id]/page.tsx`
   - Fetch `GET /api/recruiter/exams/[id]` → exam + questions + attempts.
   - Settings summary card with 4 stat blocks (Duration / Questions · picks / Pass score / Attempts) and an inline active/inactive toggle (`Switch` → PATCH `/api/recruiter/exams/[id]` body `{isActive}`).
   - Optimistic toggle: flip locally first, then PATCH; rollback + toast on failure.
   - 3 quick-stat cards: Submitted attempts, Passed (n/total), Avg score.
   - **Question bank** list — read-only view: type icon, difficulty badge (semantic colors), skill slug, points, prompt, and answer reveal:
     - MCQ: each option listed with the correct one highlighted (emerald border + check icon).
     - SHORT_ANSWER: "Expected answer" callout (emerald, monospace).
     - CODING: dashed note about manual review.
   - **Attempts table**: student name/email, score %, pass/fail badge (emerald/red, with check/x icon), time spent (mm:ss), submitted at date. "In progress" badge if started but not submitted.
   - Delete via `AlertDialog` confirm → DELETE → redirect back to list.
   - Loading/Error/Empty states. "Back" link to /dashboard/recruiter/exams.

3. `src/app/dashboard/student/exams/page.tsx`
   - Fetch `GET /api/exams/available`.
   - **Available to you** section: cards with title + job badge, company (with building icon), description, duration/questions/pass mark row. For exams **not yet attempted**: primary "Start exam" button → `/dashboard/student/exams/[id]`. For "in progress" (hasAttempted && !submitted): amber badge + "Resume" primary button.
   - **My results** section (only shown when there are submitted results): grid of cards with title, company, big score %, pass/fail badge (emerald/red), progress bar, pass mark, duration.
   - Empty states for both sections.

4. `src/app/dashboard/student/exams/[id]/page.tsx` — TAKE THE EXAM (the critical page).
   - On mount: `POST /api/exams/[id]/start` via `api()`.
     - If `status === 409`: render "You've already taken this exam" empty card with link back to exams list.
     - If success: enter `taking` phase with `attemptId`, exam meta, randomized questions, and seed `secondsLeft = durationMin * 60`.
     - Else: `error` phase.
   - Phase state machine: `starting` → `taking` → `submitting` → `done` (or `error` / `alreadyAttempted`).
   - **Sticky timer header**: shows exam title, pass mark, total questions, tab-switch badge (amber, with eye-off icon, count), and a large `mm:ss` countdown. Timer turns amber at ≤60s and red at 0.
   - Progress bar: "Question X of N answered" + percentage.
   - **Timer** uses `setInterval` in a `useEffect` keyed on `phase.kind` only (so the interval isn't recreated every tick). When `secondsLeft` hits 0, it triggers `autoSubmitRef.current()` and holds at 0 (doesn't re-fire). Interval cleared on cleanup.
   - **Tab-switch listener**: `visibilitychange` — when `document.hidden` becomes true, increment `tabSwitches` + toast.warning("Please don't switch tabs — this is recorded."). Listener added/removed on mount/unmount of the `taking` phase.
   - **Leave guard**: `beforeunload` (catches refresh/close/full nav) + a document-level capture-phase `click` listener that intercepts same-origin anchor clicks (so SPA navigation via sidebar/nav links prompts "Your exam progress will be lost."). Only active in the `taking` phase.
   - **Question rendering** (don't crash if no options):
     - MCQ: `RadioGroup` of options A/B/C/D — selected index sent as string.
     - SHORT_ANSWER: single `Input`.
     - CODING: `Textarea` with monospace font, spellCheck off.
     - Per-question type badge + difficulty badge + skill slug + points. "Answered" tick when value is non-empty.
   - **Submit button** (primary) opens an `AlertDialog` confirmation: shows count answered vs total, warns it can't be undone. On confirm → `doSubmit()` which sets phase to `submitting` and POSTs `/api/exams/[id]/submit` with `{attemptId, responses:[{questionId,answer}], timeSpentSec, tabSwitches}`. `submitRef` guard prevents double-submit (e.g. user clicking + auto-timer firing at the same time).
   - **Auto-submit** when timer hits 0: same path as manual submit, plus a "Time's up — submitting your exam…" banner.
   - **Done screen**: large pass/fail icon (emerald check / red x), score %, correct count / total, pass mark, time spent. Primary "Back to exams" link.

## API contracts verified

Read every exam API route to confirm shape:
- `GET /api/recruiter/exams` → `{exams:[{id,title,description,durationMin,questionsToPick,passScorePct,isActive,jobId,jobTitle,questionCount,attemptCount,createdAt}]}`
- `POST /api/recruiter/exams` body `{title,description,durationMin,questionsToPick,passScorePct,jobId?,questions:[{type,prompt,options?,answer,skillSlug?,difficulty,points}]}` → 201 `{ok,exam}`; 422 `{error,fields}`
- `GET /api/recruiter/exams/[id]` → `{exam:{...fields, questions:[...], attempts:[{id,student,scorePct,passed,submittedAt,timeSpentSec}]}}`
- `PATCH /api/recruiter/exams/[id]` body `{isActive}` → `{ok}`
- `DELETE /api/recruiter/exams/[id]` → `{ok}`
- `GET /api/exams/available` → `{exams:[{id,title,description,durationMin,questionsToPick,passScorePct,companyName,jobTitle,questionCount,hasAttempted,submitted,scorePct,passed}]}`
- `POST /api/exams/[id]/start` → `{attemptId,exam,questions,totalQuestions}`; 409 if already attempted
- `POST /api/exams/[id]/submit` body `{attemptId,responses,timeSpentSec,tabSwitches}` → `{ok,scorePct,passed,totalQuestions,correctCount,timeSpentSec,submittedAt}`
- `GET /api/exams/[id]/result` (not used by these pages — the start endpoint's 409 + the submit response cover our needs)

## Design conformance

- Single primary button per screen: Create exam (recruiter list), Start exam (student list), Submit exam (student take), Start exam / Resume (student available).
- White/soft-neutral bg, single deep-blue accent. Semantic green/amber/red only on status badges (pass/fail, active/inactive, difficulty, tab-switches).
- Responsive: mobile-first; grids collapse (sm:grid-cols-2, lg:grid-cols-4 etc.).
- Loading/Empty/Error states everywhere; ErrorState action buttons retry.
- Card alignment/padding consistent (`p-4 sm:p-5` on content cards).
- Long lists handled with `max-h-* overflow-y-auto scrollbar-thin` where applicable; tables are wrapped in the shadcn Table container with `overflow-x-auto`.

## Verification

- `bun run lint` → **0 errors** (clean across the whole project for my files).
- `bunx tsc --noEmit` → **0 errors in my files**. (Only remaining project-wide TS error is pre-existing in `src/app/api/recruiter/exams/route.ts:81` — a Prisma typing quirk on `options: q.options ?? null` where the inferred zod type is `string[]` not `string[] | null`. Out of scope; lint passes and the route works at runtime — Prisma happily accepts the Json value.)
- All 4 pages compiled successfully via the dev server (HEAD requests returned 307 → /login redirect because no session, but compile succeeded in 600–1200 ms each — no compile errors in dev.log).
- All imports resolve (shared `@/components/page-header`, `@/components/states`, `@/components/ui/*`, `@/lib/api`, `sonner`, `lucide-react`).
- No navbar/sidebar/footer added — pages render inside the existing `<main>` from `dashboard/layout.tsx`; role gating already done by per-role layouts.

## Files NOT touched (per task constraints)

Shared components, API routes, lib, middleware, sidebar, other dashboards, Prisma schema. The sidebar already has the "Exams" item wired for both STUDENT and RECRUITER (verified in `src/components/role-sidebar.tsx`), so navigation works out of the box.

## Stage Summary

4 exam pages delivered and lint/TS clean. The student take-exam page is the most robust: state-machine phases, sticky timer with auto-submit at 0, tab-switch visibility listener with toast warning + counter, full leave guard (beforeunload + click-intercept for in-app navigation), question-type-aware rendering (MCQ radio / SHORT_ANSWER input / CODING monospace textarea — none crash on missing options), confirmation dialog before submit, and a results screen with pass/fail + score + correct count. Recruiter create-exam flow uses raw fetch so 422 field errors are surfaced inline + as toasts. Recruiter detail page shows the question bank with correct answers highlighted + an attempts table + active toggle + delete confirm.
