# Task 13-b — Student Dashboard Enhancer

**Agent**: student-dashboard-enhancer
**Task ID**: 13-b
**Scope**: Enhance `src/app/dashboard/student/page.tsx` (and add helper components in `src/app/dashboard/student/_components/`).

## What I built

### New helper components (under `src/app/dashboard/student/_components/`)
1. **`types.ts`** — Shared types `PlanItem`, `DayGroup`, `PlanProgress`, `PlanData` (single source of truth so the page and component files share identical types; avoids TS2719 "two unrelated types" errors).
2. **`skill-radar.tsx`** — recharts `RadarChart` with two series (Current = primary-blue filled, Target = muted gray). Falls back to `EmptyState` ("Take assessment") when `!hasAssessment`.
3. **`career-match-card.tsx`** — Shows top AI recommendation (with match %, reasons) and the student's chosen career. Notes the mismatch if `chosen.slug !== top.slug`. "Retake career quiz" outline button → `/onboarding?retake=1`. Falls back to `EmptyState` ("Take the career quiz") when both are empty.
4. **`today-problems-card.tsx`** — Today's problems with progress bar, per-item difficulty/platform/topic badges + assignment reason, external `Solve` link (`<a target="_blank" rel="noopener noreferrer">`), "Open weekly plan" outline button → `/dashboard/student/problems`. "Rest day ☕" empty state when nothing assigned.
5. **`weekly-plan-card.tsx`** — 7-day grid (MON..SUN) with overall weekly progress bar; today's day is highlighted with primary tint + "Today" badge. Each item: difficulty dot + truncated title + done check. `max-h-96 overflow-y-auto scrollbar-thin`.

### Enhanced `page.tsx`
- **Parallel fetch**: `Promise.all([summary, career-match, plan])` on mount. Summary is critical (bail on error); careerMatch + plan gracefully degrade (their sections show empty-state fallbacks).
- **Greeting + Today's-goal chip**: `Hi, {firstName}` (from `useSession`) with a small chip in the PageHeader children showing flame icon + today's goal status:
  - `Goal complete! 🎉` (green flame) when today's items all done
  - `Rest day ☕` (muted flame) when no items today
  - `N problems left today` (primary flame) otherwise
- **Top row (2-col lg)**: Hero card (career badges, title, summary, salary, readiness ring, primary CTA) | CareerMatchCard.
- **5 stat cards**: Avg score, Readiness, Skills to improve, Problems solved, **Weekly progress** (new — `plan.progress.pct`).
- **2-col body**: Left = TodayProblemsCard + WeeklyPlanCard stacked. Right = SkillRadar + Top skill gaps card stacked.
- **Next milestone**: full-width card with title/description/skill chips + "View full roadmap".
- **Single primary button**: hero CTA switches between "Take assessment" (no assessment) ↔ "Solve today's problems" (assessment done). All other actions (Retake assessment, Ask AI mentor, Retake career quiz, View full skill gap, View full roadmap, Open weekly plan, Solve per-item) are `outline`/`secondary`.

## Reused (no new lib / API / shared components)
- `@/components/page-header`, `@/components/states` (LoadingState/ErrorState/EmptyState), `@/components/stat-card` (StatCard).
- `@/components/ui/{card,button,badge,progress}`.
- `@/lib/api` (`api<T>` fetcher), `@/lib/constants` (READY/AT_RISK thresholds, PLATFORM_LABELS, DIFFICULTY_LABELS, types).
- `recharts` RadarChart, `next-auth/react` useSession, `lucide-react` icons.

## Verification
- `bun run lint` — clean (0 errors).
- `bunx tsc --noEmit` — clean for all files under `src/app/dashboard/student/`. (Pre-existing errors in `src/lib/onboarding-engine.ts`/`src/app/api/onboarding/choose/route.ts`/`prisma/careers-data.ts`/`src/lib/weekly-plan.ts` are out of scope.)
- Page compiles cleanly in dev.log (`GET /dashboard/student 200 in 38ms`).

## Known runtime note
- `/api/student/career-match` depends on `src/lib/onboarding-engine.ts`, which has a pre-existing broken import `@/prisma/careers-data` (the file lives at `prisma/careers-data.ts`, not `src/prisma/careers-data.ts`). Out of scope to fix per task constraints. The dashboard gracefully degrades: if the API returns 500, `careerMatch` stays null and `CareerMatchCard` shows the "Take the career quiz" EmptyState with a working "Retake career quiz" button.
