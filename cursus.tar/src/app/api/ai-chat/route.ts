import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";
import { loadStudentContext, getAssistantReply } from "@/lib/ai";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const messages = await db.chatMessage.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
    take: 50,
    select: {
      id: true,
      role: true,
      content: true,
      createdAt: true,
    },
  });

  return json({ messages, aiEnabled: !!process.env.ZAI_API_KEY });
}

const ChatSchema = z.object({
  message: z.string().trim().min(1, "Message can't be empty").max(2000),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const parsed = await parseBody(ChatSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { message } = parsed.data;

  // Load recent history for context
  const recent = await db.chatMessage.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 8,
    select: { role: true, content: true },
  });
  const history = recent
    .reverse()
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

  const ctx = await loadStudentContext(user.id);
  const { reply, usedAI } = await getAssistantReply(ctx, history, message);

  // Persist both messages
  await db.$transaction([
    db.chatMessage.create({
      data: { userId: user.id, role: "user", content: message },
    }),
    db.chatMessage.create({
      data: { userId: user.id, role: "assistant", content: reply },
    }),
  ]);

  return json({ reply, usedAI });
}
