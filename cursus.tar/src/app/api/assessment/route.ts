import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";
import { asRequiredSkills } from "@/lib/student-stats";

async function requireStudent() {
  const user = await getCurrentUser();
  if (!user) return null;
  if (user.role !== "STUDENT") return { user, forbidden: true as const };
  return { user, forbidden: false as const };
}

export async function GET() {
  const ctx = await requireStudent();
  if (!ctx) return unauthorized();
  if (ctx.forbidden) return forbidden();

  const rec = await getCurrentUserRecord();
  const career = rec?.targetCareerId
    ? await db.career.findUnique({ where: { id: rec.targetCareerId } })
    : null;

  const requiredSkills = career ? asRequiredSkills(career.requiredSkills) : [];

  const latest = rec
    ? await db.assessment.findFirst({
        where: { userId: rec.id },
        orderBy: { takenAt: "desc" },
      })
    : null;

  return json({
    career: career
      ? { id: career.id, title: career.title }
      : null,
    requiredSkills,
    scores: latest ? (latest.scores as Record<string, number>) : {},
    lastTakenAt: latest?.takenAt ?? null,
  });
}

const ScoresSchema = z.record(z.string(), z.number().min(0).max(100));

const AssessmentSchema = z.object({
  careerId: z.string().min(1),
  scores: ScoresSchema,
});

export async function POST(req: Request) {
  const ctx = await requireStudent();
  if (!ctx) return unauthorized();
  if (ctx.forbidden) return forbidden();

  const parsed = await parseBody(AssessmentSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { careerId, scores } = parsed.data;

  const career = await db.career.findUnique({ where: { id: careerId } });
  if (!career) return errorResponse("Career not found.", 404);

  const rec = await getCurrentUserRecord();
  if (!rec) return unauthorized();

  // Only keep scores for skills that belong to this career.
  const allowed = asRequiredSkills(career.requiredSkills).map((s) => s.skill);
  const clean: Record<string, number> = {};
  for (const k of allowed) {
    if (typeof scores[k] === "number") clean[k] = scores[k];
  }

  const assessment = await db.assessment.create({
    data: {
      userId: rec.id,
      careerId,
      scores: clean,
    },
  });

  return json({ ok: true, takenAt: assessment.takenAt }, 201);
}
