import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized } from "@/lib/api";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const { searchParams } = new URL(req.url);
  const stage = searchParams.get("stage");

  const careers = await db.career.findMany({
    orderBy: { title: "asc" },
    select: {
      id: true,
      slug: true,
      title: true,
      category: true,
      stages: true,
      summary: true,
      avgSalary: true,
      icon: true,
    },
  });

  const filtered = stage
    ? careers.filter((c) => c.stages.split(",").map((s) => s.trim()).includes(stage))
    : careers;

  return json({ careers: filtered });
}
