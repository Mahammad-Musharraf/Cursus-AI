import { db } from "@/lib/db";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  PLATFORMS,
  DIFFICULTIES,
  type Platform,
  type Difficulty,
} from "@/lib/constants";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const rec = await getCurrentUserRecord();
  if (!rec?.targetCareerId) {
    return json({ problems: [], career: null });
  }

  const { searchParams } = new URL(req.url);
  const skill = searchParams.get("skill") || undefined;
  const difficulty = searchParams.get("difficulty") as Difficulty | null;
  const platform = searchParams.get("platform") as Platform | null;
  const status = searchParams.get("status"); // "done" | "undone"

  const where: {
    careerId: string;
    skillSlug?: string;
    difficulty?: string;
    platform?: string;
  } = { careerId: rec.targetCareerId };
  if (skill) where.skillSlug = skill;
  if (difficulty && DIFFICULTIES.includes(difficulty)) where.difficulty = difficulty;
  if (platform && PLATFORMS.includes(platform)) where.platform = platform;

  const problems = await db.problem.findMany({
    where,
    orderBy: [{ difficulty: "asc" }, { title: "asc" }],
    include: {
      progress: { where: { userId: rec.id } },
    },
  });

  let result = problems.map((p) => ({
    id: p.id,
    title: p.title,
    platform: p.platform,
    difficulty: p.difficulty,
    topic: p.topic,
    url: p.url,
    skillSlug: p.skillSlug,
    done: p.progress.some((pr) => pr.done),
  }));

  if (status === "done") result = result.filter((p) => p.done);
  if (status === "undone") result = result.filter((p) => !p.done);

  return json({ problems: result, career: { id: rec.targetCareerId } });
}
