import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, errorResponse } from "@/lib/api";
import { db } from "@/lib/db";
import { z } from "zod";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const { searchParams } = new URL(req.url);
  const onlyUnread = searchParams.get("unread") === "1";

  const notifications = await db.notification.findMany({
    where: { userId: user.id, ...(onlyUnread ? { read: false } : {}) },
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  const unreadCount = await db.notification.count({
    where: { userId: user.id, read: false },
  });

  return json({ notifications, unreadCount });
}

const MarkSchema = z.object({
  ids: z.array(z.string()).optional(),
  all: z.boolean().optional(),
});

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const body = await req.json().catch(() => ({}));
  const parsed = MarkSchema.safeParse(body);
  if (!parsed.ok) return errorResponse("Invalid input.", 422);

  if (parsed.data.all) {
    await db.notification.updateMany({
      where: { userId: user.id, read: false },
      data: { read: true },
    });
  } else if (parsed.data.ids?.length) {
    await db.notification.updateMany({
      where: { userId: user.id, id: { in: parsed.data.ids } },
      data: { read: true },
    });
  }

  return json({ ok: true });
}
