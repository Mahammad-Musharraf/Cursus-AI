import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";

// Student: list their job applications
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const applications = await db.jobApplication.findMany({
    where: { studentId: user.id },
    orderBy: { updatedAt: "desc" },
    include: {
      job: {
        select: {
          id: true,
          title: true,
          location: true,
          jobType: true,
          packageLpa: true,
          recruiter: { select: { companyName: true, name: true } },
        },
      },
    },
  });

  return json({
    applications: applications.map((a) => ({
      id: a.id,
      stage: a.stage,
      coverNote: a.coverNote,
      createdAt: a.createdAt,
      updatedAt: a.updatedAt,
      job: {
        id: a.job.id,
        title: a.job.title,
        location: a.job.location,
        jobType: a.job.jobType,
        packageLpa: a.job.packageLpa,
        companyName: a.job.recruiter.companyName ?? a.job.recruiter.name,
      },
    })),
  });
}
