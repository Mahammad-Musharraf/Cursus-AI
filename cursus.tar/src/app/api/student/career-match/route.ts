import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import { db } from "@/lib/db";
import { getLatestOnboarding } from "@/lib/onboarding-engine";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const latest = await getLatestOnboarding(user.id);
  if (!latest) {
    return json({ recommendations: [], chosen: null });
  }

  const chosen = latest.chosenCareerId
    ? await db.career.findUnique({
        where: { id: latest.chosenCareerId },
        select: { id: true, title: true, slug: true, category: true },
      })
    : null;

  return json({ recommendations: latest.recommendations, chosen, confirmed: latest.confirmed });
}
