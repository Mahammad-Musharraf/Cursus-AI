import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import { getWeeklyPlan } from "@/lib/weekly-plan";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();
  const plan = await getWeeklyPlan(user.id);
  return json(plan);
}
