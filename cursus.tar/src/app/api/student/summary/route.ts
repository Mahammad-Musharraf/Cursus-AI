import { db } from "@/lib/db";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  asRoadmap,
  asRequiredSkills,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS } from "@/lib/constants";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const rec = await db.user.findUnique({
    where: { id: user.id },
    include: {
      targetCareer: true,
      assessments: { orderBy: { takenAt: "desc" } },
      problemProgress: { include: { problem: true } },
    },
  });
  if (!rec) return unauthorized();

  const career = rec.targetCareer;
  const requiredSkills = career ? asRequiredSkills(career.requiredSkills) : [];
  const roadmap = career ? asRoadmap(career.roadmap) : [];

  const agg = studentAggregates(rec as unknown as StudentWithRelations);

  // Count problems available for this career
  const totalAvailable = career
    ? await db.problem.count({ where: { careerId: career.id } })
    : 0;

  return json({
    stage: rec.stage,
    stageLabel: rec.stage ? STAGE_LABELS[rec.stage as keyof typeof STAGE_LABELS] : null,
    career: career
      ? {
          id: career.id,
          title: career.title,
          category: career.category,
          summary: career.summary,
          avgSalary: career.avgSalary,
        }
      : null,
    requiredSkills,
    roadmap,
    aggregates: {
      hasAssessment: agg.hasAssessment,
      avgCurrent: agg.avgCurrent,
      avgTarget: agg.avgTarget,
      readinessPct: agg.readinessPct,
      gapCount: agg.gapCount,
      solvedProblems: agg.solvedProblems,
      totalProblems: agg.totalProblems,
      availableProblems: totalAvailable,
      status: agg.status,
    },
    skillGaps: agg.skillGaps,
    scores: agg.scores,
  });
}
