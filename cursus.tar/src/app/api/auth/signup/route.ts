import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { generateCollegeCode } from "@/lib/codes";
import { json, errorResponse, parseBody, zodErrors } from "@/lib/api";

const SignupSchema = z
  .object({
    name: z.string().trim().min(2, "Name must be at least 2 characters"),
    email: z.string().trim().email("Enter a valid email"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    role: z.enum(["STUDENT", "COLLEGE", "RECRUITER"]),
    collegeName: z.string().trim().optional(),
    collegeCode: z.string().trim().optional(),
    companyName: z.string().trim().optional(),
    collegeCodeRef: z.string().trim().optional(),
  })
  .superRefine((val, ctx) => {
    if (val.role === "COLLEGE" && (!val.collegeName || val.collegeName.length < 2)) {
      ctx.addIssue({
        code: "custom",
        path: ["collegeName"],
        message: "College name is required",
      });
    }
    if (val.role === "RECRUITER" && (!val.companyName || val.companyName.length < 2)) {
      ctx.addIssue({
        code: "custom",
        path: ["companyName"],
        message: "Company name is required",
      });
    }
  });

export async function POST(req: Request) {
  const parsed = await parseBody(SignupSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const body = parsed.data;

  const email = body.email.toLowerCase();
  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return errorResponse("An account with this email already exists.", 409);
  }

  const passwordHash = await bcrypt.hash(body.password, 10);

  // Role-specific extra fields
  let collegeName: string | null = null;
  let collegeCode: string | null = null;
  let companyName: string | null = null;

  if (body.role === "COLLEGE") {
    collegeName = body.collegeName!;
    collegeCode = (body.collegeCode?.trim() || generateCollegeCode(collegeName)).toUpperCase();
    const clash = await db.user.findUnique({ where: { collegeCode } });
    if (clash) {
      collegeCode = generateCollegeCode(collegeName);
    }
  } else if (body.role === "RECRUITER") {
    companyName = body.companyName!;
  }

  const user = await db.user.create({
    data: {
      email,
      name: body.name,
      passwordHash,
      role: body.role,
      collegeName,
      collegeCode,
      companyName,
      collegeCodeRef:
        body.role === "STUDENT" && body.collegeCodeRef
          ? body.collegeCodeRef.toUpperCase()
          : null,
    },
    select: { id: true, email: true, role: true },
  });

  return json({ ok: true, user: { id: user.id, email: user.email, role: user.role } }, 201);
}
