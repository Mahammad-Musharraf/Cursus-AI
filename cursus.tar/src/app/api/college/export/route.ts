import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS } from "@/lib/constants";

function csvEscape(v: unknown): string {
  const s = v == null ? "" : String(v);
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "COLLEGE") return forbidden();

  const college = await db.user.findUnique({ where: { id: user.id } });
  const collegeCode = college?.collegeCode ?? "";

  const students = collegeCode
    ? await db.user.findMany({
        where: { collegeCodeRef: collegeCode, role: "STUDENT" },
        include: {
          targetCareer: true,
          assessments: { orderBy: { takenAt: "desc" } },
          problemProgress: { select: { done: true } },
        },
        orderBy: { name: "asc" },
      })
    : [];

  const rows = students.map((s) => {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    return {
      name: s.name,
      email: s.email,
      stage: s.stage ? STAGE_LABELS[s.stage as keyof typeof STAGE_LABELS] : "",
      career: s.targetCareer?.title ?? "Not chosen",
      hasAssessment: agg.hasAssessment ? "Yes" : "No",
      avgScore: agg.avgCurrent,
      targetScore: agg.avgTarget,
      readinessPct: agg.readinessPct,
      status: agg.status,
      problemsSolved: agg.solvedProblems,
    };
  });

  // Collect all skills for extra columns
  const skillSet = new Set<string>();
  for (const s of students) {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    agg.skillGaps.forEach((g) => skillSet.add(g.skill));
  }
  const skillCols = Array.from(skillSet);

  const skillScoresById = students.map((s) => {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    const map: Record<string, number> = {};
    agg.skillGaps.forEach((g) => (map[g.skill] = g.current));
    return map;
  });

  const header = [
    "Name",
    "Email",
    "Stage",
    "Target Career",
    "Assessment Taken",
    "Avg Score",
    "Target Score",
    "Readiness %",
    "Status",
    "Problems Solved",
    ...skillCols,
  ];

  const lines = [header.map(csvEscape).join(",")];
  rows.forEach((r, i) => {
    const row = [
      r.name,
      r.email,
      r.stage,
      r.career,
      r.hasAssessment,
      r.avgScore,
      r.targetScore,
      r.readinessPct,
      r.status,
      r.problemsSolved,
      ...skillCols.map((sk) => skillScoresById[i][sk] ?? ""),
    ];
    lines.push(row.map(csvEscape).join(","));
  });

  const csv = lines.join("\n");
  const filename = `cursus-batch-${collegeCode || "export"}.csv`;

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}
