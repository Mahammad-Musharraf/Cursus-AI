import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS, READY_THRESHOLD, AT_RISK_THRESHOLD } from "@/lib/constants";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "COLLEGE") return forbidden();

  const college = await db.user.findUnique({ where: { id: user.id } });
  if (!college?.collegeCode) {
    return json({
      collegeCode: null,
      collegeName: college?.collegeName ?? null,
      batch: { total: 0, ready: 0, onTrack: 0, atRisk: 0, readinessPct: 0 },
      heatmap: [],
      atRisk: [],
      students: [],
      skills: [],
    });
  }

  const students = await db.user.findMany({
    where: { collegeCodeRef: college.collegeCode, role: "STUDENT" },
    include: {
      targetCareer: true,
      assessments: { orderBy: { takenAt: "desc" } },
      problemProgress: { select: { done: true } },
    },
    orderBy: { name: "asc" },
  });

  const enriched = students.map((s) => {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    return {
      id: s.id,
      name: s.name,
      email: s.email,
      stage: s.stage,
      stageLabel: s.stage ? STAGE_LABELS[s.stage as keyof typeof STAGE_LABELS] : null,
      careerTitle: s.targetCareer?.title ?? null,
      hasAssessment: agg.hasAssessment,
      avgCurrent: agg.avgCurrent,
      readinessPct: agg.readinessPct,
      status: agg.status,
      solvedProblems: agg.solvedProblems,
      skillGaps: agg.skillGaps,
    };
  });

  const total = enriched.length;
  const ready = enriched.filter((s) => s.status === "ready").length;
  const onTrack = enriched.filter((s) => s.status === "on-track").length;
  const atRiskList = enriched.filter(
    (s) => s.status === "at-risk" || s.status === "no-assessment"
  );
  const atRisk = atRiskList.length;
  const readinessPct =
    total > 0
      ? Math.round(
          enriched.reduce((sum, s) => sum + s.readinessPct, 0) / total
        )
      : 0;

  // Heatmap: average score per skill across students who have that skill
  const skillMap = new Map<string, { sum: number; count: number }>();
  for (const s of enriched) {
    for (const g of s.skillGaps) {
      const prev = skillMap.get(g.skill) ?? { sum: 0, count: 0 };
      prev.sum += g.current;
      prev.count += 1;
      skillMap.set(g.skill, prev);
    }
  }
  const heatmap = Array.from(skillMap.entries())
    .map(([skill, { sum, count }]) => ({
      skill,
      avg: count > 0 ? Math.round(sum / count) : 0,
      students: count,
    }))
    .sort((a, b) => a.avg - b.avg);

  return json({
    collegeCode: college.collegeCode,
    collegeName: college.collegeName,
    thresholds: { ready: READY_THRESHOLD, atRisk: AT_RISK_THRESHOLD },
    batch: { total, ready, onTrack, atRisk, readinessPct },
    heatmap,
    atRisk: atRiskList.map((s) => ({
      id: s.id,
      name: s.name,
      email: s.email,
      stageLabel: s.stageLabel,
      careerTitle: s.careerTitle,
      avgCurrent: s.avgCurrent,
      readinessPct: s.readinessPct,
      status: s.status,
      solvedProblems: s.solvedProblems,
    })),
    students: enriched.map((s) => ({
      id: s.id,
      name: s.name,
      email: s.email,
      stageLabel: s.stageLabel,
      careerTitle: s.careerTitle,
      hasAssessment: s.hasAssessment,
      avgCurrent: s.avgCurrent,
      readinessPct: s.readinessPct,
      status: s.status,
      solvedProblems: s.solvedProblems,
    })),
    skills: heatmap.map((h) => h.skill),
  });
}
