import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS } from "@/lib/constants";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "COLLEGE") return forbidden();

  const college = await db.user.findUnique({ where: { id: user.id } });
  const collegeCode = college?.collegeCode ?? null;

  const students = collegeCode
    ? await db.user.findMany({
        where: { collegeCodeRef: collegeCode, role: "STUDENT" },
        include: {
          targetCareer: true,
          assessments: { orderBy: { takenAt: "desc" } },
          problemProgress: { select: { done: true } },
        },
        orderBy: { name: "asc" },
      })
    : [];

  const detailed = students.map((s) => {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    return {
      id: s.id,
      name: s.name,
      email: s.email,
      stageLabel: s.stage ? STAGE_LABELS[s.stage as keyof typeof STAGE_LABELS] : null,
      careerTitle: s.targetCareer?.title ?? "Not chosen",
      hasAssessment: agg.hasAssessment,
      avgCurrent: agg.avgCurrent,
      readinessPct: agg.readinessPct,
      status: agg.status,
      solvedProblems: agg.solvedProblems,
      totalProblems: agg.totalProblems,
      skills: agg.skillGaps.map((g) => ({
        skill: g.skill,
        current: g.current,
        target: g.target,
        gap: g.gap,
      })),
    };
  });

  return json({ collegeCode, students: detailed });
}
