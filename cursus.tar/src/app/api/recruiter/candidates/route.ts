import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS } from "@/lib/constants";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim().toLowerCase() || "";
  const minAvg = Number(searchParams.get("minAvg") || 0);
  const careerId = searchParams.get("careerId") || undefined;
  const stage = searchParams.get("stage") || undefined;
  const skill = searchParams.get("skill") || undefined;
  const minSkillScore = Number(searchParams.get("minSkillScore") || 0);
  const sort = searchParams.get("sort") || "avg"; // avg | name | recent

  // Candidates = students who have at least one assessment
  const students = await db.user.findMany({
    where: {
      role: "STUDENT",
      ...(careerId ? { targetCareerId: careerId } : {}),
      ...(stage ? { stage } : {}),
      assessments: { some: {} },
    },
    include: {
      targetCareer: true,
      assessments: { orderBy: { takenAt: "desc" } },
      problemProgress: { select: { done: true } },
      shortlistsAsStudent: { where: { recruiterId: user.id }, select: { id: true } },
    },
    orderBy: { createdAt: sort === "recent" ? "desc" : "asc" },
  });

  let candidates = students.map((s) => {
    const agg = studentAggregates(s as unknown as StudentWithRelations);
    return {
      id: s.id,
      name: s.name,
      email: s.email,
      stageLabel: s.stage ? STAGE_LABELS[s.stage as keyof typeof STAGE_LABELS] : null,
      careerTitle: s.targetCareer?.title ?? null,
      careerId: s.targetCareerId,
      avgCurrent: agg.avgCurrent,
      readinessPct: agg.readinessPct,
      status: agg.status,
      solvedProblems: agg.solvedProblems,
      shortlisted: s.shortlistsAsStudent.length > 0,
      skills: agg.skillGaps.map((g) => ({
        skill: g.skill,
        current: g.current,
        target: g.target,
      })),
    };
  });

  if (q) {
    candidates = candidates.filter(
      (c) =>
        c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)
    );
  }
  if (minAvg > 0) {
    candidates = candidates.filter((c) => c.avgCurrent >= minAvg);
  }
  if (skill && minSkillScore > 0) {
    candidates = candidates.filter((c) =>
      c.skills.some((s) => s.skill === skill && s.current >= minSkillScore)
    );
  }

  if (sort === "avg") {
    candidates.sort((a, b) => b.avgCurrent - a.avgCurrent);
  } else if (sort === "name") {
    candidates.sort((a, b) => a.name.localeCompare(b.name));
  }

  return json({ candidates, recruiterId: user.id });
}
