import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
  notFound,
} from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";
import { STAGE_LABELS } from "@/lib/constants";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const shortlists = await db.shortlist.findMany({
    where: { recruiterId: user.id },
    orderBy: { createdAt: "desc" },
    include: {
      student: {
        include: {
          targetCareer: true,
          assessments: { orderBy: { takenAt: "desc" } },
          problemProgress: { select: { done: true } },
        },
      },
    },
  });

  const candidates = shortlists.map((sl) => {
    const agg = studentAggregates(
      sl.student as unknown as StudentWithRelations
    );
    return {
      id: sl.student.id,
      name: sl.student.name,
      email: sl.student.email,
      stageLabel: sl.student.stage
        ? STAGE_LABELS[sl.student.stage as keyof typeof STAGE_LABELS]
        : null,
      careerTitle: sl.student.targetCareer?.title ?? null,
      avgCurrent: agg.avgCurrent,
      readinessPct: agg.readinessPct,
      status: agg.status,
      solvedProblems: agg.solvedProblems,
      note: sl.note,
      shortlistedAt: sl.createdAt,
      skills: agg.skillGaps.map((g) => ({
        skill: g.skill,
        current: g.current,
        target: g.target,
      })),
    };
  });

  return json({ candidates });
}

const AddSchema = z.object({
  studentId: z.string().min(1),
  note: z.string().trim().max(280).optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const parsed = await parseBody(AddSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { studentId, note } = parsed.data;

  const student = await db.user.findUnique({ where: { id: studentId } });
  if (!student || student.role !== "STUDENT") return notFound("Candidate not found.");

  await db.shortlist.upsert({
    where: { recruiterId_studentId: { recruiterId: user.id, studentId } },
    create: { recruiterId: user.id, studentId, note },
    update: { note },
  });

  return json({ ok: true, shortlisted: true });
}

export async function DELETE(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { searchParams } = new URL(req.url);
  const studentId = searchParams.get("studentId");
  if (!studentId) return errorResponse("studentId is required.", 400);

  await db.shortlist.deleteMany({
    where: { recruiterId: user.id, studentId },
  });

  return json({ ok: true, shortlisted: false });
}
