import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden, notFound, errorResponse } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { id } = await params;
  const job = await db.job.findFirst({
    where: { id, recruiterId: user.id },
    include: {
      applications: {
        include: {
          student: {
            include: {
              targetCareer: { select: { id: true, title: true, requiredSkills: true } },
              assessments: { orderBy: { takenAt: "desc" }, take: 1, select: { scores: true, takenAt: true } },
              problemProgress: { select: { done: true } },
            },
          },
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });
  if (!job) return notFound("Job not found.");

  return json({ job });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { id } = await params;
  const job = await db.job.findFirst({ where: { id, recruiterId: user.id } });
  if (!job) return notFound("Job not found.");

  await db.job.delete({ where: { id } });
  return json({ ok: true });
}
