import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const jobs = await db.job.findMany({
    where: { recruiterId: user.id },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { applications: true } } },
  });

  return json({
    jobs: jobs.map((j) => ({
      ...j,
      applicationCount: j._count.applications,
    })),
  });
}

const CreateJobSchema = z.object({
  title: z.string().trim().min(2),
  description: z.string().trim().min(10),
  location: z.string().trim().default("Remote"),
  jobType: z.enum(["FULL_TIME", "INTERN", "CONTRACT"]).default("FULL_TIME"),
  requiredSkills: z.string(),
  minAvgScore: z.number().int().min(0).max(100).default(0),
  packageLpa: z.string().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const parsed = await parseBody(CreateJobSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }

  const job = await db.job.create({
    data: { ...parsed.data, recruiterId: user.id },
  });

  return json({ ok: true, job }, 201);
}
