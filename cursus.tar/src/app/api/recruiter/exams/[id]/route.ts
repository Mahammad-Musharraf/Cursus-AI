import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden, notFound, errorResponse } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { id } = await params;
  const exam = await db.exam.findFirst({
    where: { id, recruiterId: user.id },
    include: {
      questions: { orderBy: { createdAt: "asc" } },
      attempts: {
        include: { student: { select: { id: true, name: true, email: true } } },
        orderBy: { startedAt: "desc" },
      },
    },
  });
  if (!exam) return notFound("Exam not found.");

  return json({ exam });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { id } = await params;
  const exam = await db.exam.findFirst({ where: { id, recruiterId: user.id } });
  if (!exam) return notFound("Exam not found.");

  await db.exam.delete({ where: { id } });
  return json({ ok: true });
}

export async function PATCH(req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const { isActive } = body as { isActive?: boolean };
  if (typeof isActive !== "boolean")
    return errorResponse("isActive boolean required.", 422);

  const exam = await db.exam.findFirst({ where: { id, recruiterId: user.id } });
  if (!exam) return notFound("Exam not found.");

  await db.exam.update({ where: { id }, data: { isActive } });
  return json({ ok: true });
}
