import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const exams = await db.exam.findMany({
    where: { recruiterId: user.id },
    orderBy: { createdAt: "desc" },
    include: {
      _count: { select: { questions: true, attempts: true } },
      job: { select: { id: true, title: true } },
    },
  });

  return json({
    exams: exams.map((e) => ({
      id: e.id,
      title: e.title,
      description: e.description,
      durationMin: e.durationMin,
      questionsToPick: e.questionsToPick,
      passScorePct: e.passScorePct,
      isActive: e.isActive,
      jobId: e.jobId,
      jobTitle: e.job?.title ?? null,
      questionCount: e._count.questions,
      attemptCount: e._count.attempts,
      createdAt: e.createdAt,
    })),
  });
}

const QuestionInput = z.object({
  type: z.enum(["MCQ", "SHORT_ANSWER", "CODING"]),
  prompt: z.string().min(2),
  options: z.array(z.string()).optional(), // for MCQ
  answer: z.string(), // correct option index (MCQ) or expected text
  skillSlug: z.string().optional(),
  difficulty: z.enum(["EASY", "MEDIUM", "HARD"]).default("MEDIUM"),
  points: z.number().int().min(1).max(10).default(1),
});

const CreateExamSchema = z.object({
  title: z.string().trim().min(2),
  description: z.string().trim().min(2),
  durationMin: z.number().int().min(5).max(180).default(60),
  questionsToPick: z.number().int().min(1).max(50).default(10),
  passScorePct: z.number().int().min(0).max(100).default(60),
  jobId: z.string().optional(),
  questions: z.array(QuestionInput).min(1, "Add at least one question."),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const parsed = await parseBody(CreateExamSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { questions, ...examData } = parsed.data;

  const exam = await db.exam.create({
    data: {
      ...examData,
      recruiterId: user.id,
      questions: {
        create: questions.map((q) => ({
          type: q.type,
          prompt: q.prompt,
          options: q.options ?? null,
          answer: q.answer,
          skillSlug: q.skillSlug ?? null,
          difficulty: q.difficulty,
          points: q.points,
        })),
      },
    },
    include: { questions: true },
  });

  return json({ ok: true, exam }, 201);
}
