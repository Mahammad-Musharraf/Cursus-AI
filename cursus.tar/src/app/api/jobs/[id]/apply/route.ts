import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  notFound,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const ApplySchema = z.object({
  coverNote: z.string().trim().max(500).optional(),
});

// Student applies to a job
export async function POST(req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const { id } = await params;
  const parsed = await parseBody(ApplySchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }

  const job = await db.job.findUnique({ where: { id } });
  if (!job || !job.isActive) return notFound("Job not found.");

  // Check if already applied
  const existing = await db.jobApplication.findUnique({
    where: { jobId_studentId: { jobId: id, studentId: user.id } },
  });
  if (existing) return errorResponse("You've already applied to this job.", 409);

  const application = await db.jobApplication.create({
    data: {
      jobId: id,
      studentId: user.id,
      coverNote: parsed.data.coverNote ?? null,
      stage: "APPLIED",
    },
  });

  // Notify the recruiter
  await db.notification.create({
    data: {
      userId: job.recruiterId,
      type: "info",
      title: "New job application",
      body: `A student applied to "${job.title}".`,
      link: "/dashboard/recruiter/jobs",
    },
  });

  return json({ ok: true, application }, 201);
}
