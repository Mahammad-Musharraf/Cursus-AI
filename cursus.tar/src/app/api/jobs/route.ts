import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";

// Students browse all active jobs
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const jobs = await db.job.findMany({
    where: { isActive: true },
    orderBy: { createdAt: "desc" },
    include: {
      recruiter: { select: { companyName: true, name: true } },
    },
  });

  // Get student's applications
  const applications = await db.jobApplication.findMany({
    where: { studentId: user.id },
    select: { jobId: true, stage: true },
  });
  const appMap = new Map(applications.map((a) => [a.jobId, a.stage]));

  // Compute student avg for eligibility check
  const student = await db.user.findUnique({
    where: { id: user.id },
    include: {
      targetCareer: true,
      assessments: { orderBy: { takenAt: "desc" }, take: 1 },
      problemProgress: { select: { done: true } },
    },
  });
  const agg = student
    ? studentAggregates(student as unknown as StudentWithRelations)
    : null;
  const studentAvg = agg?.avgCurrent ?? 0;

  return json({
    studentAvg,
    jobs: jobs.map((j) => ({
      id: j.id,
      title: j.title,
      description: j.description,
      location: j.location,
      jobType: j.jobType,
      requiredSkills: j.requiredSkills,
      minAvgScore: j.minAvgScore,
      packageLpa: j.packageLpa,
      companyName: j.recruiter.companyName ?? j.recruiter.name,
      createdAt: j.createdAt,
      hasApplied: appMap.has(j.id),
      applicationStage: appMap.get(j.id) ?? null,
      eligible: studentAvg >= j.minAvgScore,
    })),
  });
}
