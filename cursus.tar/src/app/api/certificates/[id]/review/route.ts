import { z } from "zod";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
  notFound,
} from "@/lib/api";

const ReviewSchema = z.object({
  status: z.enum(["APPROVED", "REJECTED"]),
  reviewerNote: z.string().trim().max(280).optional(),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "COLLEGE") return forbidden();

  const { id } = await params;
  const parsed = await parseBody(ReviewSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }

  const cert = await db.certificate.findUnique({
    where: { id },
    include: { user: { select: { id: true, name: true, collegeCodeRef: true } } },
  });
  if (!cert) return notFound("Certificate not found.");

  // Only the college of the student's batch can review
  const college = await db.user.findUnique({ where: { id: user.id } });
  if (cert.user.collegeCodeRef !== college?.collegeCode) {
    return forbidden();
  }

  const updated = await db.certificate.update({
    where: { id },
    data: {
      status: parsed.data.status,
      reviewerNote: parsed.data.reviewerNote ?? null,
      reviewedById: user.id,
      reviewedAt: new Date(),
    },
  });

  // Notify the student
  await db.notification.create({
    data: {
      userId: cert.user.id,
      type: parsed.data.status === "APPROVED" ? "success" : "warning",
      title:
        parsed.data.status === "APPROVED"
          ? "Certificate approved ✅"
          : "Certificate needs changes",
      body:
        parsed.data.status === "APPROVED"
          ? `Your "${cert.title}" certificate is now verified on your profile.`
          : `Your "${cert.title}" certificate was rejected. Check the reviewer note.`,
      link: "/dashboard/student/certificates",
    },
  });

  return json({ ok: true, certificate: updated });
}
