import { NextRequest } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
} from "@/lib/api";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import { randomBytes } from "crypto";

// Simple in-memory rate limiter for uploads: max 10 uploads per 10 min per user.
const uploadHits = new Map<string, number[]>();
function rateLimited(userId: string): boolean {
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const max = 10;
  const hits = (uploadHits.get(userId) ?? []).filter((t) => now - t < windowMs);
  hits.push(now);
  uploadHits.set(userId, hits);
  return hits.length > max;
}

const MAX_SIZE = 8 * 1024 * 1024; // 8MB
const ALLOWED = new Set(["application/pdf", "image/png", "image/jpeg", "image/webp"]);

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  // Students see their own; colleges see their batch's pending.
  if (user.role === "STUDENT") {
    const certs = await db.certificate.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
    });
    return json({ certificates: certs });
  }
  if (user.role === "COLLEGE") {
    const college = await db.user.findUnique({ where: { id: user.id } });
    const students = await db.user.findMany({
      where: { collegeCodeRef: college?.collegeCode ?? "__none__", role: "STUDENT" },
      select: { id: true },
    });
    const certs = await db.certificate.findMany({
      where: { userId: { in: students.map((s) => s.id) } },
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: "desc" },
    });
    return json({ certificates: certs });
  }
  return forbidden();
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  if (rateLimited(user.id)) {
    return errorResponse("Too many uploads. Please wait a few minutes.", 429);
  }

  const form = await req.formData();
  const title = (form.get("title") as string)?.trim();
  const issuer = (form.get("issuer") as string)?.trim();
  const issuedDate = (form.get("issuedDate") as string)?.trim();
  const credentialUrl = (form.get("credentialUrl") as string)?.trim() || null;
  const file = form.get("file") as File | null;

  if (!title || title.length < 2)
    return errorResponse("Title is required.", 422);
  if (!issuer || issuer.length < 2)
    return errorResponse("Issuer is required.", 422);
  if (!issuedDate || !/^\d{4}-\d{2}-\d{2}$/.test(issuedDate))
    return errorResponse("Issued date must be YYYY-MM-DD.", 422);
  if (!file || file.size === 0)
    return errorResponse("A file is required.", 422);
  if (file.size > MAX_SIZE)
    return errorResponse("File too large (max 8MB).", 422);

  const type = file.type || "application/octet-stream";
  if (!ALLOWED.has(type)) {
    return errorResponse("Only PDF, PNG, JPG or WEBP files are allowed.", 422);
  }

  const ext = type.includes("pdf") ? "pdf" : type.includes("png") ? "png" : type.includes("webp") ? "webp" : "jpg";
  const dir = path.join(process.cwd(), "public", "uploads", "certificates");
  if (!existsSync(dir)) await mkdir(dir, { recursive: true });
  const filename = `${randomBytes(8).toString("hex")}-${Date.now()}.${ext}`;
  const filepath = path.join(dir, filename);
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(filepath, buffer);

  const cert = await db.certificate.create({
    data: {
      userId: user.id,
      title,
      issuer,
      issuedDate,
      credentialUrl,
      filePath: `/uploads/certificates/${filename}`,
      fileType: ext,
      fileSizeKb: Math.round(file.size / 1024),
      status: "PENDING",
    },
  });

  // Notify the student's college (if any) about the pending cert
  const student = await db.user.findUnique({ where: { id: user.id } });
  if (student?.collegeCodeRef) {
    const college = await db.user.findUnique({
      where: { collegeCode: student.collegeCodeRef },
    });
    if (college) {
      await db.notification.create({
        data: {
          userId: college.id,
          type: "info",
          title: "Certificate needs review",
          body: `${student.name} uploaded "${title}" from ${issuer}.`,
          link: "/dashboard/college",
        },
      });
    }
  }

  return json({ ok: true, certificate: cert }, 201);
}
