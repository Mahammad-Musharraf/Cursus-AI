import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden } from "@/lib/api";

// List all active exams available to students
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const exams = await db.exam.findMany({
    where: { isActive: true },
    orderBy: { createdAt: "desc" },
    include: {
      recruiter: { select: { companyName: true, name: true } },
      job: { select: { title: true } },
      _count: { select: { questions: true } },
    },
  });

  // Include the student's attempt status for each
  const attempts = await db.examAttempt.findMany({
    where: { studentId: user.id, examId: { in: exams.map((e) => e.id) } },
    select: {
      examId: true,
      submittedAt: true,
      scorePct: true,
      passed: true,
    },
  });
  const attemptMap = new Map(attempts.map((a) => [a.examId, a]));

  return json({
    exams: exams.map((e) => {
      const att = attemptMap.get(e.id);
      return {
        id: e.id,
        title: e.title,
        description: e.description,
        durationMin: e.durationMin,
        questionsToPick: e.questionsToPick,
        passScorePct: e.passScorePct,
        companyName: e.recruiter.companyName ?? e.recruiter.name,
        jobTitle: e.job?.title ?? null,
        questionCount: e._count.questions,
        hasAttempted: !!att,
        submitted: !!att?.submittedAt,
        scorePct: att?.scorePct ?? null,
        passed: att?.passed ?? null,
      };
    }),
  });
}
