import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  notFound,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

const SubmitSchema = z.object({
  attemptId: z.string(),
  responses: z.array(
    z.object({
      questionId: z.string(),
      answer: z.string(),
    })
  ),
  timeSpentSec: z.number().int().min(0).default(0),
  tabSwitches: z.number().int().min(0).default(0),
});

// Auto-grade MCQ + SHORT_ANSWER; CODING is marked pending manual review.
export async function POST(req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const { id } = await params;
  const parsed = await parseBody(SubmitSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { attemptId, responses, timeSpentSec, tabSwitches } = parsed.data;

  const exam = await db.exam.findUnique({
    where: { id },
    include: { questions: true },
  });
  if (!exam) return notFound("Exam not found.");

  const attempt = await db.examAttempt.findUnique({
    where: { id: attemptId },
  });
  if (!attempt || attempt.studentId !== user.id || attempt.examId !== id) {
    return errorResponse("Invalid attempt.", 403);
  }
  if (attempt.submittedAt) {
    return errorResponse("Exam already submitted.", 409);
  }

  // Grade each response
  const gradedResponses = responses.map((r) => {
    const question = exam.questions.find((q) => q.id === r.questionId);
    if (!question) return { ...r, correct: false };
    let correct = false;
    if (question.type === "MCQ") {
      correct = r.answer.trim() === question.answer.trim();
    } else if (question.type === "SHORT_ANSWER") {
      // Case-insensitive trimmed match
      correct =
        r.answer.trim().toLowerCase() === question.answer.trim().toLowerCase();
    }
    // CODING: not auto-graded (correct stays false / pending)
    return { ...r, correct };
  });

  // Compute score (only auto-gradable questions count toward score)
  const autoGradable = gradedResponses.filter((r) => {
    const q = exam.questions.find((x) => x.id === r.questionId);
    return q && q.type !== "CODING";
  });
  const totalPoints = autoGradable.reduce((sum, r) => {
    const q = exam.questions.find((x) => x.id === r.questionId);
    return sum + (q?.points ?? 1);
  }, 0);
  const earnedPoints = autoGradable
    .filter((r) => r.correct)
    .reduce((sum, r) => {
      const q = exam.questions.find((x) => x.id === r.questionId);
      return sum + (q?.points ?? 1);
    }, 0);
  const scorePct =
    totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
  const passed = scorePct >= exam.passScorePct;

  const updated = await db.examAttempt.update({
    where: { id: attemptId },
    data: {
      submittedAt: new Date(),
      timeSpentSec,
      tabSwitches,
      responses: gradedResponses as unknown as object,
      scorePct,
      passed,
    },
  });

  // Notify the student
  await db.notification.create({
    data: {
      userId: user.id,
      type: passed ? "success" : "warning",
      title: passed ? "Exam passed! 🎉" : "Exam result",
      body: `You scored ${scorePct}% on "${exam.title}". ${passed ? "You passed!" : "Below the pass threshold."}`,
      link: `/dashboard/student/exams`,
    },
  });

  return json({
    ok: true,
    scorePct,
    passed,
    totalQuestions: responses.length,
    correctCount: autoGradable.filter((r) => r.correct).length,
    timeSpentSec,
    submittedAt: updated.submittedAt,
  });
}
