import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden, notFound } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// Get a student's result for an exam (after submission)
export async function GET(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();

  const { id } = await params;

  const exam = await db.exam.findUnique({
    where: { id },
    include: { questions: true },
  });
  if (!exam) return notFound("Exam not found.");

  if (user.role === "STUDENT") {
    const attempt = await db.examAttempt.findUnique({
      where: { examId_studentId: { examId: id, studentId: user.id } },
    });
    if (!attempt) return notFound("No attempt found.");
    return json({ exam: { id: exam.id, title: exam.title, passScorePct: exam.passScorePct }, attempt });
  }

  // Recruiter: see all attempts for their exam
  if (user.role === "RECRUITER") {
    if (exam.recruiterId !== user.id) return forbidden();
    const attempts = await db.examAttempt.findMany({
      where: { examId: id },
      include: { student: { select: { id: true, name: true, email: true } } },
      orderBy: { startedAt: "desc" },
    });
    return json({ exam, attempts });
  }

  return forbidden();
}
