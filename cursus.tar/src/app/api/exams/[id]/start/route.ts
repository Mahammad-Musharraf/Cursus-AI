import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden, notFound, errorResponse } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// Student starts an exam: returns a randomized subset of questions.
export async function POST(_req: Request, { params }: Ctx) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const { id } = await params;
  const exam = await db.exam.findUnique({
    where: { id },
    include: { questions: true },
  });
  if (!exam || !exam.isActive) return notFound("Exam not available.");

  // Check for existing attempt (one attempt per exam)
  const existing = await db.examAttempt.findUnique({
    where: { examId_studentId: { examId: id, studentId: user.id } },
  });
  if (existing) {
    return errorResponse("You've already attempted this exam.", 409);
  }

  // Randomize question order and pick the configured count
  const shuffled = [...exam.questions].sort(() => Math.random() - 0.5);
  const picked = shuffled.slice(0, Math.min(exam.questionsToPick, shuffled.length));

  // Create the attempt
  const attempt = await db.examAttempt.create({
    data: {
      examId: id,
      studentId: user.id,
    },
  });

  // Return questions WITHOUT answers
  return json({
    attemptId: attempt.id,
    exam: {
      id: exam.id,
      title: exam.title,
      durationMin: exam.durationMin,
      passScorePct: exam.passScorePct,
    },
    questions: picked.map((q) => ({
      id: q.id,
      type: q.type,
      prompt: q.prompt,
      options: q.options as string[] | null,
      skillSlug: q.skillSlug,
      difficulty: q.difficulty,
      points: q.points,
    })),
    totalQuestions: picked.length,
  });
}
