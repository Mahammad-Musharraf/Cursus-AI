import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";

const ProgressSchema = z.object({
  problemId: z.string().min(1),
  done: z.boolean(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const parsed = await parseBody(ProgressSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { problemId, done } = parsed.data;

  const problem = await db.problem.findUnique({ where: { id: problemId } });
  if (!problem) return errorResponse("Problem not found.", 404);

  await db.problemProgress.upsert({
    where: { userId_problemId: { userId: user.id, problemId } },
    create: {
      userId: user.id,
      problemId,
      done,
      completedAt: done ? new Date() : null,
    },
    update: {
      done,
      completedAt: done ? new Date() : null,
    },
  });

  // Return updated counts for the career
  const total = await db.problemProgress.count({
    where: { userId: user.id },
  });
  const solved = await db.problemProgress.count({
    where: { userId: user.id, done: true },
  });

  return json({ ok: true, solved, total });
}
