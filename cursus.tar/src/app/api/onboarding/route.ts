import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { json, unauthorized, forbidden, parseBody, zodErrors, errorResponse } from "@/lib/api";

const OnboardingSchema = z.object({
  stage: z.enum(["AFTER_10TH", "AFTER_12TH", "IN_BTECH"]),
  targetCareerId: z.string().min(1),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const parsed = await parseBody(OnboardingSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { stage, targetCareerId } = parsed.data;

  const career = await db.career.findUnique({ where: { id: targetCareerId } });
  if (!career) return errorResponse("Career not found.", 404);

  await db.user.update({
    where: { id: user.id },
    data: { stage, targetCareerId },
  });

  return json({ ok: true });
}
