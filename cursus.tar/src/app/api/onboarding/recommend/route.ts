import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";
import {
  recommendCareers,
  saveOnboardingResult,
  type Answer,
} from "@/lib/onboarding-engine";

const RecommendSchema = z.object({
  answers: z
    .array(
      z.object({
        questionId: z.string(),
        question: z.string(),
        answer: z.string(),
        optionIndex: z.number().int().min(0),
      })
    )
    .min(6, "Answer at least the core questions."),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const parsed = await parseBody(RecommendSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }

  const recommendations = recommendCareers(parsed.data.answers as Answer[]);

  // Persist the result (unconfirmed until the student picks a path).
  const { result } = await saveOnboardingResult(
    user.id,
    parsed.data.answers as Answer[],
    recommendations
  );

  // Send a notification
  await db.notification.create({
    data: {
      userId: user.id,
      type: "success",
      title: "Career recommendations ready",
      body: `We matched you with ${recommendations[0]?.title} at ${recommendations[0]?.matchPct}% and more.`,
      link: "/onboarding",
    },
  });

  return json({ recommendations, resultId: result.id }, 201);
}
