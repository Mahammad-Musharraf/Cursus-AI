import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";
import { saveOnboardingResult, getLatestOnboarding } from "@/lib/onboarding-engine";
import { CAREERS } from "@/lib/careers-data";

const ChooseSchema = z.object({
  careerSlug: z.string().min(1),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const parsed = await parseBody(ChooseSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }

  const careerSlug = parsed.data.careerSlug;
  const valid = CAREERS.some((c) => c.slug === careerSlug);
  if (!valid) return errorResponse("Unknown career path.", 400);

  // Use the latest onboarding result's answers + recommendations
  const latest = await getLatestOnboarding(user.id);
  if (!latest) {
    return errorResponse("Complete the onboarding conversation first.", 400);
  }

  await saveOnboardingResult(user.id, latest.answers, latest.recommendations, careerSlug);

  // Notify
  const career = await db.career.findUnique({
    where: { slug: careerSlug },
    select: { title: true },
  });
  await db.notification.create({
    data: {
      userId: user.id,
      type: "success",
      title: "Career path confirmed",
      body: `You're now on the ${career?.title ?? careerSlug} track. Take your skill assessment next.`,
      link: "/dashboard/student/assessment",
    },
  });

  return json({ ok: true, careerSlug });
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  const latest = await getLatestOnboarding(user.id);
  return json({ onboarding: latest });
}
