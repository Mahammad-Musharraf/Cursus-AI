import { json, unauthorized, forbidden } from "@/lib/api";
import { getCurrentUser } from "@/lib/session";
import { ONBOARDING_QUESTIONS } from "@/lib/onboarding-engine";

export async function GET() {
  // questions are public-ish but we still require a session
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "STUDENT") return forbidden();

  return json({
    questions: ONBOARDING_QUESTIONS.map((q) => ({
      id: q.id,
      prompt: q.prompt,
      helpText: q.helpText,
      options: q.options.map((o) => ({ label: o.label })),
    })),
  });
}
