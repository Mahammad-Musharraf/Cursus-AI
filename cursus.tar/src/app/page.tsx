import Link from "next/link";
import {
  ArrowRight,
  Target,
  Map,
  ClipboardCheck,
  Code2,
  Sparkles,
  Users,
  Download,
  Bookmark,
  ShieldCheck,
  TrendingUp,
  GraduationCap,
  Building2,
  Briefcase,
} from "lucide-react";
import { PublicHeader } from "@/components/public-header";
import { SiteFooter } from "@/components/site-footer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const STEPS = [
  {
    icon: Target,
    title: "Pick your stage & target career",
    desc: "Tell us where you are — after 10th, 12th, or in B.Tech — and the role you want.",
  },
  {
    icon: ClipboardCheck,
    title: "Take a skill assessment",
    desc: "Rate your current skills. We save it to your profile and compute your gaps.",
  },
  {
    icon: Map,
    title: "Get a personalized roadmap",
    desc: "A clear, milestone-by-milestone path from where you are to placement-ready.",
  },
  {
    icon: Code2,
    title: "Practice & talk to your AI mentor",
    desc: "Solve curated problems and chat with an AI that knows your progress.",
  },
];

const ROLES = [
  {
    icon: GraduationCap,
    title: "For Students",
    points: [
      "Skill-gap analysis & roadmap",
      "Curated problems from LeetCode, GFG, CodeChef",
      "AI mentor that suggests your next step",
    ],
    cta: "Join as a student",
    href: "/signup",
  },
  {
    icon: Building2,
    title: "For College T&P",
    points: [
      "Batch readiness dashboard",
      "Skill heatmap & at-risk students",
      "One-click CSV export",
    ],
    cta: "Set up your college",
    href: "/signup",
  },
  {
    icon: Briefcase,
    title: "For Recruiters",
    points: [
      "Filter & rank verified candidates",
      "Shortlist by real skill scores",
      "Skip the resume noise",
    ],
    cta: "Find candidates",
    href: "/signup",
  },
];

const FEATURES = [
  { icon: ShieldCheck, title: "Verified skill scores", desc: "Every assessment is saved to a real database — no fake claims." },
  { icon: TrendingUp, title: "Real progress tracking", desc: "Mark problems done and watch your readiness climb." },
  { icon: Sparkles, title: "AI mentor", desc: "A server-side LLM reads your data and suggests the next step." },
  { icon: Users, title: "Placement intelligence", desc: "Colleges see batch readiness; recruiters see ranked talent." },
  { icon: Download, title: "Export-ready reports", desc: "CSV exports computed live from student records." },
  { icon: Bookmark, title: "Shortlist talent", desc: "Recruiters shortlist candidates, saved to the database." },
];

export default function HomePage() {
  return (
    <div className="flex min-h-svh flex-col bg-background">
      <PublicHeader />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(60% 60% at 50% 0%, oklch(0.45 0.18 264 / 0.10), transparent 70%)",
          }}
        />
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <Badge variant="secondary" className="mb-4 gap-1.5">
              <Sparkles className="size-3.5 text-primary" />
              AI career-to-placement platform
            </Badge>
            <h1 className="text-4xl font-semibold tracking-tight text-foreground sm:text-6xl">
              Forge a clear path from{" "}
              <span className="text-primary">campus to career.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
              Cursus AI helps engineering students find their skill gaps, follow a
              personalized roadmap, practice with curated problems, and get mentored
              by an AI that knows their progress.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link
                href="/signup"
                className="inline-flex h-11 items-center gap-2 rounded-md bg-primary px-6 text-sm font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary/90"
              >
                Get started free
                <ArrowRight className="size-4" />
              </Link>
              <Link
                href="/login"
                className="inline-flex h-11 items-center rounded-md border border-border bg-background px-6 text-sm font-medium text-foreground transition-colors hover:bg-secondary/60"
              >
                Sign in
              </Link>
            </div>
          </div>

          {/* Steps preview */}
          <div id="how-it-works" className="mx-auto mt-20 grid max-w-5xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((s, i) => {
              const Icon = s.icon;
              return (
                <Card key={s.title} className="relative">
                  <CardContent className="p-5">
                    <div className="mb-3 flex items-center justify-between">
                      <span className="inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Icon className="size-4" />
                      </span>
                      <span className="text-xs font-medium text-muted-foreground">
                        Step {i + 1}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-foreground">{s.title}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Roles */}
      <section id="roles" className="border-b border-border bg-secondary/30">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
              One platform, three ways to win
            </h2>
            <p className="mt-3 text-muted-foreground">
              Built for students, college placement cells, and recruiters alike.
            </p>
          </div>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {ROLES.map((r) => {
              const Icon = r.icon;
              return (
                <Card key={r.title} className="flex flex-col">
                  <CardContent className="flex flex-1 flex-col p-6">
                    <span className="mb-4 inline-flex size-11 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm">
                      <Icon className="size-5" />
                    </span>
                    <h3 className="text-lg font-semibold">{r.title}</h3>
                    <ul className="mt-4 flex-1 space-y-2 text-sm text-muted-foreground">
                      {r.points.map((p) => (
                        <li key={p} className="flex items-start gap-2">
                          <span className="mt-1.5 inline-block size-1.5 shrink-0 rounded-full bg-primary" />
                          {p}
                        </li>
                      ))}
                    </ul>
                    <Link
                      href={r.href}
                      className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                    >
                      {r.cta}
                      <ArrowRight className="size-4" />
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            Everything wired to a real backend
          </h2>
          <p className="mt-3 text-muted-foreground">
            Every form, button and chart reads from and writes to a validated,
            auth-protected database. No mock data in working flows.
          </p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <div
                key={f.title}
                className="rounded-lg border border-border bg-card p-6 transition-shadow hover:shadow-sm"
              >
                <span className="mb-3 inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="size-4" />
                </span>
                <h3 className="text-base font-semibold">{f.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="overflow-hidden rounded-2xl bg-primary px-8 py-12 text-center text-primary-foreground">
            <h2 className="text-3xl font-semibold tracking-tight">
              Ready to forge your path?
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-primary-foreground/80">
              Create a free account in seconds. Take your first assessment today.
            </p>
            <Link
              href="/signup"
              className="mt-6 inline-flex h-11 items-center gap-2 rounded-md bg-primary-foreground px-6 text-sm font-medium text-primary transition-colors hover:bg-primary-foreground/90"
            >
              Get started
              <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
