"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2, Plus, BriefcaseBusiness, MapPin, Users, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";
import Link from "next/link";

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: string;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  isActive: boolean;
  applicationCount: number;
  createdAt: string;
};

export default function RecruiterJobsPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    location: "Remote",
    jobType: "FULL_TIME",
    requiredSkills: "",
    minAvgScore: 0,
    packageLpa: "",
  });

  async function load() {

    const res = await api<{ jobs: Job[] }>("/api/recruiter/jobs");
    setLoading(false);
    if (res.data) setJobs(res.data.jobs);
    else setError(res.error || "Failed to load jobs");
  }

  useEffect(() => {
    // Inline the initial fetch so setState stays out of the effect body
    // (initial state is loading:true). The standalone load() is used by
    // the retry button as an event handler.
    Promise.resolve().then(() => load());
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const res = await api<{ ok?: boolean; error?: string; fields?: Record<string, string[]> }>(
      "/api/recruiter/jobs",
      {
        method: "POST",
        body: JSON.stringify({
          title: form.title,
          description: form.description,
          location: form.location,
          jobType: form.jobType,
          requiredSkills: form.requiredSkills,
          minAvgScore: Number(form.minAvgScore),
          packageLpa: form.packageLpa || undefined,
        }),
      }
    );
    setSubmitting(false);
    if (res.error) {
      toast.error(res.data?.error || res.error);
      return;
    }
    toast.success("Job posted!");
    setForm({
      title: "",
      description: "",
      location: "Remote",
      jobType: "FULL_TIME",
      requiredSkills: "",
      minAvgScore: 0,
      packageLpa: "",
    });
    setShowForm(false);
    load();
  }

  async function deleteJob(id: string) {
    if (!confirm("Delete this job? This removes all applications too.")) return;
    const res = await api(`/api/recruiter/jobs/${id}`, { method: "DELETE" });
    if (res.error) {
      toast.error(res.error);
      return;
    }
    toast.success("Job deleted");
    setJobs((prev) => prev.filter((j) => j.id !== id));
  }

  if (loading) return <><PageHeader title="Jobs" description="Post openings and track applicants." /><LoadingState /></>;
  if (error) return <><PageHeader title="Jobs" /><ErrorState message={error} action={<Button onClick={load}>Try again</Button>} /></>;

  return (
    <>
      <PageHeader title="Jobs" description="Post openings and track applicants.">
        <Button onClick={() => setShowForm((v) => !v)}>
          {showForm ? "Cancel" : <><Plus className="size-4" /> Post a job</>}
        </Button>
      </PageHeader>

      {showForm && (
        <Card className="mb-6">
          <CardContent className="p-5">
            <h3 className="mb-4 text-sm font-semibold">New job posting</h3>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="title">Job title</Label>
                  <Input id="title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Backend Engineer" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Remote / Bengaluru" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" required value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Describe the role, responsibilities and what you're looking for." rows={3} />
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label>Job type</Label>
                  <Select value={form.jobType} onValueChange={(v) => setForm({ ...form, jobType: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FULL_TIME">Full-time</SelectItem>
                      <SelectItem value="INTERN">Internship</SelectItem>
                      <SelectItem value="CONTRACT">Contract</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="minAvgScore">Min. avg score</Label>
                  <Input id="minAvgScore" type="number" min={0} max={100} value={form.minAvgScore} onChange={(e) => setForm({ ...form, minAvgScore: Number(e.target.value) })} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="packageLpa">Package (optional)</Label>
                  <Input id="packageLpa" value={form.packageLpa} onChange={(e) => setForm({ ...form, packageLpa: e.target.value })} placeholder="₹8–12 LPA" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="requiredSkills">Required skills</Label>
                <Input id="requiredSkills" required value={form.requiredSkills} onChange={(e) => setForm({ ...form, requiredSkills: e.target.value })} placeholder="Data Structures, Algorithms, DBMS" />
                <p className="text-xs text-muted-foreground">Comma-separated skills.</p>
              </div>
              <Button type="submit" disabled={submitting}>
                {submitting && <Loader2 className="size-4 animate-spin" />}
                Post job
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {jobs.length === 0 ? (
        <EmptyState
          icon={BriefcaseBusiness}
          title="No jobs posted yet"
          description="Post your first job to start receiving applications."
          action={<Button onClick={() => setShowForm(true)}><Plus className="size-4" /> Post a job</Button>}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {jobs.map((job) => (
            <Card key={job.id} className="flex flex-col">
              <CardContent className="flex flex-1 flex-col p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <Link href={`/dashboard/recruiter/jobs/${job.id}`} className="hover:underline">
                      <h3 className="text-base font-semibold">{job.title}</h3>
                    </Link>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><MapPin className="size-3" />{job.location}</span>
                      <Badge variant="outline" className="font-normal">{job.jobType.replace("_", " ")}</Badge>
                      {job.isActive ? <Badge variant="secondary" className="font-normal">Active</Badge> : <Badge variant="outline" className="font-normal">Inactive</Badge>}
                    </div>
                  </div>
                  <button onClick={() => deleteJob(job.id)} className="text-muted-foreground hover:text-destructive" aria-label="Delete">
                    <Trash2 className="size-4" />
                  </button>
                </div>
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{job.description}</p>
                <div className="mt-3 flex flex-wrap gap-1">
                  {job.requiredSkills.split(",").filter(Boolean).map((s) => (
                    <Badge key={s} variant="secondary" className="font-normal">{s.trim()}</Badge>
                  ))}
                </div>
                <div className="mt-auto flex items-center justify-between pt-4 text-sm">
                  <span className="inline-flex items-center gap-1.5 text-muted-foreground"><Users className="size-4" /> {job.applicationCount} applicant{job.applicationCount !== 1 ? "s" : ""}</span>
                  {job.packageLpa && <span className="font-medium text-primary">{job.packageLpa}</span>}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
