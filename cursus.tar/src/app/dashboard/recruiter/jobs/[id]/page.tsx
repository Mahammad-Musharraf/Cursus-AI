"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { toast } from "sonner";
import { ArrowLeft, MapPin, Users, Award, CheckCircle2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";
import Link from "next/link";

type Applicant = {
  id: string;
  stage: string;
  coverNote: string | null;
  createdAt: string;
  student: {
    id: string;
    name: string;
    email: string;
    targetCareer: { title: string } | null;
    assessments: { scores: Record<string, number> }[];
    problemProgress: { done: boolean }[];
    certificates: { id: string; title: string; issuer: string }[];
  };
};

type JobDetail = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: string;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  isActive: boolean;
  applications: Applicant[];
};

const STAGES = ["APPLIED", "SHORTLISTED", "EXAM", "INTERVIEW", "OFFER", "REJECTED"];
const STAGE_LABELS: Record<string, string> = {
  APPLIED: "Applied",
  SHORTLISTED: "Shortlisted",
  EXAM: "Exam",
  INTERVIEW: "Interview",
  OFFER: "Offer",
  REJECTED: "Rejected",
};

function avgScore(student: Applicant["student"]): number {
  const scores = student.assessments[0]?.scores;
  if (!scores) return 0;
  const vals = Object.values(scores);
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : 0;
}

export default function JobDetailPage() {
  const params = useParams<{ id: string }>();
  const [job, setJob] = useState<JobDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {

    const res = await api<{ job: JobDetail }>(`/api/recruiter/jobs/${params.id}`);
    setLoading(false);
    if (res.data) setJob(res.data.job);
    else setError(res.error || "Failed to load job");
  }

  useEffect(() => {
    // Inline the initial fetch so setState stays out of the effect body
    // (initial state is loading:true). The standalone load() is used by
    // the retry button as an event handler.
    Promise.resolve().then(() => load());
  }, []);

  async function changeStage(applicationId: string, stage: string) {
    const res = await api<{ ok?: boolean }>("/api/recruiter/pipeline", {
      method: "PATCH",
      body: JSON.stringify({ applicationId, stage }),
    });
    if (res.error) {
      toast.error(res.error);
      return;
    }
    toast.success(`Moved to ${STAGE_LABELS[stage]}`);
    setJob((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        applications: prev.applications.map((a) =>
          a.id === applicationId ? { ...a, stage } : a
        ),
      };
    });
  }

  if (loading) return <><PageHeader title="Job detail" /><LoadingState /></>;
  if (error) return <><PageHeader title="Job detail" /><ErrorState message={error} action={<Button onClick={load}>Try again</Button>} /></>;
  if (!job) return <><PageHeader title="Job detail" /><EmptyState title="Job not found" /></>;

  return (
    <>
      <PageHeader
        title={job.title}
        description={job.description}
      >
        <Button asChild variant="outline" size="sm">
          <Link href="/dashboard/recruiter/jobs"><ArrowLeft className="size-4" /> Back to jobs</Link>
        </Button>
      </PageHeader>

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Location</p>
          <p className="mt-1 flex items-center gap-1.5 text-sm font-medium"><MapPin className="size-4 text-muted-foreground" /> {job.location}</p>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Required skills</p>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {job.requiredSkills.split(",").filter(Boolean).map((s) => (
              <Badge key={s} variant="secondary" className="font-normal">{s.trim()}</Badge>
            ))}
          </div>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <p className="text-xs text-muted-foreground">Package · Min score</p>
          <p className="mt-1 text-sm font-medium">{job.packageLpa || "—"} · ≥ {job.minAvgScore}%</p>
        </CardContent></Card>
      </div>

      <h2 className="mb-4 text-lg font-semibold">Applicants ({job.applications.length})</h2>

      {job.applications.length === 0 ? (
        <EmptyState icon={Users} title="No applicants yet" description="Students who apply to this job will appear here." />
      ) : (
        <div className="space-y-3">
          {job.applications.map((app) => {
            const avg = avgScore(app.student);
            const solved = app.student.problemProgress.filter((p) => p.done).length;
            const initials = app.student.name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
            return (
              <Card key={app.id}>
                <CardContent className="p-4">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-3">
                      <Avatar className="size-10">
                        <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">{initials}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="font-medium">{app.student.name}</p>
                        <p className="text-sm text-muted-foreground">{app.student.email}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          {app.student.targetCareer && <span>{app.student.targetCareer.title}</span>}
                          <span>· Avg {avg}%</span>
                          <span>· {solved} solved</span>
                          {app.student.certificates.length > 0 && (
                            <span className="inline-flex items-center gap-1 text-emerald-600"><CheckCircle2 className="size-3" /> {app.student.certificates.length} cert(s)</span>
                          )}
                        </div>
                        {app.coverNote && (
                          <p className="mt-2 rounded-md bg-secondary/60 p-2 text-sm text-muted-foreground">&ldquo;{app.coverNote}&rdquo;</p>
                        )}
                        {app.student.certificates.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {app.student.certificates.map((c) => (
                              <Badge key={c.id} variant="outline" className="font-normal"><Award className="mr-1 size-3" />{c.title}</Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={app.stage === "OFFER" ? "default" : app.stage === "REJECTED" ? "destructive" : "secondary"} className="font-normal">
                        {STAGE_LABELS[app.stage]}
                      </Badge>
                      <Select value={app.stage} onValueChange={(v) => changeStage(app.id, v)}>
                        <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {STAGES.map((s) => (
                            <SelectItem key={s} value={s}>{STAGE_LABELS[s]}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </>
  );
}
