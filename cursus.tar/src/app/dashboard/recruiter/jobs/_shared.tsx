"use client";

import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

// ---------------- Types ----------------

export type JobType = "FULL_TIME" | "INTERN" | "CONTRACT";

export type ApplicationStage =
  | "APPLIED"
  | "SHORTLISTED"
  | "EXAM"
  | "INTERVIEW"
  | "OFFER"
  | "REJECTED";

export const STAGE_ORDER: ApplicationStage[] = [
  "APPLIED",
  "SHORTLISTED",
  "EXAM",
  "INTERVIEW",
  "OFFER",
  "REJECTED",
];

export const STAGE_LABELS: Record<ApplicationStage, string> = {
  APPLIED: "Applied",
  SHORTLISTED: "Shortlisted",
  EXAM: "Exam",
  INTERVIEW: "Interview",
  OFFER: "Offer",
  REJECTED: "Rejected",
};

export const JOB_TYPE_LABELS: Record<JobType, string> = {
  FULL_TIME: "Full-time",
  INTERN: "Internship",
  CONTRACT: "Contract",
};

// Semantic stage colors per the design spec.
// APPLIED=gray, SHORTLISTED=primary blue, EXAM=amber,
// INTERVIEW=purple, OFFER=green, REJECTED=red
const STAGE_BADGE_CLASS: Record<ApplicationStage, string> = {
  APPLIED:
    "border-transparent bg-secondary text-muted-foreground",
  SHORTLISTED: "border-transparent bg-primary/10 text-primary",
  EXAM:
    "border-transparent bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  INTERVIEW:
    "border-transparent bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300",
  OFFER:
    "border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  REJECTED:
    "border-transparent bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

export function StageBadge({
  stage,
  className,
}: {
  stage: ApplicationStage;
  className?: string;
}) {
  return (
    <Badge className={cn(STAGE_BADGE_CLASS[stage], className)}>
      {STAGE_LABELS[stage]}
    </Badge>
  );
}

const JOB_TYPE_BADGE_CLASS: Record<JobType, string> = {
  FULL_TIME:
    "border-transparent bg-primary/10 text-primary",
  INTERN:
    "border-transparent bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-400",
  CONTRACT:
    "border-transparent bg-secondary text-muted-foreground",
};

export function JobTypeBadge({
  jobType,
  className,
}: {
  jobType: JobType;
  className?: string;
}) {
  return (
    <Badge className={cn(JOB_TYPE_BADGE_CLASS[jobType], className)}>
      {JOB_TYPE_LABELS[jobType]}
    </Badge>
  );
}

// ---------------- Helpers ----------------

// Compute a student's average score from their latest assessment's `scores` JSON.
// `scores` may be a Record<skillSlug, number>, possibly null/undefined.
export function avgScoreFromAssessments(
  assessments?: { scores?: Record<string, number> | null }[] | null
): number {
  if (!assessments || assessments.length === 0) return 0;
  const scores = assessments[0]?.scores ?? {};
  const values = Object.values(scores ?? {}).filter(
    (v): v is number => typeof v === "number" && !Number.isNaN(v)
  );
  if (values.length === 0) return 0;
  const sum = values.reduce((a, b) => a + b, 0);
  return Math.round(sum / values.length);
}

export function statusFromScore(
  hasAssessment: boolean,
  avg: number
):
  | "no-assessment"
  | "at-risk"
  | "on-track"
  | "ready" {
  if (!hasAssessment) return "no-assessment";
  if (avg < 40) return "at-risk";
  if (avg >= 70) return "ready";
  return "on-track";
}

export const STATUS_BADGE_CLASS: Record<
  ReturnType<typeof statusFromScore>,
  string
> = {
  "no-assessment":
    "border-transparent bg-secondary text-muted-foreground",
  "at-risk":
    "border-transparent bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  "on-track": "border-transparent bg-primary/10 text-primary",
  ready:
    "border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
};

export const STATUS_LABELS: Record<
  ReturnType<typeof statusFromScore>,
  string
> = {
  "no-assessment": "No assessment",
  "at-risk": "At risk",
  "on-track": "On track",
  ready: "Ready",
};

export function initialsOf(name: string): string {
  return (
    name
      .split(" ")
      .filter(Boolean)
      .map((p) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "?"
  );
}

export function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}

export function formatDateTime(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function relativeTime(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    const diffMs = Date.now() - d.getTime();
    const sec = Math.round(diffMs / 1000);
    const min = Math.round(sec / 60);
    const hr = Math.round(min / 60);
    const day = Math.round(hr / 24);
    if (sec < 60) return "just now";
    if (min < 60) return `${min}m ago`;
    if (hr < 24) return `${hr}h ago`;
    if (day < 30) return `${day}d ago`;
    return formatDate(iso);
  } catch {
    return iso;
  }
}

// Parse a comma-separated skills string into a tidy array.
export function parseSkills(raw: string): string[] {
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

// Convert an array of skill strings into a comma-separated string (for input default).
export function skillsToInput(skills: string | null | undefined): string {
  if (!skills) return "";
  // Some legacy data may already be comma-separated.
  return skills;
}

// Render a list of skill strings as chips.
export function SkillChips({
  skills,
  max = 6,
}: {
  skills: string[];
  max?: number;
}) {
  const list = skills.slice(0, max);
  const more = skills.length - list.length;
  if (list.length === 0) {
    return <span className="text-xs text-muted-foreground">None</span>;
  }
  return (
    <div className="flex flex-wrap gap-1.5">
      {list.map((s) => (
        <span
          key={s}
          className="inline-flex items-center rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground"
        >
          {s}
        </span>
      ))}
      {more > 0 && (
        <span className="inline-flex items-center rounded-md bg-secondary/60 px-2 py-0.5 text-xs font-medium text-muted-foreground">
          +{more}
        </span>
      )}
    </div>
  );
}

// Thin wrapper used by the stage-move Select so its trigger
// looks like a small, inline control inside a card.
export function StageSelect({
  value,
  onChange,
  disabled,
  className,
}: {
  value: ApplicationStage;
  onChange: (next: ApplicationStage) => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <Select
      value={value}
      onValueChange={(v) => onChange(v as ApplicationStage)}
      disabled={disabled}
    >
      <SelectTrigger size="sm" className={cn("h-8 w-[10rem]", className)}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {STAGE_ORDER.map((s) => (
          <SelectItem key={s} value={s}>
            {STAGE_LABELS[s]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
