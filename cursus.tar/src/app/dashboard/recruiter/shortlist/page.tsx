"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bookmark,
  CalendarDays,
  Mail,
  StickyNote as StickyNoteIcon,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { api } from "@/lib/api";

import {
  type ShortlistedCandidate,
  SkillBars,
  StatusBadge,
  formatDate,
  initialsOf,
} from "../shared";

type ShortlistResponse = { candidates: ShortlistedCandidate[] };

export default function RecruiterShortlistPage() {
  const [candidates, setCandidates] = React.useState<ShortlistedCandidate[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [removingId, setRemovingId] = React.useState<string | null>(null);

  const load = React.useCallback(() => {
    setLoading(true);
    api<ShortlistResponse>("/api/recruiter/shortlist").then((res) => {
      setLoading(false);
      if (res.data) {
        setCandidates(res.data.candidates);
        setError(null);
      } else {
        setError(res.error || "Failed to load shortlist.");
      }
    });
  }, []);

  React.useEffect(() => {
    load();
  }, [load]);

  const onRemove = async (candidate: ShortlistedCandidate) => {
    setRemovingId(candidate.id);
    // Optimistically remove
    const prev = candidates;
    setCandidates((cur) => cur.filter((c) => c.id !== candidate.id));
    const { data, error } = await api<{ ok: boolean; shortlisted: boolean }>(
      `/api/recruiter/shortlist?studentId=${encodeURIComponent(candidate.id)}`,
      { method: "DELETE" }
    );
    setRemovingId(null);
    if (data?.ok) {
      toast.success("Removed from shortlist");
    } else {
      // Restore on failure
      setCandidates(prev);
      toast.error(error || "Could not remove from shortlist.");
    }
  };

  return (
    <div className="mx-auto w-full max-w-5xl">
      <PageHeader
        title="Shortlist"
        description="The candidates you've saved for follow-up."
      >
        {candidates.length > 0 && (
          <Button asChild variant="outline">
            <Link href="/dashboard/recruiter">
              <Users className="size-4" />
              Find more candidates
            </Link>
          </Button>
        )}
      </PageHeader>

      {loading ? (
        <LoadingState label="Loading shortlist…" />
      ) : error ? (
        <ErrorState
          message={error}
          action={
            <Button variant="outline" size="sm" onClick={load}>
              Try again
            </Button>
          }
        />
      ) : candidates.length === 0 ? (
        <EmptyState
          icon={Bookmark}
          title="Your shortlist is empty"
          description="Shortlist promising candidates from the candidates page to keep them here for follow-up."
          action={
            <Button asChild>
              <Link href="/dashboard/recruiter">
                <Users className="size-4" />
                Find candidates
              </Link>
            </Button>
          }
        />
      ) : (
        <>
          <div className="mb-3 text-sm text-muted-foreground" aria-live="polite">
            <span className="font-medium text-foreground">
              {candidates.length}
            </span>{" "}
            {candidates.length === 1 ? "candidate" : "candidates"} shortlisted
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {candidates.map((c) => (
              <ShortlistCard
                key={c.id}
                candidate={c}
                removing={removingId === c.id}
                onRemove={() => onRemove(c)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function ShortlistCard({
  candidate,
  removing,
  onRemove,
}: {
  candidate: ShortlistedCandidate;
  removing: boolean;
  onRemove: () => void;
}) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <Avatar className="size-11 shrink-0">
              <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
                {initialsOf(candidate.name)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <p className="truncate text-base font-semibold text-foreground">
                  {candidate.name}
                </p>
                <StatusBadge status={candidate.status} />
              </div>
              <p className="truncate text-sm text-muted-foreground">
                {candidate.email}
              </p>
              <p className="mt-0.5 truncate text-sm text-muted-foreground">
                {candidate.careerTitle || "No target career"}
                {candidate.stageLabel ? (
                  <>
                    <span className="mx-1.5 text-muted-foreground/50">•</span>
                    {candidate.stageLabel}
                  </>
                ) : null}
              </p>
            </div>
          </div>
        </div>

        <Separator className="my-4" />

        {/* Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground">
              Avg score
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-foreground">
              {candidate.avgCurrent}
              <span className="text-base font-normal text-muted-foreground">
                /100
              </span>
            </p>
            <p className="text-xs text-muted-foreground">
              {candidate.solvedProblems} problems solved
            </p>
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground">
              Readiness
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-foreground">
              {candidate.readinessPct}%
            </p>
            <Progress value={candidate.readinessPct} className="mt-1.5 h-1.5" />
          </div>
        </div>

        {/* Top skills */}
        {candidate.skills?.length > 0 && (
          <div className="mt-4">
            <p className="mb-2 text-xs font-medium text-muted-foreground">
              Top skills
            </p>
            <SkillBars skills={candidate.skills} max={3} />
          </div>
        )}

        {/* Note + date */}
        {(candidate.note || candidate.shortlistedAt) && (
          <Separator className="my-4" />
        )}
        <div className="space-y-2">
          {candidate.note && (
            <div className="flex items-start gap-2 rounded-md bg-secondary/60 p-2.5">
              <StickyNoteIcon className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" />
              <p className="text-sm text-foreground">{candidate.note}</p>
            </div>
          )}
          {candidate.shortlistedAt && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <CalendarDays className="size-3.5" />
              Shortlisted on {formatDate(candidate.shortlistedAt)}
            </div>
          )}
        </div>

        {/* Footer action */}
        <div className="mt-4 flex items-center justify-between gap-2">
          <a
            href={`mailto:${candidate.email}`}
            className="inline-flex h-9 items-center gap-2 rounded-md border bg-background px-3 text-sm font-medium shadow-xs transition-colors hover:bg-accent hover:text-accent-foreground"
          >
            <Mail className="size-4" />
            Contact
          </a>
          <Button
            variant="outline"
            size="sm"
            onClick={onRemove}
            disabled={removing}
            className="text-destructive hover:bg-destructive/5 hover:text-destructive"
          >
            <Trash2 className="size-4" />
            {removing ? "Removing…" : "Remove"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
