"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { KanbanSquare } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState } from "@/components/states";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { api } from "@/lib/api";

type Application = {
  id: string;
  stage: string;
  updatedAt: string;
  job: { id: string; title: string };
  student: {
    id: string;
    name: string;
    email: string;
    careerTitle: string | null;
    avgScore: number;
    readinessPct: number;
    status: string;
  };
};

const STAGES = ["APPLIED", "SHORTLISTED", "EXAM", "INTERVIEW", "OFFER", "REJECTED"];
const STAGE_LABELS: Record<string, string> = {
  APPLIED: "Applied",
  SHORTLISTED: "Shortlisted",
  EXAM: "Exam",
  INTERVIEW: "Interview",
  OFFER: "Offer",
  REJECTED: "Rejected",
};
const STAGE_TONES: Record<string, string> = {
  APPLIED: "bg-slate-100 text-slate-600",
  SHORTLISTED: "bg-blue-100 text-blue-600",
  EXAM: "bg-amber-100 text-amber-600",
  INTERVIEW: "bg-purple-100 text-purple-600",
  OFFER: "bg-emerald-100 text-emerald-600",
  REJECTED: "bg-red-100 text-red-600",
};

export default function PipelinePage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {

    const res = await api<{ applications: Application[] }>("/api/recruiter/pipeline");
    setLoading(false);
    if (res.data) setApplications(res.data.applications);
    else setError(res.error || "Failed to load pipeline");
  }

  useEffect(() => {
    // Inline the initial fetch so setState stays out of the effect body
    // (initial state is loading:true). The standalone load() is used by
    // the retry button as an event handler.
    Promise.resolve().then(() => load());
  }, []);

  async function changeStage(applicationId: string, stage: string) {
    const res = await api<{ ok?: boolean }>("/api/recruiter/pipeline", {
      method: "PATCH",
      body: JSON.stringify({ applicationId, stage }),
    });
    if (res.error) {
      toast.error(res.error);
      return;
    }
    toast.success(`Moved to ${STAGE_LABELS[stage]}`);
    setApplications((prev) =>
      prev.map((a) => (a.id === applicationId ? { ...a, stage } : a))
    );
  }

  if (loading) return <><PageHeader title="Hiring pipeline" description="Move candidates through your hiring stages." /><LoadingState /></>;
  if (error) return <><PageHeader title="Hiring pipeline" /><ErrorState message={error} action={<Button onClick={load}>Try again</Button>} /></>;

  return (
    <>
      <PageHeader title="Hiring pipeline" description={`${applications.length} candidate${applications.length !== 1 ? "s" : ""} across all your jobs.`} />
      {applications.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border px-6 py-16 text-center">
          <KanbanSquare className="mb-3 size-10 text-muted-foreground" />
          <h3 className="text-base font-semibold">No candidates yet</h3>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">
            Post a job and candidates will appear here as they apply.
          </p>
        </div>
      ) : (
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
          {STAGES.map((stage) => {
            const apps = applications.filter((a) => a.stage === stage);
            return (
              <div key={stage} className="flex w-72 shrink-0 flex-col">
                <div className="mb-2 flex items-center justify-between px-1">
                  <span className="text-sm font-semibold">{STAGE_LABELS[stage]}</span>
                  <span className={`inline-flex size-5 items-center justify-center rounded-full text-xs font-medium ${STAGE_TONES[stage]}`}>
                    {apps.length}
                  </span>
                </div>
                <div className="flex-1 space-y-2 rounded-lg bg-secondary/40 p-2">
                  {apps.length === 0 ? (
                    <p className="px-2 py-8 text-center text-xs text-muted-foreground">No candidates</p>
                  ) : (
                    apps.map((app) => (
                      <Card key={app.id} className="bg-background">
                        <CardContent className="p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <p className="truncate text-sm font-medium">{app.student.name}</p>
                              <p className="truncate text-xs text-muted-foreground">{app.job.title}</p>
                            </div>
                            <Badge variant="outline" className="shrink-0 font-normal">{app.student.avgScore}%</Badge>
                          </div>
                          <div className="mt-2 flex items-center gap-2">
                            <Select value={app.stage} onValueChange={(v) => changeStage(app.id, v)}>
                              <SelectTrigger className="h-7 w-full text-xs"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {STAGES.map((s) => (
                                  <SelectItem key={s} value={s} className="text-xs">{STAGE_LABELS[s]}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
