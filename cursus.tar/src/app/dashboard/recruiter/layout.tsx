import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";

export default async function RecruiterLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?callbackUrl=/dashboard/recruiter");
  if (user.role !== "RECRUITER") {
    redirect(`/dashboard/${user.role.toLowerCase()}`);
  }
  return <>{children}</>;
}
