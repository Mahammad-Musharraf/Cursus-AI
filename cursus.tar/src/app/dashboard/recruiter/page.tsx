"use client";

import * as React from "react";
import Link from "next/link";
import {
  Bookmark,
  BookmarkCheck,
  BookmarkPlus,
  Filter,
  Search,
  StickyNote,
  Users,
  X,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { api } from "@/lib/api";
import { STAGE_LABELS } from "@/lib/constants";

import {
  type Candidate,
  MetricBlock,
  SkillBars,
  StatusBadge,
  initialsOf,
} from "./shared";

type CandidatesResponse = { candidates: Candidate[]; recruiterId: string };

const MIN_AVG_OPTIONS = [
  { value: "0", label: "Any" },
  { value: "40", label: "40+" },
  { value: "60", label: "60+" },
  { value: "70", label: "70+" },
];

const STAGE_OPTIONS = [
  { value: "all", label: "All stages" },
  ...Object.entries(STAGE_LABELS).map(([value, label]) => ({
    value,
    label,
  })),
];

const SORT_OPTIONS = [
  { value: "avg", label: "Avg score (high to low)" },
  { value: "name", label: "Name (A→Z)" },
  { value: "recent", label: "Recently joined" },
];

export default function RecruiterCandidatesPage() {
  // Filter state
  const [q, setQ] = React.useState("");
  const [debouncedQ, setDebouncedQ] = React.useState("");
  const [minAvg, setMinAvg] = React.useState("0");
  const [stage, setStage] = React.useState("all");
  const [sort, setSort] = React.useState("avg");

  // Data state
  const [candidates, setCandidates] = React.useState<Candidate[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  // Track if the very first load has finished (to distinguish "no candidates at all" vs "no matches")
  const [initialLoaded, setInitialLoaded] = React.useState(false);
  // Bumping this refetches without changing filters
  const [refreshKey, setRefreshKey] = React.useState(0);

  // Debounce the text search ~300ms
  React.useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  // Build query + fetch when any filter changes
  React.useEffect(() => {
    const params = new URLSearchParams();
    if (debouncedQ) params.set("q", debouncedQ);
    if (minAvg && minAvg !== "0") params.set("minAvg", minAvg);
    if (stage && stage !== "all") params.set("stage", stage);
    if (sort && sort !== "avg") params.set("sort", sort);

    const url = `/api/recruiter/candidates${
      params.toString() ? `?${params.toString()}` : ""
    }`;

    setLoading(true);
    api<CandidatesResponse>(url).then((res) => {
      setLoading(false);
      setInitialLoaded(true);
      if (res.data) {
        setCandidates(res.data.candidates);
        setError(null);
      } else {
        setError(res.error || "Failed to load candidates.");
      }
    });
  }, [debouncedQ, minAvg, stage, sort, refreshKey]);

  const filtersActive =
    debouncedQ !== "" || minAvg !== "0" || stage !== "all" || sort !== "avg";

  const clearFilters = () => {
    setQ("");
    setMinAvg("0");
    setStage("all");
    setSort("avg");
  };

  const retry = () => setRefreshKey((k) => k + 1);

  // Shortlist handlers (update local state immediately for snappy UI)
  const onShortlist = async (candidate: Candidate) => {
    // Optimistically flip state
    setCandidates((prev) =>
      prev.map((c) =>
        c.id === candidate.id ? { ...c, shortlisted: true } : c
      )
    );
    const { data, error } = await api<{ ok: boolean; shortlisted: boolean }>(
      "/api/recruiter/shortlist",
      {
        method: "POST",
        body: JSON.stringify({ studentId: candidate.id }),
      }
    );
    if (data?.ok) {
      toast.success("Added to shortlist");
    } else {
      // Rollback
      setCandidates((prev) =>
        prev.map((c) =>
          c.id === candidate.id ? { ...c, shortlisted: false } : c
        )
      );
      toast.error(error || "Could not shortlist candidate.");
    }
  };

  const onRemoveShortlist = async (candidate: Candidate) => {
    setCandidates((prev) =>
      prev.map((c) =>
        c.id === candidate.id ? { ...c, shortlisted: false } : c
      )
    );
    const { data, error } = await api<{ ok: boolean; shortlisted: boolean }>(
      `/api/recruiter/shortlist?studentId=${encodeURIComponent(candidate.id)}`,
      { method: "DELETE" }
    );
    if (data?.ok) {
      toast.success("Removed from shortlist");
    } else {
      setCandidates((prev) =>
        prev.map((c) =>
          c.id === candidate.id ? { ...c, shortlisted: true } : c
        )
      );
      toast.error(error || "Could not remove from shortlist.");
    }
  };

  // Save a note on an already-shortlisted candidate (POST upserts).
  const onSaveNote = async (candidate: Candidate, note: string) => {
    const { data, error } = await api<{ ok: boolean; shortlisted: boolean }>(
      "/api/recruiter/shortlist",
      {
        method: "POST",
        body: JSON.stringify({ studentId: candidate.id, note }),
      }
    );
    if (data?.ok) {
      toast.success("Note saved");
    } else {
      toast.error(error || "Could not save note.");
    }
  };

  const hasCandidates = candidates.length > 0;
  const showNoMatches = initialLoaded && !hasCandidates && filtersActive;
  const showNoCandidatesAtAll =
    initialLoaded && !hasCandidates && !filtersActive && !loading;

  return (
    <div className="mx-auto w-full max-w-6xl">
      <PageHeader
        title="Candidates"
        description="Discover placement-ready students ranked by their average skill score."
      >
        <Button asChild>
          <Link href="/dashboard/recruiter/shortlist">
            <Bookmark className="size-4" />
            View shortlist
          </Link>
        </Button>
      </PageHeader>

      {/* Filter bar */}
      <Card className="mb-6">
        <CardContent className="p-4 sm:p-5">
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground">
                <Filter className="size-4 text-muted-foreground" />
                Filters
              </span>
              {filtersActive && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="h-7 text-xs text-muted-foreground"
                >
                  <X className="size-3.5" />
                  Clear
                </Button>
              )}
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {/* Text search */}
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search name or email"
                  className="pl-8"
                  aria-label="Search candidates by name or email"
                />
              </div>
              {/* Min avg score */}
              <Select value={minAvg} onValueChange={setMinAvg}>
                <SelectTrigger className="w-full" aria-label="Minimum average score">
                  <SelectValue placeholder="Min avg score" />
                </SelectTrigger>
                <SelectContent>
                  {MIN_AVG_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.value === "0" ? "Avg: Any" : `Avg ${o.label}`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {/* Stage */}
              <Select value={stage} onValueChange={setStage}>
                <SelectTrigger className="w-full" aria-label="Stage filter">
                  <SelectValue placeholder="Stage" />
                </SelectTrigger>
                <SelectContent>
                  {STAGE_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {/* Sort */}
              <Select value={sort} onValueChange={setSort}>
                <SelectTrigger className="w-full" aria-label="Sort by">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Result count */}
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {loading ? (
            "Loading candidates…"
          ) : (
            <>
              <span className="font-medium text-foreground">
                {candidates.length}
              </span>{" "}
              {candidates.length === 1 ? "candidate" : "candidates"}
            </>
          )}
        </p>
      </div>

      {/* Body */}
      {loading && candidates.length === 0 ? (
        <LoadingState label="Loading candidates…" />
      ) : error ? (
        <ErrorState
          message={error}
          action={
            <Button variant="outline" size="sm" onClick={retry}>
              Try again
            </Button>
          }
        />
      ) : showNoCandidatesAtAll ? (
        <EmptyState
          icon={Users}
          title="No candidates yet"
          description="Students will appear here once they take an assessment and pick a target career."
        />
      ) : showNoMatches ? (
        <EmptyState
          icon={Search}
          title="No matches for these filters"
          description="Try widening your search, lowering the minimum score, or clearing filters."
          action={
            <Button onClick={clearFilters} variant="outline" size="sm">
              <X className="size-4" />
              Clear filters
            </Button>
          }
        />
      ) : (
        <div className="max-h-[32rem] space-y-3 overflow-y-auto scrollbar-thin pr-1">
          {candidates.map((c) => (
            <CandidateCard
              key={c.id}
              candidate={c}
              onShortlist={onShortlist}
              onRemoveShortlist={onRemoveShortlist}
              onSaveNote={onSaveNote}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------- Candidate card ----------------

function CandidateCard({
  candidate,
  onShortlist,
  onRemoveShortlist,
  onSaveNote,
}: {
  candidate: Candidate;
  onShortlist: (c: Candidate) => void;
  onRemoveShortlist: (c: Candidate) => void;
  onSaveNote: (c: Candidate, note: string) => void;
}) {
  const [noteOpen, setNoteOpen] = React.useState(false);

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4 sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          {/* Identity */}
          <div className="flex min-w-0 items-start gap-3">
            <Avatar className="size-11 shrink-0">
              <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
                {initialsOf(candidate.name)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <p className="truncate text-base font-semibold text-foreground">
                  {candidate.name}
                </p>
                <StatusBadge status={candidate.status} />
              </div>
              <p className="truncate text-sm text-muted-foreground">
                {candidate.email}
              </p>
              <p className="mt-1 truncate text-sm text-muted-foreground">
                {candidate.careerTitle || "No target career"}
                {candidate.stageLabel ? (
                  <>
                    <span className="mx-1.5 text-muted-foreground/50">•</span>
                    {candidate.stageLabel}
                  </>
                ) : null}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex shrink-0 items-center gap-2">
            {candidate.shortlisted ? (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onRemoveShortlist(candidate)}
                >
                  <BookmarkCheck className="size-4 text-primary" />
                  Shortlisted
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Add or edit note"
                  title="Add / edit note"
                  onClick={() => setNoteOpen(true)}
                >
                  <StickyNote className="size-4" />
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                onClick={() => onShortlist(candidate)}
              >
                <BookmarkPlus className="size-4" />
                Shortlist
              </Button>
            )}
          </div>
        </div>

        <Separator className="my-4" />

        {/* Metrics + Skills */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <MetricBlock
            label="Avg score"
            value={
              <span>
                {candidate.avgCurrent}
                <span className="text-base font-normal text-muted-foreground">
                  /100
                </span>
              </span>
            }
            hint={`${candidate.solvedProblems} problems solved`}
          />
          <div className="sm:col-span-1">
            <p className="text-xs font-medium text-muted-foreground">
              Readiness
            </p>
            <p className="mt-0.5 text-xl font-semibold tracking-tight text-foreground">
              {candidate.readinessPct}%
            </p>
            <Progress
              value={candidate.readinessPct}
              className="mt-1.5 h-1.5"
            />
          </div>
          <div className="sm:col-span-1">
            <p className="mb-2 text-xs font-medium text-muted-foreground">
              Top skills
            </p>
            <SkillBars skills={candidate.skills} max={3} />
          </div>
        </div>
      </CardContent>

      {/* Note dialog */}
      <NoteDialog
        open={noteOpen}
        onOpenChange={setNoteOpen}
        candidateName={candidate.name}
        onSubmit={(note) => {
          onSaveNote(candidate, note);
          setNoteOpen(false);
        }}
      />
    </Card>
  );
}

// ---------------- Note dialog ----------------

function NoteDialog({
  open,
  onOpenChange,
  candidateName,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  candidateName: string;
  onSubmit: (note: string) => void;
}) {
  const [note, setNote] = React.useState("");

  // Reset note each time dialog opens
  React.useEffect(() => {
    if (open) setNote("");
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add a note</DialogTitle>
          <DialogDescription>
            A private note for{" "}
            <span className="font-medium text-foreground">{candidateName}</span>.
            Visible only to you on your shortlist.
          </DialogDescription>
        </DialogHeader>
        <Textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="e.g. Strong React + TypeScript. Follow up about their capstone project."
          maxLength={280}
          rows={4}
        />
        <p className="text-right text-xs text-muted-foreground">
          {note.length}/280
        </p>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={() => onSubmit(note.trim())}
            disabled={note.trim().length === 0}
          >
            Save note
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
