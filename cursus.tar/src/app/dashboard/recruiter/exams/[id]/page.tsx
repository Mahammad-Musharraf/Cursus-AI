"use client";

import * as React from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  Clock,
  ListChecks,
  Users,
  Trash2,
  Loader2,
  CheckCircle2,
  XCircle,
  Target,
  Calendar,
  Code2,
  AlignLeft,
  ListChecks as ListIcon,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { api } from "@/lib/api";

// ---------------- Types ----------------

type QuestionType = "MCQ" | "SHORT_ANSWER" | "CODING";
type Difficulty = "EASY" | "MEDIUM" | "HARD";

type ExamQuestion = {
  id: string;
  type: QuestionType;
  prompt: string;
  options: string[] | null;
  answer: string;
  skillSlug: string | null;
  difficulty: Difficulty;
  points: number;
};

type Attempt = {
  id: string;
  student: { id: string; name: string; email: string };
  scorePct: number | null;
  passed: boolean | null;
  submittedAt: string | null;
  timeSpentSec: number;
};

type ExamDetail = {
  id: string;
  title: string;
  description: string;
  durationMin: number;
  questionsToPick: number;
  passScorePct: number;
  isActive: boolean;
  jobId: string | null;
  jobTitle: string | null;
  createdAt: string;
  questions: ExamQuestion[];
  attempts: Attempt[];
};

type ExamDetailResponse = { exam: ExamDetail };

const QUESTION_TYPE_META: Record<
  QuestionType,
  { label: string; icon: React.ComponentType<{ className?: string }> }
> = {
  MCQ: { label: "Multiple choice", icon: ListIcon },
  SHORT_ANSWER: { label: "Short answer", icon: AlignLeft },
  CODING: { label: "Coding", icon: Code2 },
};

const DIFFICULTY_BADGE: Record<Difficulty, string> = {
  EASY:
    "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  MEDIUM:
    "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  HARD: "border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

function fmtDateTime(iso: string | null): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function fmtDuration(sec: number): string {
  if (!sec || sec < 1) return "—";
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m === 0) return `${s}s`;
  return `${m}m ${s.toString().padStart(2, "0")}s`;
}

// ---------------- Page ----------------

export default function RecruiterExamDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const router = useRouter();

  const [exam, setExam] = React.useState<ExamDetail | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshKey, setRefreshKey] = React.useState(0);
  const [toggling, setToggling] = React.useState(false);
  const [deleting, setDeleting] = React.useState(false);

  React.useEffect(() => {
    if (!id) return;
    let active = true;
    api<ExamDetailResponse>(`/api/recruiter/exams/${id}`).then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data?.exam) {
        setExam(res.data.exam);
        setError(null);
      } else {
        setError(res.error || "Failed to load exam.");
      }
    });
    return () => {
      active = false;
    };
  }, [id, refreshKey]);

  const retry = () => {
    setLoading(true);
    setError(null);
    setRefreshKey((k) => k + 1);
  };

  async function handleToggleActive(next: boolean) {
    if (!exam) return;
    setToggling(true);
    const prev = exam.isActive;
    setExam({ ...exam, isActive: next });
    const res = await api<{ ok: boolean }>(`/api/recruiter/exams/${exam.id}`, {
      method: "PATCH",
      body: JSON.stringify({ isActive: next }),
    });
    setToggling(false);
    if (res.data?.ok) {
      toast.success(next ? "Exam activated" : "Exam deactivated");
    } else {
      setExam({ ...exam, isActive: prev });
      toast.error(res.error || "Could not update exam.");
    }
  }

  async function handleDelete() {
    if (!exam) return;
    setDeleting(true);
    const res = await api<{ ok: boolean }>(`/api/recruiter/exams/${exam.id}`, {
      method: "DELETE",
    });
    setDeleting(false);
    if (res.data?.ok) {
      toast.success("Exam deleted.");
      router.push("/dashboard/recruiter/exams");
    } else {
      toast.error(res.error || "Could not delete exam.");
    }
  }

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-5xl space-y-6">
        <PageHeader
          title="Exam"
          description="Loading exam details…"
        />
        <LoadingState label="Loading exam…" />
      </div>
    );
  }

  if (error || !exam) {
    return (
      <div className="mx-auto w-full max-w-5xl space-y-6">
        <PageHeader title="Exam" description="Could not load this exam." />
        <ErrorState
          message={error || "Exam not found."}
          action={
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={retry}>
                Try again
              </Button>
              <Button asChild variant="ghost" size="sm">
                <Link href="/dashboard/recruiter/exams">
                  <ArrowLeft className="size-4" />
                  Back to exams
                </Link>
              </Button>
            </div>
          }
        />
      </div>
    );
  }

  const submittedAttempts = exam.attempts.filter((a) => a.submittedAt);
  const passedCount = submittedAttempts.filter((a) => a.passed).length;
  const avgScore =
    submittedAttempts.length > 0
      ? Math.round(
          submittedAttempts.reduce(
            (s, a) => s + (a.scorePct ?? 0),
            0
          ) / submittedAttempts.length
        )
      : 0;

  return (
    <div className="mx-auto w-full max-w-5xl space-y-6">
      <PageHeader
        title={exam.title}
        description={exam.description || "—"}
      >
        <Button asChild variant="ghost" size="sm">
          <Link href="/dashboard/recruiter/exams">
            <ArrowLeft className="size-4" />
            Back
          </Link>
        </Button>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              disabled={deleting}
              className="text-destructive hover:bg-destructive/5"
            >
              {deleting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Trash2 className="size-4" />
              )}
              Delete
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete this exam?</AlertDialogTitle>
              <AlertDialogDescription>
                This permanently deletes the exam, its question bank, and all
                student attempts. This cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                disabled={deleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {deleting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Deleting…
                  </>
                ) : (
                  "Delete exam"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </PageHeader>

      {/* Settings summary + active toggle */}
      <Card>
        <CardContent className="p-4 sm:p-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="grid flex-1 grid-cols-2 gap-4 sm:grid-cols-4">
              <Stat icon={Clock} label="Duration" value={`${exam.durationMin} min`} />
              <Stat
                icon={ListChecks}
                label="Questions"
                value={`${exam.questions.length} · picks ${exam.questionsToPick}`}
              />
              <Stat icon={Target} label="Pass score" value={`${exam.passScorePct}%`} />
              <Stat icon={Users} label="Attempts" value={String(exam.attempts.length)} />
            </div>

            <div className="flex shrink-0 items-center gap-3 rounded-md border border-border bg-muted/30 px-3 py-2">
              <div className="text-right">
                <p className="text-xs font-medium text-foreground">
                  {exam.isActive ? "Active" : "Inactive"}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  Visible to students when active
                </p>
              </div>
              <Switch
                checked={exam.isActive}
                onCheckedChange={handleToggleActive}
                disabled={toggling}
                aria-label="Toggle exam active"
              />
            </div>
          </div>

          {(exam.jobTitle || exam.createdAt) && (
            <>
              <Separator className="my-4" />
              <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-xs text-muted-foreground">
                {exam.jobTitle && (
                  <span>Linked job: {exam.jobTitle}</span>
                )}
                <span className="inline-flex items-center gap-1">
                  <Calendar className="size-3.5" />
                  Created {fmtDateTime(exam.createdAt)}
                </span>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Quick stats on attempts */}
      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground">
              Submitted attempts
            </p>
            <p className="mt-1 text-2xl font-semibold tracking-tight text-foreground">
              {submittedAttempts.length}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground">Passed</p>
            <p className="mt-1 text-2xl font-semibold tracking-tight text-foreground">
              {passedCount}
              <span className="text-sm font-normal text-muted-foreground">
                {" "}
                / {submittedAttempts.length}
              </span>
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <p className="text-xs font-medium text-muted-foreground">
              Avg score
            </p>
            <p className="mt-1 text-2xl font-semibold tracking-tight text-foreground">
              {avgScore}%
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Question bank */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">
          Question bank ({exam.questions.length})
        </h2>
        {exam.questions.length === 0 ? (
          <EmptyState
            icon={ListChecks}
            title="No questions"
            description="This exam has no questions in its bank."
          />
        ) : (
          <div className="space-y-3">
            {exam.questions.map((q, i) => (
              <QuestionView key={q.id} index={i} question={q} />
            ))}
          </div>
        )}
      </section>

      {/* Attempts table */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">
          Student attempts ({exam.attempts.length})
        </h2>
        {exam.attempts.length === 0 ? (
          <EmptyState
            icon={Users}
            title="No attempts yet"
            description="Once students start this exam, their attempts and scores will appear here."
          />
        ) : (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Result</TableHead>
                    <TableHead>Time spent</TableHead>
                    <TableHead>Submitted</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {exam.attempts.map((a) => (
                    <TableRow key={a.id}>
                      <TableCell>
                        <div className="min-w-0">
                          <p className="truncate font-medium text-foreground">
                            {a.student.name}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">
                            {a.student.email}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {a.scorePct === null ? (
                          <span className="text-muted-foreground">—</span>
                        ) : (
                          <span className="font-semibold text-foreground">
                            {a.scorePct}%
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        {a.submittedAt === null ? (
                          <Badge variant="secondary">In progress</Badge>
                        ) : a.passed ? (
                          <Badge className="border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                            <CheckCircle2 className="size-3" />
                            Passed
                          </Badge>
                        ) : (
                          <Badge className="border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400">
                            <XCircle className="size-3" />
                            Failed
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {a.submittedAt ? fmtDuration(a.timeSpentSec) : "—"}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {fmtDateTime(a.submittedAt)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </section>
    </div>
  );
}

// ---------------- Sub-components ----------------

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="min-w-0">
      <p className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </p>
      <p className="mt-0.5 truncate text-base font-semibold text-foreground">
        {value}
      </p>
    </div>
  );
}

function QuestionView({
  index,
  question,
}: {
  index: number;
  question: ExamQuestion;
}) {
  const meta = QUESTION_TYPE_META[question.type];
  const Icon = meta.icon;
  const options = question.options ?? [];

  return (
    <Card>
      <CardContent className="p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="inline-flex size-6 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
            {index + 1}
          </span>
          <Badge variant="outline" className="gap-1">
            <Icon className="size-3" />
            {meta.label}
          </Badge>
          <Badge variant="outline" className={DIFFICULTY_BADGE[question.difficulty]}>
            {question.difficulty}
          </Badge>
          {question.skillSlug && (
            <Badge variant="secondary">{question.skillSlug}</Badge>
          )}
          <span className="text-xs text-muted-foreground">
            {question.points} {question.points === 1 ? "point" : "points"}
          </span>
        </div>

        <p className="text-sm text-foreground">{question.prompt}</p>

        {question.type === "MCQ" && options.length > 0 && (
          <div className="mt-3 grid gap-1.5">
            {options.map((opt, i) => {
              const isCorrect = String(i) === question.answer.trim();
              return (
                <div
                  key={i}
                  className={
                    "flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-sm " +
                    (isCorrect
                      ? "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200"
                      : "border-border bg-muted/30 text-foreground")
                  }
                >
                  <span className="text-xs font-semibold text-muted-foreground">
                    {String.fromCharCode(65 + i)}
                  </span>
                  <span className="flex-1 truncate">{opt || "—"}</span>
                  {isCorrect && (
                    <CheckCircle2 className="size-4 text-emerald-600" />
                  )}
                </div>
              );
            })}
          </div>
        )}

        {question.type === "SHORT_ANSWER" && (
          <div className="mt-3 rounded-md border border-emerald-300 bg-emerald-50 px-3 py-2 text-sm dark:border-emerald-800 dark:bg-emerald-950/40">
            <p className="text-xs font-medium uppercase tracking-wide text-emerald-700 dark:text-emerald-400">
              Expected answer
            </p>
            <p className="mt-0.5 font-mono text-foreground">{question.answer}</p>
          </div>
        )}

        {question.type === "CODING" && (
          <div className="mt-3 rounded-md border border-dashed border-border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
            Coding question — submitted answers are stored for manual review.
          </div>
        )}
      </CardContent>
    </Card>
  );
}
