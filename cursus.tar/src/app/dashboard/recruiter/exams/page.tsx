"use client";

import * as React from "react";
import Link from "next/link";
import {
  ClipboardList,
  Plus,
  Trash2,
  X,
  Loader2,
  FileText,
  Clock,
  ListChecks,
  Users,
  ArrowRight,
  Eye,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import { api } from "@/lib/api";

// ---------------- Types ----------------

type ExamListItem = {
  id: string;
  title: string;
  description: string;
  durationMin: number;
  questionsToPick: number;
  passScorePct: number;
  isActive: boolean;
  jobId: string | null;
  jobTitle: string | null;
  questionCount: number;
  attemptCount: number;
  createdAt: string;
};

type ExamsResponse = { exams: ExamListItem[] };

type QuestionType = "MCQ" | "SHORT_ANSWER" | "CODING";
type Difficulty = "EASY" | "MEDIUM" | "HARD";

type QuestionDraft = {
  id: string;
  type: QuestionType;
  prompt: string;
  options: string[]; // for MCQ: 4 strings
  correctOption: number; // for MCQ: 0-based index
  expectedAnswer: string; // for SHORT_ANSWER
  skillSlug: string;
  difficulty: Difficulty;
  points: number;
};

const QUESTION_TYPE_LABEL: Record<QuestionType, string> = {
  MCQ: "Multiple choice",
  SHORT_ANSWER: "Short answer",
  CODING: "Coding",
};

const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  EASY: "Easy",
  MEDIUM: "Medium",
  HARD: "Hard",
};

const DIFFICULTY_BADGE: Record<Difficulty, string> = {
  EASY:
    "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  MEDIUM:
    "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  HARD: "border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function newQuestion(): QuestionDraft {
  return {
    id: uid(),
    type: "MCQ",
    prompt: "",
    options: ["", "", "", ""],
    correctOption: 0,
    expectedAnswer: "",
    skillSlug: "",
    difficulty: "MEDIUM",
    points: 1,
  };
}

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}

// ---------------- Page ----------------

export default function RecruiterExamsPage() {
  // List state
  const [exams, setExams] = React.useState<ExamListItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  // Create-form state
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [durationMin, setDurationMin] = React.useState("60");
  const [questionsToPick, setQuestionsToPick] = React.useState("10");
  const [passScorePct, setPassScorePct] = React.useState("60");
  const [questions, setQuestions] = React.useState<QuestionDraft[]>([
    newQuestion(),
  ]);
  const [submitting, setSubmitting] = React.useState(false);
  const [fieldErrors, setFieldErrors] = React.useState<
    Record<string, string[]>
  >({});
  const [createOpen, setCreateOpen] = React.useState(false);

  // Initial load — keep setState out of the effect body (matches the
  // existing dashboard patterns; initial state is loading:true).
  React.useEffect(() => {
    let active = true;
    api<ExamsResponse>("/api/recruiter/exams").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) {
        setExams(res.data.exams);
        setError(null);
      } else {
        setError(res.error || "Failed to load exams.");
      }
    });
    return () => {
      active = false;
    };
  }, []);

  function load() {
    setLoading(true);
    setError(null);
    api<ExamsResponse>("/api/recruiter/exams").then((res) => {
      setLoading(false);
      if (res.data) setExams(res.data.exams);
      else setError(res.error || "Failed to load exams.");
    });
  }

  // ---------- Question builder helpers ----------
  function updateQuestion(id: string, patch: Partial<QuestionDraft>) {
    setQuestions((prev) =>
      prev.map((q) => (q.id === id ? { ...q, ...patch } : q))
    );
  }

  function addQuestion() {
    setQuestions((prev) => [...prev, newQuestion()]);
  }

  function removeQuestion(id: string) {
    setQuestions((prev) => prev.filter((q) => q.id !== id));
  }

  function updateOption(id: string, idx: number, value: string) {
    setQuestions((prev) =>
      prev.map((q) => {
        if (q.id !== id) return q;
        const next = [...q.options];
        next[idx] = value;
        return { ...q, options: next };
      })
    );
  }

  function resetForm() {
    setTitle("");
    setDescription("");
    setDurationMin("60");
    setQuestionsToPick("10");
    setPassScorePct("60");
    setQuestions([newQuestion()]);
    setFieldErrors({});
  }

  // ---------- Submit ----------
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setFieldErrors({});

    // Build the question payload + client-side validation
    const payload: {
      type: QuestionType;
      prompt: string;
      options?: string[];
      answer: string;
      skillSlug?: string;
      difficulty: Difficulty;
      points: number;
    }[] = [];

    const localErrors: string[] = [];
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      const ctx = `Question ${i + 1}`;
      if (q.prompt.trim().length < 2) {
        localErrors.push(`${ctx}: prompt is too short.`);
        continue;
      }
      if (q.type === "MCQ") {
        const filledOptions = q.options
          .map((o) => o.trim())
          .filter((o) => o.length > 0);
        if (filledOptions.length < 2) {
          localErrors.push(`${ctx}: add at least 2 MCQ options.`);
          continue;
        }
        if (q.correctOption < 0 || q.correctOption >= q.options.length) {
          localErrors.push(`${ctx}: pick a correct option.`);
          continue;
        }
        if (!q.options[q.correctOption].trim()) {
          localErrors.push(`${ctx}: the correct option can't be blank.`);
          continue;
        }
        payload.push({
          type: "MCQ",
          prompt: q.prompt.trim(),
          options: q.options.map((o) => o.trim()),
          answer: String(q.correctOption),
          skillSlug: q.skillSlug.trim() || undefined,
          difficulty: q.difficulty,
          points: q.points,
        });
      } else if (q.type === "SHORT_ANSWER") {
        if (q.expectedAnswer.trim().length < 1) {
          localErrors.push(`${ctx}: provide an expected answer.`);
          continue;
        }
        payload.push({
          type: "SHORT_ANSWER",
          prompt: q.prompt.trim(),
          answer: q.expectedAnswer.trim(),
          skillSlug: q.skillSlug.trim() || undefined,
          difficulty: q.difficulty,
          points: q.points,
        });
      } else {
        // CODING
        payload.push({
          type: "CODING",
          prompt: q.prompt.trim(),
          answer: "PENDING_MANUAL_REVIEW",
          skillSlug: q.skillSlug.trim() || undefined,
          difficulty: q.difficulty,
          points: q.points,
        });
      }
    }

    if (localErrors.length) {
      for (const msg of localErrors) toast.error(msg);
      return;
    }

    if (payload.length === 0) {
      toast.error("Add at least one question.");
      return;
    }

    const body = {
      title: title.trim(),
      description: description.trim(),
      durationMin: Number(durationMin) || 60,
      questionsToPick: Number(questionsToPick) || 10,
      passScorePct: Number(passScorePct) || 60,
      questions: payload,
    };

    if (body.title.length < 2) {
      toast.error("Title must be at least 2 characters.");
      return;
    }
    if (body.description.length < 2) {
      toast.error("Description must be at least 2 characters.");
      return;
    }

    setSubmitting(true);
    // Use raw fetch (not api()) so we can read the full error body — including
    // the `fields` map returned on 422 — which the api() helper drops.
    let res: Response;
    try {
      res = await fetch("/api/recruiter/exams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    } catch (e) {
      setSubmitting(false);
      toast.error(e instanceof Error ? e.message : "Network error");
      return;
    }
    const respBody = await res.json().catch(() => null);
    setSubmitting(false);

    if (res.ok && respBody?.ok && respBody.exam) {
      toast.success("Exam created.", {
        description: `${respBody.exam.title} • ${respBody.exam.questionCount} questions`,
      });
      setExams((prev) => [respBody.exam as ExamListItem, ...prev]);
      resetForm();
      setCreateOpen(false);
    } else if (res.status === 422 && respBody?.fields) {
      setFieldErrors(respBody.fields as Record<string, string[]>);
      const flat = Object.values(
        respBody.fields as Record<string, string[]>
      ).flat();
      for (const m of flat.slice(0, 3)) toast.error(m);
      if (flat.length === 0) toast.error(respBody?.error || "Invalid input.");
    } else {
      toast.error(respBody?.error || "Could not create exam.");
    }
  }

  // ---------- Render ----------
  return (
    <div className="mx-auto w-full max-w-6xl space-y-6">
      <PageHeader
        title="Exams"
        description="Create screening exams from a question bank."
      >
        <Button onClick={() => setCreateOpen((v) => !v)}>
          {createOpen ? (
            <>
              <X className="size-4" />
              Close
            </>
          ) : (
            <>
              <Plus className="size-4" />
              Create exam
            </>
          )}
        </Button>
      </PageHeader>

      {/* Create exam form */}
      {createOpen && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <span className="inline-flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
                <ClipboardList className="size-4" />
              </span>
              New exam
            </CardTitle>
            <CardDescription>
              Add exam settings, then build your question bank. Students will
              see a randomized subset.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Settings */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="grid gap-1.5 sm:col-span-2">
                  <Label htmlFor="ex-title">Title</Label>
                  <Input
                    id="ex-title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Frontend Engineer screening"
                    maxLength={120}
                    required
                    disabled={submitting}
                  />
                  {fieldErrors.title && (
                    <p className="text-xs text-destructive">
                      {fieldErrors.title.join(", ")}
                    </p>
                  )}
                </div>

                <div className="grid gap-1.5 sm:col-span-2">
                  <Label htmlFor="ex-desc">Description</Label>
                  <Textarea
                    id="ex-desc"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="What this exam screens for, who it's aimed at…"
                    rows={3}
                    maxLength={600}
                    required
                    disabled={submitting}
                  />
                  {fieldErrors.description && (
                    <p className="text-xs text-destructive">
                      {fieldErrors.description.join(", ")}
                    </p>
                  )}
                </div>

                <div className="grid gap-1.5">
                  <Label htmlFor="ex-dur">Duration (minutes)</Label>
                  <Input
                    id="ex-dur"
                    type="number"
                    min={5}
                    max={180}
                    value={durationMin}
                    onChange={(e) => setDurationMin(e.target.value)}
                    disabled={submitting}
                  />
                  {fieldErrors.durationMin && (
                    <p className="text-xs text-destructive">
                      {fieldErrors.durationMin.join(", ")}
                    </p>
                  )}
                </div>

                <div className="grid gap-1.5">
                  <Label htmlFor="ex-qp">Questions to pick</Label>
                  <Input
                    id="ex-qp"
                    type="number"
                    min={1}
                    max={50}
                    value={questionsToPick}
                    onChange={(e) => setQuestionsToPick(e.target.value)}
                    disabled={submitting}
                  />
                  <p className="text-xs text-muted-foreground">
                    Randomized subset per candidate.
                  </p>
                  {fieldErrors.questionsToPick && (
                    <p className="text-xs text-destructive">
                      {fieldErrors.questionsToPick.join(", ")}
                    </p>
                  )}
                </div>

                <div className="grid gap-1.5">
                  <Label htmlFor="ex-pass">Pass score (%)</Label>
                  <Input
                    id="ex-pass"
                    type="number"
                    min={0}
                    max={100}
                    value={passScorePct}
                    onChange={(e) => setPassScorePct(e.target.value)}
                    disabled={submitting}
                  />
                  {fieldErrors.passScorePct && (
                    <p className="text-xs text-destructive">
                      {fieldErrors.passScorePct.join(", ")}
                    </p>
                  )}
                </div>
              </div>

              <Separator />

              {/* Question bank */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold text-foreground">
                      Question bank
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {questions.length}{" "}
                      {questions.length === 1 ? "question" : "questions"} in the
                      bank · students see {questionsToPick || "—"}
                    </p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addQuestion}
                    disabled={submitting}
                  >
                    <Plus className="size-4" />
                    Add question
                  </Button>
                </div>

                <div className="space-y-3">
                  {questions.map((q, idx) => (
                    <QuestionRow
                      key={q.id}
                      index={idx}
                      question={q}
                      disabled={submitting}
                      onChange={(patch) => updateQuestion(q.id, patch)}
                      onOptionChange={(i, v) => updateOption(q.id, i, v)}
                      onRemove={() => removeQuestion(q.id)}
                      canRemove={questions.length > 1}
                    />
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <Button type="submit" disabled={submitting}>
                  {submitting ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      Creating…
                    </>
                  ) : (
                    <>
                      <Plus className="size-4" />
                      Create exam
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={resetForm}
                  disabled={submitting}
                >
                  Reset
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* List */}
      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-medium text-muted-foreground">
            {exams.length > 0
              ? `Your exams (${exams.length})`
              : "Your exams"}
          </h2>
        </div>

        {loading ? (
          <LoadingState label="Loading exams…" />
        ) : error ? (
          <ErrorState
            message={error}
            action={
              <Button variant="outline" size="sm" onClick={load}>
                Try again
              </Button>
            }
          />
        ) : exams.length === 0 ? (
          <EmptyState
            icon={FileText}
            title="No exams yet"
            description="Click “Create exam” above to build your first screening exam from a question bank."
            action={
              <Button onClick={() => setCreateOpen(true)}>
                <Plus className="size-4" />
                Create your first exam
              </Button>
            }
          />
        ) : (
          <div className="grid gap-3">
            {exams.map((exam) => (
              <ExamCard key={exam.id} exam={exam} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

// ---------------- Exam card ----------------

function ExamCard({ exam }: { exam: ExamListItem }) {
  return (
    <Card>
      <CardContent className="p-4 sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-semibold text-foreground">
                {exam.title}
              </h3>
              {exam.isActive ? (
                <Badge className="border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                  Active
                </Badge>
              ) : (
                <Badge variant="secondary">Inactive</Badge>
              )}
              {exam.jobTitle && (
                <Badge variant="outline">{exam.jobTitle}</Badge>
              )}
            </div>
            {exam.description && (
              <p className="mt-1 line-clamp-2 max-w-2xl text-sm text-muted-foreground">
                {exam.description}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Clock className="size-3.5" />
                {exam.durationMin} min
              </span>
              <span className="inline-flex items-center gap-1.5">
                <ListChecks className="size-3.5" />
                {exam.questionCount} in bank · picks {exam.questionsToPick}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Users className="size-3.5" />
                {exam.attemptCount}{" "}
                {exam.attemptCount === 1 ? "attempt" : "attempts"}
              </span>
              <span className="inline-flex items-center gap-1.5">
                Pass {exam.passScorePct}%
              </span>
              <span className="text-xs text-muted-foreground/70">
                Created {formatDate(exam.createdAt)}
              </span>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/dashboard/recruiter/exams/${exam.id}`}>
                <Eye className="size-4" />
                View & results
                <ArrowRight className="size-3.5" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ---------------- Question row (builder) ----------------

function QuestionRow({
  index,
  question,
  disabled,
  onChange,
  onOptionChange,
  onRemove,
  canRemove,
}: {
  index: number;
  question: QuestionDraft;
  disabled: boolean;
  onChange: (patch: Partial<QuestionDraft>) => void;
  onOptionChange: (idx: number, value: string) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  return (
    <div className="rounded-lg border border-border bg-muted/20 p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          <span className="inline-flex size-5 items-center justify-center rounded-full bg-primary/10 text-[10px] font-bold text-primary">
            {index + 1}
          </span>
          Question
        </span>
        <div className="flex items-center gap-2">
          <Select
            value={question.difficulty}
            onValueChange={(v) => onChange({ difficulty: v as Difficulty })}
            disabled={disabled}
          >
            <SelectTrigger size="sm" className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(DIFFICULTY_LABEL) as Difficulty[]).map((d) => (
                <SelectItem key={d} value={d}>
                  {DIFFICULTY_LABEL[d]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {canRemove && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="size-8 text-muted-foreground hover:text-destructive"
              onClick={onRemove}
              disabled={disabled}
              aria-label="Remove question"
            >
              <Trash2 className="size-4" />
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-3">
        <div className="grid gap-1.5 sm:grid-cols-[160px_1fr] sm:items-start">
          <div className="grid gap-1.5">
            <Label className="text-xs">Type</Label>
            <Select
              value={question.type}
              onValueChange={(v) => onChange({ type: v as QuestionType })}
              disabled={disabled}
            >
              <SelectTrigger className="w-full sm:w-40" size="sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(QUESTION_TYPE_LABEL) as QuestionType[]).map(
                  (t) => (
                    <SelectItem key={t} value={t}>
                      {QUESTION_TYPE_LABEL[t]}
                    </SelectItem>
                  )
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label className="text-xs">Prompt</Label>
            <Input
              value={question.prompt}
              onChange={(e) => onChange({ prompt: e.target.value })}
              placeholder="e.g. What is the time complexity of binary search?"
              disabled={disabled}
            />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="grid gap-1.5">
            <Label className="text-xs">Skill slug (optional)</Label>
            <Input
              value={question.skillSlug}
              onChange={(e) => onChange({ skillSlug: e.target.value })}
              placeholder="e.g. data-structures"
              disabled={disabled}
            />
          </div>
          <div className="grid gap-1.5">
            <Label className="text-xs">Points</Label>
            <Input
              type="number"
              min={1}
              max={10}
              value={question.points}
              onChange={(e) =>
                onChange({ points: Number(e.target.value) || 1 })
              }
              disabled={disabled}
            />
          </div>
        </div>

        {/* Type-specific answer UI */}
        {question.type === "MCQ" && (
          <div className="grid gap-2">
            <Label className="text-xs">
              Options — pick the correct one with the radio
            </Label>
            <RadioGroup
              value={String(question.correctOption)}
              onValueChange={(v) => onChange({ correctOption: Number(v) })}
              className="gap-2"
            >
              {question.options.map((opt, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 rounded-md border border-border bg-card px-2 py-1.5"
                >
                  <RadioGroupItem value={String(i)} id={`${question.id}-opt-${i}`} />
                  <Label
                    htmlFor={`${question.id}-opt-${i}`}
                    className="text-xs font-normal text-muted-foreground"
                  >
                    {String.fromCharCode(65 + i)}
                  </Label>
                  <Input
                    value={opt}
                    onChange={(e) => onOptionChange(i, e.target.value)}
                    placeholder={`Option ${String.fromCharCode(65 + i)}`}
                    disabled={disabled}
                    className="h-8"
                  />
                </div>
              ))}
            </RadioGroup>
          </div>
        )}

        {question.type === "SHORT_ANSWER" && (
          <div className="grid gap-1.5">
            <Label className="text-xs">Expected answer</Label>
            <Input
              value={question.expectedAnswer}
              onChange={(e) => onChange({ expectedAnswer: e.target.value })}
              placeholder="e.g. O(log n)"
              disabled={disabled}
            />
            <p className="text-xs text-muted-foreground">
              Matched case-insensitively, trimmed.
            </p>
          </div>
        )}

        {question.type === "CODING" && (
          <div className="rounded-md border border-dashed border-border bg-muted/30 p-3 text-xs text-muted-foreground">
            Coding questions are <span className="font-medium">not auto-graded</span>.
            They&apos;re stored with the prompt and the response is recorded for
            manual review after submission.
          </div>
        )}

        <div className="flex items-center gap-2">
          <Badge
            variant="outline"
            className={DIFFICULTY_BADGE[question.difficulty]}
          >
            {DIFFICULTY_LABEL[question.difficulty]}
          </Badge>
          <span className="text-xs text-muted-foreground">
            {question.points} {question.points === 1 ? "point" : "points"}
          </span>
        </div>
      </div>
    </div>
  );
}
