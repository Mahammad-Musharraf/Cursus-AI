"use client";

import * as React from "react";
import { useSession } from "next-auth/react";
import {
  Briefcase,
  Building2,
  Lock,
  Mail,
  ShieldCheck,
  User as UserIcon,
} from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function RecruiterSettingsPage() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return (
      <div className="mx-auto w-full max-w-3xl">
        <PageHeader
          title="Profile"
          description="Your recruiter account details."
        />
        <LoadingState label="Loading profile…" />
      </div>
    );
  }

  const name = session?.user?.name ?? "—";
  const email = session?.user?.email ?? "—";
  const initials =
    name
      .split(" ")
      .filter(Boolean)
      .map((p) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "?";

  return (
    <div className="mx-auto w-full max-w-3xl">
      <PageHeader
        title="Profile"
        description="Your recruiter account details. This information is read-only for now."
      />

      {/* Identity card */}
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>
            Signed-in recruiter profile. Used to identify you when shortlisting
            candidates.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="size-14">
              <AvatarFallback className="bg-primary/10 text-base font-semibold text-primary">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <p className="truncate text-lg font-semibold text-foreground">
                {name}
              </p>
              <p className="truncate text-sm text-muted-foreground">{email}</p>
            </div>
            <Badge className="ml-auto hidden items-center gap-1.5 bg-primary/10 text-primary sm:inline-flex">
              <Briefcase className="size-3.5" />
              Recruiter
            </Badge>
          </div>

          <Separator />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field
              icon={UserIcon}
              label="Full name"
              value={name}
            />
            <Field icon={Mail} label="Email address" value={email} />
            <Field
              icon={Building2}
              label="Company"
              value="—"
              hint="Not configured for this account."
            />
            <Field
              icon={ShieldCheck}
              label="Role"
              value="Recruiter"
              hint="Can view candidates and manage a shortlist."
            />
          </div>
        </CardContent>
      </Card>

      {/* Permissions card */}
      <Card>
        <CardHeader>
          <CardTitle>Permissions</CardTitle>
          <CardDescription>
            What you can do as a recruiter on Cursus AI.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <PermissionRow label="Browse candidates by stage, career, or skill" />
          <PermissionRow label="Shortlist candidates and add private notes" />
          <PermissionRow label="Export your shortlist for follow-up" />
        </CardContent>
      </Card>

      {/* Edit (disabled) */}
      <div className="mt-6 flex justify-end">
        <Tooltip>
          <TooltipTrigger asChild>
            <span tabIndex={0} className="inline-flex">
              <Button variant="outline" disabled className="gap-2">
                <Lock className="size-4" />
                Edit profile
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent side="top">
            Profile editing isn&apos;t available yet.
          </TooltipContent>
        </Tooltip>
      </div>
    </div>
  );
}

function Field({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-secondary/40 p-4">
      <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </div>
      <p className="mt-1 truncate text-sm font-medium text-foreground">
        {value}
      </p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function PermissionRow({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-foreground">
      <span className="inline-flex size-5 items-center justify-center rounded-full bg-primary/10 text-primary">
        <ShieldCheck className="size-3.5" />
      </span>
      {label}
    </div>
  );
}
