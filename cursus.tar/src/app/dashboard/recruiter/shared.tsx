"use client";

import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

// ---- Types matching the recruiter API contract ----

export type CandidateStatus =
  | "no-assessment"
  | "at-risk"
  | "on-track"
  | "ready";

export type CandidateSkill = {
  skill: string;
  current: number;
  target: number;
};

export type Candidate = {
  id: string;
  name: string;
  email: string;
  stageLabel: string | null;
  careerTitle: string | null;
  careerId?: string | null;
  avgCurrent: number;
  readinessPct: number;
  status: CandidateStatus;
  solvedProblems: number;
  shortlisted: boolean;
  skills: CandidateSkill[];
};

export type ShortlistedCandidate = Candidate & {
  note: string | null;
  shortlistedAt: string; // ISO date string (serialized Date)
};

// ---- Status helpers ----

export const STATUS_LABELS: Record<CandidateStatus, string> = {
  "no-assessment": "No assessment",
  "at-risk": "At risk",
  "on-track": "On track",
  ready: "Ready",
};

const STATUS_CLASS: Record<CandidateStatus, string> = {
  "no-assessment":
    "border-transparent bg-secondary text-muted-foreground",
  "at-risk":
    "border-transparent bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  "on-track": "border-transparent bg-primary/10 text-primary",
  ready: "border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
};

export function StatusBadge({
  status,
  className,
}: {
  status: CandidateStatus;
  className?: string;
}) {
  return (
    <Badge className={cn(STATUS_CLASS[status], className)}>
      {STATUS_LABELS[status]}
    </Badge>
  );
}

// ---- Skill bars (top N) ----

export function SkillBars({
  skills,
  max = 3,
}: {
  skills: CandidateSkill[];
  max?: number;
}) {
  if (!skills?.length) {
    return (
      <p className="text-xs text-muted-foreground">No skill data available.</p>
    );
  }
  const top = [...skills]
    .sort((a, b) => b.current - a.current)
    .slice(0, max);
  return (
    <div className="space-y-2.5">
      {top.map((s) => {
        const pct =
          s.target > 0
            ? Math.min(100, Math.round((s.current / s.target) * 100))
            : 0;
        return (
          <div key={s.skill} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="truncate font-medium text-foreground">
                {s.skill}
              </span>
              <span className="text-muted-foreground">
                {s.current}
                <span className="text-muted-foreground/60">/{s.target}</span>
              </span>
            </div>
            <Progress value={pct} className="h-1.5" />
          </div>
        );
      })}
    </div>
  );
}

// ---- Small "metric" block for the candidate cards ----

export function MetricBlock({
  label,
  value,
  hint,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="min-w-0">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-xl font-semibold tracking-tight text-foreground">
        {value}
      </p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

// ---- Helpers ----

export function initialsOf(name: string): string {
  return (
    name
      .split(" ")
      .filter(Boolean)
      .map((p) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase() || "?"
  );
}

export function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(undefined, {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}
