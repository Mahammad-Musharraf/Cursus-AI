"use client";

import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  XCircle,
  ExternalLink,
  Link2,
  Calendar,
  Building2,
  FileText,
  ShieldCheck,
  Filter,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";

type CertStatus = "PENDING" | "APPROVED" | "REJECTED";

type CertificateWithUser = {
  id: string;
  userId: string;
  title: string;
  issuer: string;
  issuedDate: string;
  credentialUrl: string | null;
  filePath: string;
  fileType: string;
  fileSizeKb: number;
  status: CertStatus;
  reviewerNote: string | null;
  reviewedAt: string | null;
  createdAt: string;
  updatedAt: string;
  user: { id: string; name: string; email: string };
};

const STATUS_META: Record<CertStatus, { label: string; className: string }> = {
  PENDING: {
    label: "Pending",
    className:
      "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  },
  APPROVED: {
    label: "Approved",
    className:
      "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  },
  REJECTED: {
    label: "Rejected",
    className:
      "border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
  },
};

type FilterValue = "all" | "PENDING" | "APPROVED" | "REJECTED";

const FILTER_LABELS: Record<FilterValue, string> = {
  all: "All statuses",
  PENDING: "Pending",
  APPROVED: "Approved",
  REJECTED: "Rejected",
};

function formatDisplayDate(d: string): string {
  if (!d) return "—";
  const [y, m, day] = d.split("-");
  if (!y || !m || !day) return d;
  const dt = new Date(Number(y), Number(m) - 1, Number(day));
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function formatTimestamp(s: string | null): string {
  if (!s) return "—";
  const dt = new Date(s);
  if (Number.isNaN(dt.getTime())) return "—";
  return dt.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export default function CollegeCertificatesPage() {
  const [certs, setCerts] = useState<CertificateWithUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterValue>("PENDING");

  // Review dialog state
  const [reviewTarget, setReviewTarget] = useState<{
    id: string;
    action: "APPROVED" | "REJECTED";
    title: string;
    studentName: string;
  } | null>(null);
  const [reviewNote, setReviewNote] = useState("");
  const [submittingId, setSubmittingId] = useState<string | null>(null);

  function load() {
    setLoading(true);
    setError(null);
    api<{ certificates: CertificateWithUser[] }>("/api/certificates").then(
      (res) => {
        setLoading(false);
        if (res.data) setCerts(res.data.certificates);
        else setError(res.error || "Failed to load certificates.");
      }
    );
  }

  useEffect(() => {
    // Initial load — keep setState out of the effect body (initial state is
    // already loading:true / error:null). The standalone `load()` is used by
    // the retry button as an event handler.
    let active = true;
    api<{ certificates: CertificateWithUser[] }>("/api/certificates").then(
      (res) => {
        if (!active) return;
        setLoading(false);
        if (res.data) setCerts(res.data.certificates);
        else setError(res.error || "Failed to load certificates.");
      }
    );
    return () => {
      active = false;
    };
  }, []);

  // Filtered + sorted list: PENDING first (regardless of filter), then by createdAt desc.
  const filtered = useMemo(() => {
    const list =
      filter === "all" ? certs : certs.filter((c) => c.status === filter);
    const rank = (s: CertStatus) =>
      s === "PENDING" ? 0 : s === "APPROVED" ? 1 : 2;
    return [...list].sort((a, b) => {
      const r = rank(a.status) - rank(b.status);
      if (r !== 0) return r;
      return b.createdAt.localeCompare(a.createdAt);
    });
  }, [certs, filter]);

  const pendingCount = certs.filter((c) => c.status === "PENDING").length;

  function openReview(
    c: CertificateWithUser,
    action: "APPROVED" | "REJECTED"
  ) {
    setReviewTarget({
      id: c.id,
      action,
      title: c.title,
      studentName: c.user.name,
    });
    setReviewNote("");
  }

  function closeReview() {
    setReviewTarget(null);
    setReviewNote("");
  }

  async function submitReview() {
    if (!reviewTarget) return;
    const { id, action } = reviewTarget;
    setSubmittingId(id);
    const res = await api<{ ok: boolean; certificate: CertificateWithUser }>(
      `/api/certificates/${id}/review`,
      {
        method: "POST",
        body: JSON.stringify({
          status: action,
          reviewerNote: reviewNote.trim() || undefined,
        }),
      }
    );
    setSubmittingId(null);
    if (res.data) {
      // Keep the user record from the existing row (the review API only
      // returns the certificate, not the nested user).
      setCerts((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, ...res.data!.certificate, user: c.user } : c
        )
      );
      toast.success(
        action === "APPROVED"
          ? "Certificate approved."
          : "Certificate rejected.",
        {
          description:
            action === "APPROVED"
              ? "The student will be notified."
              : "The student can re-upload with changes.",
        }
      );
      closeReview();
    } else {
      toast.error(res.error || "Could not submit review.");
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Certificate verification"
        description="Review certificates submitted by students in your batch."
      >
        {pendingCount > 0 && (
          <Badge variant="secondary" className="font-medium">
            {pendingCount} pending
          </Badge>
        )}
      </PageHeader>

      {/* Filter bar */}
      <div className="flex flex-wrap items-end gap-3">
        <div className="grid gap-1.5">
          <Label className="text-xs text-muted-foreground">Status</Label>
          <Select
            value={filter}
            onValueChange={(v) => setFilter(v as FilterValue)}
          >
            <SelectTrigger className="w-[180px]" size="sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {(Object.keys(FILTER_LABELS) as FilterValue[]).map((f) => (
                <SelectItem key={f} value={f}>
                  {FILTER_LABELS[f]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <p className="text-xs text-muted-foreground">
          Showing {filtered.length} of {certs.length}
        </p>
      </div>

      {/* Body */}
      {loading ? (
        <LoadingState label="Loading certificates…" />
      ) : error ? (
        <ErrorState
          message={error}
          action={
            <Button variant="outline" onClick={load}>
              Try again
            </Button>
          }
        />
      ) : filtered.length === 0 ? (
        certs.length === 0 ? (
          <EmptyState
            icon={ShieldCheck}
            title="No certificates to review 🎉"
            description="When students upload certificates for verification, they'll appear here for your review."
          />
        ) : (
          <EmptyState
            icon={Filter}
            title={`No ${filter.toLowerCase()} certificates`}
            description="Try a different filter to see other statuses."
            action={
              <Button variant="outline" onClick={() => setFilter("all")}>
                Show all
              </Button>
            }
          />
        )
      ) : (
        <div className="max-h-[32rem] overflow-y-auto scrollbar-thin pr-1">
          <ul className="grid gap-3">
            {filtered.map((c) => {
              const meta = STATUS_META[c.status];
              const isSubmitting = submittingId === c.id;
              return (
                <li key={c.id}>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                        <div className="min-w-0 flex-1">
                          {/* Student row */}
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="inline-flex size-8 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                              {initialsOf(c.user.name)}
                            </span>
                            <div className="min-w-0">
                              <p className="truncate text-sm font-semibold text-foreground">
                                {c.user.name}
                              </p>
                              <p className="truncate text-xs text-muted-foreground">
                                {c.user.email}
                              </p>
                            </div>
                            <Badge
                              variant="outline"
                              className={meta.className}
                            >
                              {meta.label}
                            </Badge>
                          </div>

                          {/* Cert details */}
                          <div className="mt-3">
                            <p className="font-medium text-foreground">
                              {c.title}
                            </p>
                            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                              <span className="inline-flex items-center gap-1">
                                <Building2 className="size-3.5" />
                                {c.issuer}
                              </span>
                              <span className="inline-flex items-center gap-1">
                                <Calendar className="size-3.5" />
                                {formatDisplayDate(c.issuedDate)}
                              </span>
                              <span className="inline-flex items-center gap-1">
                                <FileText className="size-3.5" />
                                {c.fileType.toUpperCase()} ·{" "}
                                {c.fileSizeKb.toLocaleString()} KB
                              </span>
                            </div>
                          </div>

                          {/* File + credential links */}
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            <Button asChild variant="outline" size="sm">
                              <a
                                href={c.filePath}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="size-4" />
                                View file
                              </a>
                            </Button>
                            {c.credentialUrl && (
                              <Button asChild variant="ghost" size="sm">
                                <a
                                  href={c.credentialUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <Link2 className="size-4" />
                                  Credential URL
                                </a>
                              </Button>
                            )}
                          </div>

                          {/* Reviewer note (for already reviewed) */}
                          {c.reviewerNote && (
                            <div className="mt-3 rounded-md border border-border bg-muted/40 p-3 text-sm">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Reviewer note
                              </p>
                              <p className="mt-1 text-foreground">
                                {c.reviewerNote}
                              </p>
                              {c.reviewedAt && (
                                <p className="mt-1 text-xs text-muted-foreground">
                                  Reviewed on {formatTimestamp(c.reviewedAt)}
                                </p>
                              )}
                            </div>
                          )}

                          {/* Reviewed timestamp (when no note) */}
                          {!c.reviewerNote && c.reviewedAt && (
                            <p className="mt-3 text-xs text-muted-foreground">
                              Reviewed on {formatTimestamp(c.reviewedAt)}
                            </p>
                          )}
                        </div>

                        {/* Actions */}
                        {c.status === "PENDING" && (
                          <div className="flex shrink-0 flex-col gap-2 sm:flex-row lg:flex-col">
                            <Button
                              size="sm"
                              onClick={() => openReview(c, "APPROVED")}
                              disabled={isSubmitting}
                            >
                              {isSubmitting ? (
                                <Loader2 className="size-4 animate-spin" />
                              ) : (
                                <CheckCircle2 className="size-4" />
                              )}
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openReview(c, "REJECTED")}
                              disabled={isSubmitting}
                            >
                              <XCircle className="size-4" />
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {/* Review dialog */}
      <Dialog
        open={!!reviewTarget}
        onOpenChange={(open) => {
          if (!open) closeReview();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {reviewTarget?.action === "APPROVED"
                ? "Approve certificate"
                : "Reject certificate"}
            </DialogTitle>
            <DialogDescription>
              {reviewTarget?.action === "APPROVED"
                ? `Confirm approval of "${reviewTarget?.title}" from ${reviewTarget?.studentName}. The student will be notified.`
                : `Reject "${reviewTarget?.title}" from ${reviewTarget?.studentName}. Add a note so they can fix and re-upload.`}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-1.5">
            <Label htmlFor="reviewer-note">
              Reviewer note{" "}
              <span className="font-normal text-muted-foreground">
                (optional)
              </span>
            </Label>
            <Textarea
              id="reviewer-note"
              value={reviewNote}
              onChange={(e) => setReviewNote(e.target.value)}
              placeholder={
                reviewTarget?.action === "APPROVED"
                  ? "e.g. Verified against the NPTEL portal."
                  : "e.g. Issuer name doesn't match. Please re-upload."
              }
              maxLength={280}
              rows={3}
            />
            <p className="text-right text-xs text-muted-foreground">
              {reviewNote.length}/280
            </p>
          </div>

          <DialogFooter>
            <Button
              variant="ghost"
              onClick={closeReview}
              disabled={!!submittingId}
            >
              Cancel
            </Button>
            <Button
              variant={
                reviewTarget?.action === "APPROVED" ? "default" : "destructive"
              }
              onClick={submitReview}
              disabled={!!submittingId}
            >
              {submittingId ? (
                <Loader2 className="size-4 animate-spin" />
              ) : reviewTarget?.action === "APPROVED" ? (
                <CheckCircle2 className="size-4" />
              ) : (
                <XCircle className="size-4" />
              )}
              {reviewTarget?.action === "APPROVED" ? "Approve" : "Reject"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
