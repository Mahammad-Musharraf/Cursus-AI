"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  ArrowLeft,
  Copy,
  Mail,
  Building2,
  KeyRound,
  User,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { api } from "@/lib/api";
import { toast } from "sonner";

type DashboardData = {
  collegeCode: string | null;
  collegeName: string | null;
};

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function FieldRow({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
  hint?: string;
}) {
  return (
    <div className="flex items-start gap-3 py-3">
      <span className="mt-0.5 inline-flex size-9 shrink-0 items-center justify-center rounded-md bg-secondary text-muted-foreground">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="mt-0.5 truncate text-sm font-medium text-foreground">
          {value}
        </p>
        {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
      </div>
    </div>
  );
}

export default function CollegeSettingsPage() {
  const { data: session } = useSession();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    api<DashboardData>("/api/college/dashboard").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load profile.");
    });
    return () => {
      active = false;
    };
  }, []);

  const name = session?.user?.name ?? "—";
  const email = session?.user?.email ?? "—";

  return (
    <div className="space-y-6">
      <PageHeader
        title="College profile"
        description="Your account details and the join code students use to enter your batch."
      >
        <Button variant="outline" asChild>
          <Link href="/dashboard/college">
            <ArrowLeft className="size-4" />
            Back to dashboard
          </Link>
        </Button>
      </PageHeader>

      {loading ? (
        <LoadingState label="Loading profile…" />
      ) : error ? (
        <ErrorState
          message={error}
          action={
            <Button
              variant="outline"
              onClick={() => {
                setError(null);
                setLoading(true);
                api<DashboardData>("/api/college/dashboard").then((res) => {
                  setLoading(false);
                  if (res.data) setData(res.data);
                  else setError(res.error || "Failed to load profile.");
                });
              }}
            >
              Try again
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Profile details */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Account details</CardTitle>
              <CardDescription>
                Read-only. Contact an administrator if anything needs updating.
              </CardDescription>
            </CardHeader>
            <CardContent className="divide-y divide-border">
              <FieldRow icon={User} label="Name" value={name} />
              <FieldRow icon={Mail} label="Email" value={email} />
              <FieldRow
                icon={Building2}
                label="College name"
                value={data?.collegeName || "Not set"}
              />
            </CardContent>
          </Card>

          {/* College code */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>College join code</CardTitle>
              <CardDescription>
                Share this with your students. They&apos;ll enter it during
                signup to join your batch.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {data?.collegeCode ? (
                <div className="space-y-4">
                  <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 p-5 text-center">
                    <span className="mb-2 inline-flex size-9 items-center justify-center rounded-full bg-primary/10 text-primary">
                      <KeyRound className="size-4" />
                    </span>
                    <p className="font-mono text-3xl font-bold tracking-[0.2em] text-primary">
                      {data.collegeCode}
                    </p>
                  </div>
                  <Button
                    className="w-full"
                    onClick={async () => {
                      const ok = await copyText(data.collegeCode || "");
                      if (ok)
                        toast.success("College code copied to clipboard");
                      else
                        toast.error(
                          "Couldn't copy. Please copy it manually."
                        );
                    }}
                  >
                    <Copy className="size-4" />
                    Copy code
                  </Button>
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-border bg-secondary/40 p-5 text-center">
                  <p className="text-sm text-muted-foreground">
                    No college code is set on your account.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
