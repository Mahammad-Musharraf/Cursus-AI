"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Users,
  CheckCircle2,
  TrendingUp,
  AlertTriangle,
  Download,
  ArrowRight,
  Copy,
  GraduationCap,
  Sparkles,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { StatCard } from "@/components/stat-card";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { toast } from "sonner";
import { StatusBadge, type StudentStatus } from "./_components/status-badge";
import { ReadinessRing } from "./_components/readiness-ring";

type AtRiskStudent = {
  id: string;
  name: string;
  email: string;
  stageLabel: string | null;
  careerTitle: string | null;
  avgCurrent: number;
  readinessPct: number;
  status: StudentStatus;
  solvedProblems: number;
};

type HeatmapItem = { skill: string; avg: number; students: number };

type DashboardData = {
  collegeCode: string | null;
  collegeName: string | null;
  thresholds: { ready: number; atRisk: number };
  batch: {
    total: number;
    ready: number;
    onTrack: number;
    atRisk: number;
    readinessPct: number;
  };
  heatmap: HeatmapItem[];
  atRisk: AtRiskStudent[];
  students: {
    id: string;
    name: string;
    email: string;
    stageLabel: string | null;
    careerTitle: string | null;
    hasAssessment: boolean;
    avgCurrent: number;
    readinessPct: number;
    status: StudentStatus;
    solvedProblems: number;
  }[];
  skills: string[];
};

function barColor(avg: number) {
  if (avg < 40) return "#dc2626";
  if (avg < 70) return "#d97706";
  return "#16a34a";
}

function handleExport() {
  window.location.href = "/api/college/export";
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

export default function CollegeDashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    api<DashboardData>("/api/college/dashboard").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load dashboard.");
    });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Batch dashboard"
          description="Track batch readiness, spot at-risk students, and export reports."
        />
        <LoadingState label="Loading your batch…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Batch dashboard"
          description="Track batch readiness, spot at-risk students, and export reports."
        />
        <ErrorState
          message={error}
          action={
            <Button
              variant="outline"
              onClick={() => {
                setError(null);
                setLoading(true);
                api<DashboardData>("/api/college/dashboard").then((res) => {
                  setLoading(false);
                  if (res.data) setData(res.data);
                  else setError(res.error || "Failed to load dashboard.");
                });
              }}
            >
              Try again
            </Button>
          }
        />
      </div>
    );
  }

  // Empty batch state — show the join code prominently so T&P can share it.
  if (data && data.batch.total === 0) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Batch dashboard"
          description="Track batch readiness, spot at-risk students, and export reports."
        />
        <EmptyState
          icon={GraduationCap}
          title="No students in your batch yet"
          description="Students join your batch by signing up with your college join code. Share the code below with your students to get started."
          className="py-14"
          action={
            data.collegeCode ? (
              <div className="flex flex-col items-center gap-3">
                <div className="rounded-lg border border-dashed border-primary/40 bg-primary/5 px-4 py-3 text-center">
                  <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Your college join code
                  </p>
                  <p className="mt-1 font-mono text-2xl font-bold tracking-widest text-primary">
                    {data.collegeCode}
                  </p>
                </div>
                <Button
                  onClick={async () => {
                    const ok = await copyText(data.collegeCode || "");
                    if (ok) toast.success("College code copied to clipboard");
                    else toast.error("Couldn't copy. Please copy manually.");
                  }}
                >
                  <Copy className="size-4" />
                  Copy college code
                </Button>
              </div>
            ) : undefined
          }
        />
      </div>
    );
  }

  if (!data) return null;

  const { batch, heatmap, atRisk } = data;
  const heatmapHeight = Math.max(160, heatmap.length * 38 + 24);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Batch dashboard"
        description={
          data.collegeName
            ? `${data.collegeName} · ${batch.total} students in your batch`
            : `${batch.total} students in your batch`
        }
      >
        <Button variant="outline" asChild>
          <Link href="/dashboard/college/students">
            View all students
            <ArrowRight className="size-4" />
          </Link>
        </Button>
        <Button onClick={handleExport}>
          <Download className="size-4" />
          Export CSV
        </Button>
      </PageHeader>

      {/* Hero: Batch readiness */}
      <Card>
        <CardContent className="flex flex-col items-center gap-6 p-6 sm:flex-row sm:items-center sm:gap-10">
          <div className="flex shrink-0 items-center justify-center">
            <ReadinessRing value={batch.readinessPct} label="readiness" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-xl font-semibold tracking-tight text-foreground">
              Batch readiness
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">
                {batch.ready} of {batch.total}
              </span>{" "}
              students are placement-ready (avg&nbsp;score&nbsp;≥&nbsp;
              {data.thresholds.ready}).
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Badge variant="secondary">
                {batch.ready} ready
              </Badge>
              <Badge variant="secondary">
                {batch.onTrack} on-track
              </Badge>
              <Badge variant="secondary">
                {batch.atRisk} at-risk
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="Total students"
          value={batch.total}
          icon={Users}
          tone="primary"
        />
        <StatCard
          label="Placement-ready"
          value={batch.ready}
          hint={`≥ ${data.thresholds.ready} avg`}
          icon={CheckCircle2}
          tone="success"
        />
        <StatCard
          label="On track"
          value={batch.onTrack}
          hint={`${data.thresholds.atRisk}–${data.thresholds.ready - 1} avg`}
          icon={TrendingUp}
          tone="primary"
        />
        <StatCard
          label="At risk"
          value={batch.atRisk}
          hint={`avg < ${data.thresholds.atRisk} or no assessment`}
          icon={AlertTriangle}
          tone="warning"
        />
      </div>

      {/* Heatmap + At-risk list */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Skill heatmap */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>Average skill score across batch</CardTitle>
            <CardDescription>
              Lower bars need the most attention.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {heatmap.length === 0 ? (
              <EmptyState
                icon={Sparkles}
                title="No skill data yet"
                description="Once students take their first assessment, the average score per skill will appear here."
              />
            ) : (
              <div
                className="w-full"
                style={{ height: heatmapHeight }}
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={heatmap}
                    margin={{ top: 4, right: 16, bottom: 4, left: 8 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="#e2e8f0"
                      horizontal={false}
                    />
                    <XAxis
                      type="number"
                      domain={[0, 100]}
                      tick={{ fontSize: 12, fill: "#64748b" }}
                      axisLine={{ stroke: "#cbd5e1" }}
                      tickLine={false}
                    />
                    <YAxis
                      type="category"
                      dataKey="skill"
                      width={120}
                      tick={{ fontSize: 12, fill: "#0f172a" }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      cursor={{ fill: "#f1f5f9" }}
                      contentStyle={{
                        borderRadius: 8,
                        border: "1px solid #e2e8f0",
                        fontSize: 12,
                      }}
                      formatter={(v: number, _n, item) => {
                        const s = (item?.payload as HeatmapItem)?.students;
                        return [
                          `${v} avg${s ? ` · ${s} students` : ""}`,
                          "Avg score",
                        ];
                      }}
                    />
                    <Bar dataKey="avg" radius={[0, 6, 6, 0]} barSize={20}>
                      {heatmap.map((h) => (
                        <Cell key={h.skill} fill={barColor(h.avg)} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* At-risk students list */}
        <Card className="flex flex-col">
          <CardHeader>
            <CardTitle>At-risk students</CardTitle>
            <CardDescription>
              Needs work or hasn&apos;t taken the assessment yet.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-1">
            {atRisk.length === 0 ? (
              <EmptyState
                icon={Sparkles}
                title="No at-risk students 🎉"
                description="Every student in your batch has taken an assessment and is on track or placement-ready."
              />
            ) : (
              <div className="max-h-96 overflow-y-auto scrollbar-thin -mx-2 px-2">
                <ul className="divide-y divide-border">
                  {atRisk.map((s) => (
                    <li
                      key={s.id}
                      className="flex flex-col gap-2 py-3 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-foreground">
                          {s.name}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">
                          {s.careerTitle ?? "No career chosen"}
                          {s.stageLabel ? ` · ${s.stageLabel}` : ""}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className="text-sm font-semibold text-foreground">
                            {s.avgCurrent}
                            <span className="text-xs font-normal text-muted-foreground">
                              {" "}
                              avg
                            </span>
                          </p>
                          <p className="text-[11px] text-muted-foreground">
                            {s.readinessPct}% ready · {s.solvedProblems} solved
                          </p>
                        </div>
                        <StatusBadge status={s.status} />
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
