"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Download,
  FileSpreadsheet,
  Users,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { api } from "@/lib/api";

type StudentsResponse = {
  collegeCode: string | null;
  students: { id: string }[];
};

const INCLUDED_FIELDS = [
  { label: "Name", hint: "Student full name" },
  { label: "Email", hint: "Login email" },
  { label: "Stage", hint: "After 10th / 12th / In B.Tech" },
  { label: "Target career", hint: "Selected career track" },
  { label: "Assessment taken", hint: "Yes / No" },
  { label: "Avg score", hint: "Average across required skills (0–100)" },
  { label: "Target score", hint: "Average target across required skills" },
  { label: "Readiness %", hint: "avgCurrent ÷ avgTarget × 100" },
  { label: "Status", hint: "ready / on-track / at-risk / no-assessment" },
  { label: "Problems solved", hint: "Count of solved practice problems" },
  {
    label: "Per-skill scores",
    hint: "One column per skill in the batch (current 0–100)",
  },
];

function handleDownload() {
  window.location.href = "/api/college/export";
}

export default function CollegeExportPage() {
  const [data, setData] = useState<StudentsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    api<StudentsResponse>("/api/college/students").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load preview.");
    });
    return () => {
      active = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Export CSV"
          description="Download a CSV snapshot of your entire batch."
        />
        <LoadingState label="Preparing export…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Export CSV"
          description="Download a CSV snapshot of your entire batch."
        />
        <ErrorState
          message={error}
          action={
            <Button
              variant="outline"
              onClick={() => {
                setError(null);
                setLoading(true);
                api<StudentsResponse>("/api/college/students").then((res) => {
                  setLoading(false);
                  if (res.data) setData(res.data);
                  else setError(res.error || "Failed to load preview.");
                });
              }}
            >
              Try again
            </Button>
          }
        />
      </div>
    );
  }

  if (!data) return null;

  if (data.students.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Export CSV"
          description="Download a CSV snapshot of your entire batch."
        >
          <Button variant="outline" asChild>
            <Link href="/dashboard/college">
              <ArrowLeft className="size-4" />
              Back to dashboard
            </Link>
          </Button>
        </PageHeader>
        <EmptyState
          icon={Users}
          title="No students to export"
          description="Your batch is empty. Once students join with your college code, you can export their data here."
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Export CSV"
        description="Download a CSV snapshot of your entire batch."
      >
        <Button variant="outline" asChild>
          <Link href="/dashboard/college">
            <ArrowLeft className="size-4" />
            Back to dashboard
          </Link>
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Preview / primary action card */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Export preview</CardTitle>
            <CardDescription>
              Snapshot will include every student in your batch.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <div className="flex items-center gap-3 rounded-lg border border-primary/20 bg-primary/5 p-4">
              <span className="inline-flex size-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                <FileSpreadsheet className="size-5" />
              </span>
              <div>
                <p className="text-2xl font-bold tracking-tight text-foreground">
                  {data.students.length}
                </p>
                <p className="text-xs text-muted-foreground">
                  {data.students.length === 1
                    ? "student will be exported"
                    : "students will be exported"}
                </p>
              </div>
            </div>
            <Button size="lg" className="w-full" onClick={handleDownload}>
              <Download className="size-4" />
              Download CSV
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              The browser will download a file named{" "}
              <code className="rounded bg-secondary px-1 py-0.5 font-mono">
                cursus-batch-{data.collegeCode || "export"}.csv
              </code>
            </p>
          </CardContent>
        </Card>

        {/* What's included */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>What&apos;s included</CardTitle>
            <CardDescription>
              One row per student. Per-skill columns are appended automatically
              based on the skills present across your batch.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {INCLUDED_FIELDS.map((f) => (
                <li
                  key={f.label}
                  className="flex items-start gap-2 rounded-md border border-border bg-card p-3"
                >
                  <span className="mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-[10px] font-bold">
                    ✓
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-foreground">
                      {f.label}
                    </p>
                    <p className="text-xs text-muted-foreground">{f.hint}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
