"use client";

import { Badge } from "@/components/ui/badge";

export type StudentStatus =
  | "no-assessment"
  | "at-risk"
  | "on-track"
  | "ready";

const STATUS_META: Record<
  StudentStatus,
  { label: string; className: string }
> = {
  ready: {
    label: "Ready",
    className:
      "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  },
  "on-track": {
    label: "On track",
    className: "border-transparent bg-primary/10 text-primary",
  },
  "at-risk": {
    label: "At risk",
    className:
      "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  },
  "no-assessment": {
    label: "No assessment",
    className: "border-transparent bg-secondary text-muted-foreground",
  },
};

export function StatusBadge({ status }: { status: StudentStatus }) {
  const meta = STATUS_META[status] ?? STATUS_META["no-assessment"];
  return (
    <Badge variant="outline" className={meta.className}>
      {meta.label}
    </Badge>
  );
}
