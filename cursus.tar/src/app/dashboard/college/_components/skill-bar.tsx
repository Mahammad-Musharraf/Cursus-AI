"use client";

import { cn } from "@/lib/utils";

// A compact skill bar showing current vs target. The filled portion shows
// current score (colored by band) and the marker shows target. Gap is the
// empty space between current and target.
export function SkillBar({
  current,
  target,
  className,
}: {
  current: number;
  target: number;
  className?: string;
}) {
  const cur = Math.min(100, Math.max(0, current));
  const tgt = Math.min(100, Math.max(0, target));
  const bandColor =
    cur < 40 ? "#dc2626" : cur < 70 ? "#d97706" : "#16a34a";

  return (
    <div className={cn("w-full", className)}>
      <div className="relative h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full rounded-full transition-all"
          style={{
            width: `${cur}%`,
            backgroundColor: bandColor,
          }}
        />
        {/* Target marker */}
        <div
          className="absolute top-1/2 h-3 w-[2px] -translate-y-1/2 rounded-full bg-foreground/60"
          style={{ left: `${tgt}%` }}
          aria-hidden
        />
      </div>
    </div>
  );
}
