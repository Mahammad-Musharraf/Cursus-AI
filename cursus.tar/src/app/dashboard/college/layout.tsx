import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";

export default async function CollegeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?callbackUrl=/dashboard/college");
  if (user.role !== "COLLEGE") {
    redirect(`/dashboard/${user.role.toLowerCase()}`);
  }
  return <>{children}</>;
}
