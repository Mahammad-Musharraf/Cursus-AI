"use client";

import { useEffect, useState, Fragment } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Download,
  ChevronRight,
  Users,
  ClipboardCheck,
  ClipboardX,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import { api } from "@/lib/api";
import { StatusBadge, type StudentStatus } from "../_components/status-badge";
import { SkillBar } from "../_components/skill-bar";

type StudentSkill = {
  skill: string;
  current: number;
  target: number;
  gap: number;
};

type StudentRow = {
  id: string;
  name: string;
  email: string;
  stageLabel: string | null;
  careerTitle: string;
  hasAssessment: boolean;
  avgCurrent: number;
  readinessPct: number;
  status: StudentStatus;
  solvedProblems: number;
  totalProblems: number;
  skills: StudentSkill[];
};

type StudentsResponse = {
  collegeCode: string | null;
  students: StudentRow[];
};

function handleExport() {
  window.location.href = "/api/college/export";
}

export default function CollegeStudentsPage() {
  const [data, setData] = useState<StudentsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let active = true;
    api<StudentsResponse>("/api/college/students").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load students.");
    });
    return () => {
      active = false;
    };
  }, []);

  function toggleRow(id: string) {
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Students"
          description="Detailed per-student breakdown with per-skill scores."
        />
        <LoadingState label="Loading students…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Students"
          description="Detailed per-student breakdown with per-skill scores."
        />
        <ErrorState
          message={error}
          action={
            <Button
              variant="outline"
              onClick={() => {
                setError(null);
                setLoading(true);
                api<StudentsResponse>("/api/college/students").then((res) => {
                  setLoading(false);
                  if (res.data) setData(res.data);
                  else setError(res.error || "Failed to load students.");
                });
              }}
            >
              Try again
            </Button>
          }
        />
      </div>
    );
  }

  if (!data) return null;

  if (data.students.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Students"
          description="Detailed per-student breakdown with per-skill scores."
        >
          <Button variant="outline" asChild>
            <Link href="/dashboard/college">
              <ArrowLeft className="size-4" />
              Back to dashboard
            </Link>
          </Button>
          <Button onClick={handleExport}>
            <Download className="size-4" />
            Export CSV
          </Button>
        </PageHeader>
        <EmptyState
          icon={Users}
          title="No students in your batch yet"
          description="Students appear here once they sign up with your college code and take an assessment."
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Students"
        description={`${data.students.length} students · per-skill scores and readiness.`}
      >
        <Button variant="outline" asChild>
          <Link href="/dashboard/college">
            <ArrowLeft className="size-4" />
            Back to dashboard
          </Link>
        </Button>
        <Button onClick={handleExport}>
          <Download className="size-4" />
          Export CSV
        </Button>
      </PageHeader>

      <Card className="py-0">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10" />
                  <TableHead>Name</TableHead>
                  <TableHead>Career</TableHead>
                  <TableHead>Stage</TableHead>
                  <TableHead>Assessment</TableHead>
                  <TableHead className="text-right">Avg</TableHead>
                  <TableHead className="text-right">Readiness</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Solved</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.students.map((s) => {
                  const isOpen = !!expanded[s.id];
                  const hasSkills = s.skills.length > 0;
                  return (
                    <Fragment key={s.id}>
                      <TableRow
                        className="cursor-pointer"
                        onClick={() => hasSkills && toggleRow(s.id)}
                      >
                        <TableCell className="w-10">
                          {hasSkills && (
                            <ChevronRight
                              className={`size-4 text-muted-foreground transition-transform ${
                                isOpen ? "rotate-90" : ""
                              }`}
                            />
                          )}
                        </TableCell>
                        <TableCell className="min-w-[160px]">
                          <div className="font-medium text-foreground">
                            {s.name}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {s.email}
                          </div>
                        </TableCell>
                        <TableCell className="min-w-[140px] text-sm text-muted-foreground">
                          {s.careerTitle}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {s.stageLabel ?? "—"}
                        </TableCell>
                        <TableCell>
                          {s.hasAssessment ? (
                            <Badge
                              variant="outline"
                              className="border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                            >
                              <ClipboardCheck className="size-3" />
                              Yes
                            </Badge>
                          ) : (
                            <Badge
                              variant="outline"
                              className="border-transparent bg-secondary text-muted-foreground"
                            >
                              <ClipboardX className="size-3" />
                              No
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right tabular-nums font-medium">
                          {s.avgCurrent}
                        </TableCell>
                        <TableCell className="text-right tabular-nums">
                          {s.readinessPct}%
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={s.status} />
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-muted-foreground">
                          {s.solvedProblems}
                          <span className="text-xs">
                            {s.totalProblems > 0
                              ? ` / ${s.totalProblems}`
                              : ""}
                          </span>
                        </TableCell>
                      </TableRow>
                      {isOpen && hasSkills && (
                        <TableRow
                          className="bg-muted/30 hover:bg-muted/30"
                        >
                          <TableCell />
                          <TableCell colSpan={8} className="py-4">
                            <div className="space-y-3">
                              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                                Per-skill scores
                              </p>
                              <div className="grid grid-cols-1 gap-x-8 gap-y-3 sm:grid-cols-2">
                                {s.skills.map((sk) => (
                                  <div
                                    key={sk.skill}
                                    className="flex items-center gap-3"
                                  >
                                    <div className="w-28 shrink-0 truncate text-xs font-medium text-foreground">
                                      {sk.skill}
                                    </div>
                                    <SkillBar
                                      current={sk.current}
                                      target={sk.target}
                                      className="flex-1"
                                    />
                                    <div className="w-24 shrink-0 text-right text-[11px] tabular-nums text-muted-foreground">
                                      <span className="font-semibold text-foreground">
                                        {sk.current}
                                      </span>
                                      {" / "}
                                      {sk.target}
                                      {sk.gap > 0 && (
                                        <span className="text-amber-600">
                                          {" "}
                                          (−{sk.gap})
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <p className="text-xs text-muted-foreground">
        Tip: click a row to expand per-skill scores. Bars are colored by band
        (red&nbsp;&lt;&nbsp;40, amber 40–69, green&nbsp;≥&nbsp;70); the vertical
        marker shows the target.
      </p>
    </div>
  );
}
