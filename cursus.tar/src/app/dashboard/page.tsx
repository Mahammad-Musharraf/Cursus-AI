import { redirect } from "next/navigation";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";

export default async function DashboardIndex() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");

  if (u.role === "STUDENT") {
    const rec = await getCurrentUserRecord();
    if (!rec?.stage || !rec?.targetCareerId) redirect("/onboarding");
    redirect("/dashboard/student");
  }
  if (u.role === "COLLEGE") redirect("/dashboard/college");
  if (u.role === "RECRUITER") redirect("/dashboard/recruiter");
  redirect("/login");
}
