"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ClipboardCheck, Save, Info } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

type AssessmentData = {
  career: { id: string; title: string } | null;
  requiredSkills: { skill: string; target: number; weight?: number }[];
  scores: Record<string, number>;
  lastTakenAt: string | null;
};

function fmtDate(iso: string | null) {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function AssessmentPage() {
  const router = useRouter();
  const [data, setData] = useState<AssessmentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [saving, setSaving] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>(
    {}
  );

  useEffect(() => {
    api<AssessmentData>("/api/assessment").then((res) => {
      setLoading(false);
      if (res.data) {
        setData(res.data);
        const initial: Record<string, number> = {};
        for (const r of res.data.requiredSkills) {
          const v = res.data.scores[r.skill];
          initial[r.skill] = typeof v === "number" ? v : 0;
        }
        setScores(initial);
      } else {
        setError(res.error || "Failed to load assessment.");
      }
    });
  }, []);

  const avg = useMemo(() => {
    const vals = Object.values(scores);
    if (!vals.length) return 0;
    return Math.round(vals.reduce((s, n) => s + n, 0) / vals.length);
  }, [scores]);

  if (loading) {
    return (
      <>
        <PageHeader
          title="Skill assessment"
          description="Rate your current skill levels to get a personalized plan."
        />
        <LoadingState label="Loading assessment…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader title="Skill assessment" />
        <ErrorState message={error} />
      </>
    );
  }
  if (!data) return null;

  if (!data.career || data.requiredSkills.length === 0) {
    return (
      <>
        <PageHeader title="Skill assessment" />
        <EmptyState
          title="No target career yet"
          description="Pick a career during onboarding to unlock the assessment."
          icon={ClipboardCheck}
          action={
            <Button asChild>
              <a href="/onboarding">Complete onboarding</a>
            </Button>
          }
        />
      </>
    );
  }

  const lastDate = fmtDate(data.lastTakenAt);

  async function onSave() {
    if (!data?.career) return;
    setSaving(true);
    setFieldErrors({});
    try {
      const r = await fetch("/api/assessment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ careerId: data.career!.id, scores }),
      });
      const body = r.ok ? await r.json() : await r.json().catch(() => ({}));
      setSaving(false);
      if (r.ok) {
        toast.success("Assessment saved.", {
          description: "Your skill-gap analysis is ready.",
        });
        router.push("/dashboard/student/skill-gap");
      } else if (r.status === 422 && body?.fields) {
        setFieldErrors(body.fields as Record<string, string[]>);
        toast.error("Please fix the highlighted fields and try again.");
      } else {
        toast.error(body?.error || "Could not save assessment.");
      }
    } catch (e) {
      setSaving(false);
      toast.error(e instanceof Error ? e.message : "Network error");
    }
  }

  return (
    <>
      <PageHeader
        title="Skill assessment"
        description={`Self-rate your current level for each skill required for ${data.career.title}.`}
      />

      {lastDate && (
        <Alert className="mb-4">
          <Info className="size-4" />
          <AlertTitle>Last assessment: {lastDate}</AlertTitle>
          <AlertDescription>
            Re-taking the assessment creates a new snapshot — your previous
            scores are kept for history.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-3">
            <span>Rate your skills (0 – 100)</span>
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              Avg: {avg}
            </Badge>
          </CardTitle>
          <CardDescription>
            Drag each slider to your current level. The target shows the level
            expected for placement readiness.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {data.requiredSkills.map((r) => {
            const v = scores[r.skill] ?? 0;
            const err = fieldErrors[r.skill];
            return (
              <div key={r.skill}>
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Label className="text-sm font-medium text-foreground">
                      {r.skill}
                    </Label>
                    <Badge variant="outline" className="font-normal">
                      Target: {r.target}
                    </Badge>
                    {typeof r.weight === "number" && r.weight !== 1 && (
                      <Badge variant="secondary" className="font-normal">
                        weight {r.weight}
                      </Badge>
                    )}
                  </div>
                  <span
                    className={`tabular-nums text-sm font-semibold ${
                      v >= r.target
                        ? "text-emerald-600"
                        : v >= r.target * 0.6
                          ? "text-primary"
                          : "text-amber-600"
                    }`}
                  >
                    {v}
                  </span>
                </div>
                <div className="mt-2 px-1">
                  <Slider
                    value={[v]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(arr) =>
                      setScores((s) => ({ ...s, [r.skill]: arr[0] ?? 0 }))
                    }
                  />
                  {/* Target marker */}
                  <div className="relative mt-1 h-3 text-[10px] text-muted-foreground">
                    <span
                      className="absolute -translate-x-1/2"
                      style={{ left: `${r.target}%` }}
                    >
                      ↑ {r.target}
                    </span>
                  </div>
                </div>
                {err && (
                  <p className="mt-1 text-xs text-destructive">{err[0]}</p>
                )}
              </div>
            );
          })}

          <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-4">
            <p className="text-sm text-muted-foreground">
              {data.requiredSkills.length} skills rated. Your average is{" "}
              <span className="font-semibold text-foreground">{avg}</span>.
            </p>
            <Button onClick={onSave} disabled={saving}>
              <Save className="size-4" />
              {saving ? "Saving…" : "Save assessment"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
