"use client";

import { useEffect, useRef, useState } from "react";
import {
  Upload,
  FileText,
  ExternalLink,
  Link2,
  Calendar,
  Building2,
  Award,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type CertStatus = "PENDING" | "APPROVED" | "REJECTED";

type Certificate = {
  id: string;
  userId: string;
  title: string;
  issuer: string;
  issuedDate: string;
  credentialUrl: string | null;
  filePath: string;
  fileType: string;
  fileSizeKb: number;
  status: CertStatus;
  reviewerNote: string | null;
  reviewedAt: string | null;
  createdAt: string;
  updatedAt: string;
};

const STATUS_META: Record<CertStatus, { label: string; className: string }> = {
  PENDING: {
    label: "Pending review",
    className:
      "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  },
  APPROVED: {
    label: "Approved",
    className:
      "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  },
  REJECTED: {
    label: "Rejected",
    className:
      "border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
  },
};

const MAX_BYTES = 8 * 1024 * 1024; // 8MB — matches the server limit

function formatDisplayDate(d: string): string {
  if (!d) return "—";
  const [y, m, day] = d.split("-");
  if (!y || !m || !day) return d;
  const dt = new Date(Number(y), Number(m) - 1, Number(day));
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default function StudentCertificatesPage() {
  const [certs, setCerts] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [issuer, setIssuer] = useState("");
  const [issuedDate, setIssuedDate] = useState("");
  const [credentialUrl, setCredentialUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function load() {
    setLoading(true);
    setError(null);
    api<{ certificates: Certificate[] }>("/api/certificates").then((res) => {
      setLoading(false);
      if (res.data) setCerts(res.data.certificates);
      else setError(res.error || "Failed to load certificates.");
    });
  }

  useEffect(() => {
    // Initial load — keep setState out of the effect body (initial state is
    // already loading:true / error:null). The standalone `load()` is used by
    // the retry button as an event handler.
    let active = true;
    api<{ certificates: Certificate[] }>("/api/certificates").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) setCerts(res.data.certificates);
      else setError(res.error || "Failed to load certificates.");
    });
    return () => {
      active = false;
    };
  }, []);

  function resetForm() {
    setTitle("");
    setIssuer("");
    setIssuedDate("");
    setCredentialUrl("");
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  const formDirty =
    !!title || !!issuer || !!issuedDate || !!credentialUrl || !!file;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;

    // Client-side validation (mirrors server rules)
    if (title.trim().length < 2) {
      toast.error("Title must be at least 2 characters.");
      return;
    }
    if (issuer.trim().length < 2) {
      toast.error("Issuer must be at least 2 characters.");
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(issuedDate)) {
      toast.error("Please pick an issued date.");
      return;
    }
    if (!file) {
      toast.error("Please choose a certificate file to upload.");
      return;
    }
    if (file.size > MAX_BYTES) {
      toast.error("File too large (max 8MB).");
      return;
    }

    const fd = new FormData();
    fd.append("title", title.trim());
    fd.append("issuer", issuer.trim());
    fd.append("issuedDate", issuedDate);
    if (credentialUrl.trim()) fd.append("credentialUrl", credentialUrl.trim());
    fd.append("file", file);

    setSubmitting(true);
    try {
      // NOTE: use raw fetch (not api()) so the browser sets the correct
      // multipart/form-data Content-Type with a boundary.
      const res = await fetch("/api/certificates", {
        method: "POST",
        body: fd,
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        toast.error(data?.error || `Upload failed (${res.status})`);
        return;
      }
      toast.success("Certificate uploaded.", {
        description: "Your college will review it shortly.",
      });
      if (data?.certificate) {
        setCerts((prev) => [data.certificate as Certificate, ...prev]);
      }
      resetForm();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Network error");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Certificates"
        description="Upload your certificates for your college to verify."
      />

      {/* Upload card — the primary action */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <span className="inline-flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
              <Upload className="size-4" />
            </span>
            Upload a certificate
          </CardTitle>
          <CardDescription>
            Accepted formats: PDF, PNG, JPG or WEBP. Max 8&nbsp;MB.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="cert-title">Title</Label>
                <Input
                  id="cert-title"
                  placeholder="e.g. NPTEL Data Structures"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  maxLength={120}
                  required
                  disabled={submitting}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cert-issuer">Issuer</Label>
                <Input
                  id="cert-issuer"
                  placeholder="e.g. NPTEL / IIT Madras"
                  value={issuer}
                  onChange={(e) => setIssuer(e.target.value)}
                  maxLength={120}
                  required
                  disabled={submitting}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cert-date">Issued date</Label>
                <Input
                  id="cert-date"
                  type="date"
                  value={issuedDate}
                  onChange={(e) => setIssuedDate(e.target.value)}
                  max={new Date().toISOString().slice(0, 10)}
                  required
                  disabled={submitting}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cert-url">
                  Credential URL{" "}
                  <span className="font-normal text-muted-foreground">
                    (optional)
                  </span>
                </Label>
                <Input
                  id="cert-url"
                  type="url"
                  placeholder="https://verify.example.com/…"
                  value={credentialUrl}
                  onChange={(e) => setCredentialUrl(e.target.value)}
                  disabled={submitting}
                />
              </div>
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="cert-file">Certificate file</Label>
              <Input
                id="cert-file"
                ref={fileInputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                required
                disabled={submitting}
              />
              {file && (
                <p className="text-xs text-muted-foreground">
                  {file.name} · {(file.size / 1024).toFixed(0)} KB
                </p>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Button type="submit" disabled={submitting}>
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Uploading…
                  </>
                ) : (
                  <>
                    <Upload className="size-4" />
                    Upload certificate
                  </>
                )}
              </Button>
              {formDirty && (
                <Button
                  type="button"
                  variant="ghost"
                  onClick={resetForm}
                  disabled={submitting}
                >
                  Clear
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      {/* List */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">
          {certs.length > 0
            ? `Your certificates (${certs.length})`
            : "Your certificates"}
        </h2>

        {loading ? (
          <LoadingState label="Loading certificates…" />
        ) : error ? (
          <ErrorState
            message={error}
            action={
              <Button variant="outline" onClick={load}>
                Try again
              </Button>
            }
          />
        ) : certs.length === 0 ? (
          <EmptyState
            icon={Award}
            title="No certificates yet"
            description="Upload your first certificate above — your college T&P cell will verify it and it'll appear on your profile."
          />
        ) : (
          <div className="max-h-[28rem] overflow-y-auto scrollbar-thin pr-1">
            <ul className="grid gap-3">
              {certs.map((c) => {
                const meta = STATUS_META[c.status];
                return (
                  <li key={c.id}>
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="font-semibold text-foreground">
                                {c.title}
                              </h3>
                              <Badge
                                variant="outline"
                                className={meta.className}
                              >
                                {meta.label}
                              </Badge>
                            </div>
                            <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                              <span className="inline-flex items-center gap-1">
                                <Building2 className="size-3.5" />
                                {c.issuer}
                              </span>
                              <span className="inline-flex items-center gap-1">
                                <Calendar className="size-3.5" />
                                {formatDisplayDate(c.issuedDate)}
                              </span>
                              <span className="inline-flex items-center gap-1">
                                <FileText className="size-3.5" />
                                {c.fileType.toUpperCase()} ·{" "}
                                {c.fileSizeKb.toLocaleString()} KB
                              </span>
                            </div>
                          </div>

                          <div className="flex shrink-0 flex-wrap items-center gap-2">
                            <Button asChild variant="outline" size="sm">
                              <a
                                href={c.filePath}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="size-4" />
                                View file
                              </a>
                            </Button>
                            {c.credentialUrl && (
                              <Button asChild variant="ghost" size="sm">
                                <a
                                  href={c.credentialUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <Link2 className="size-4" />
                                  Credential
                                </a>
                              </Button>
                            )}
                          </div>
                        </div>

                        {c.reviewerNote && (
                          <div className="mt-3 rounded-md border border-border bg-muted/40 p-3 text-sm">
                            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                              Reviewer note
                            </p>
                            <p className="mt-1 text-foreground">
                              {c.reviewerNote}
                            </p>
                            {c.reviewedAt && (
                              <p className="mt-1 text-xs text-muted-foreground">
                                Reviewed on{" "}
                                {new Date(c.reviewedAt).toLocaleDateString(
                                  undefined,
                                  {
                                    day: "numeric",
                                    month: "short",
                                    year: "numeric",
                                  }
                                )}
                              </p>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </section>
    </div>
  );
}
