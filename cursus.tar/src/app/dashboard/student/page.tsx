"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import {
  ArrowRight,
  ClipboardCheck,
  Code2,
  Flame,
  MapPin,
  Sparkles,
  Target as TargetIcon,
  TrendingUp,
  Trophy,
} from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { StatCard } from "@/components/stat-card";
import { api } from "@/lib/api";
import {
  AT_RISK_THRESHOLD,
  READY_THRESHOLD,
} from "@/lib/constants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CareerMatchCard } from "./_components/career-match-card";
import { SkillRadar } from "./_components/skill-radar";
import { TodayProblemsCard } from "./_components/today-problems-card";
import { WeeklyPlanCard } from "./_components/weekly-plan-card";
import type { PlanData } from "./_components/types";

type Summary = {
  stage: string | null;
  stageLabel: string | null;
  career: {
    id: string;
    title: string;
    category: string;
    summary: string;
    avgSalary: string | null;
  } | null;
  requiredSkills: { skill: string; target: number; weight?: number }[];
  roadmap: {
    title: string;
    description: string;
    skills?: string[];
  }[];
  aggregates: {
    hasAssessment: boolean;
    avgCurrent: number;
    avgTarget: number;
    readinessPct: number;
    gapCount: number;
    solvedProblems: number;
    totalProblems: number;
    availableProblems: number;
    status: "no-assessment" | "at-risk" | "on-track" | "ready";
  };
  skillGaps: {
    skill: string;
    target: number;
    current: number;
    gap: number;
    band: { label: string; tone: "low" | "mid" | "high" };
  }[];
  scores: Record<string, number>;
};

type CareerMatchData = {
  recommendations: {
    careerId: string;
    slug: string;
    title: string;
    category: string;
    matchPct: number;
    reasons: string[];
  }[];
  chosen: {
    id: string;
    title: string;
    slug: string;
    category: string;
  } | null;
  confirmed: boolean;
};

function statusMeta(status: Summary["aggregates"]["status"]): {
  label: string;
  tone: "low" | "mid" | "high";
  color: string;
  ringStroke: string;
} {
  switch (status) {
    case "ready":
      return {
        label: "Placement-ready",
        tone: "high",
        color: "text-emerald-600",
        ringStroke: "#10b981",
      };
    case "on-track":
      return {
        label: "On track",
        tone: "mid",
        color: "text-primary",
        ringStroke: "oklch(0.45 0.18 264)",
      };
    case "at-risk":
      return {
        label: "At risk",
        tone: "low",
        color: "text-amber-600",
        ringStroke: "#f59e0b",
      };
    default:
      return {
        label: "No assessment yet",
        tone: "low",
        color: "text-muted-foreground",
        ringStroke: "oklch(0.5 0.012 250)",
      };
  }
}

export default function StudentDashboardPage() {
  const { data: session } = useSession();
  const [summary, setSummary] = useState<Summary | null>(null);
  const [careerMatch, setCareerMatch] = useState<CareerMatchData | null>(null);
  const [plan, setPlan] = useState<PlanData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      api<Summary>("/api/student/summary"),
      api<CareerMatchData>("/api/student/career-match"),
      api<PlanData>("/api/student/plan"),
    ]).then(([s, c, p]) => {
      if (cancelled) return;
      setLoading(false);
      // Summary is critical — bail if it failed.
      if (s.error || !s.data) {
        setError(s.error || "Failed to load your dashboard.");
        return;
      }
      setSummary(s.data);
      if (c.data) setCareerMatch(c.data);
      if (p.data) setPlan(p.data);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) {
    return (
      <>
        <PageHeader
          title="Dashboard"
          description="Your placement journey at a glance."
        />
        <LoadingState label="Loading your dashboard…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader
          title="Dashboard"
          description="Your placement journey at a glance."
        />
        <ErrorState message={error} />
      </>
    );
  }
  if (!summary || !summary.career) {
    return (
      <>
        <PageHeader title="Dashboard" />
        <EmptyState
          title="No career selected"
          description="Complete onboarding to pick your target career and unlock your dashboard."
          action={
            <Button asChild>
              <Link href="/onboarding">Choose a career</Link>
            </Button>
          }
        />
      </>
    );
  }

  const firstName =
    (session?.user?.name || "").split(" ")[0] || "there";
  const a = summary.aggregates;
  const meta = statusMeta(a.status);
  const topGaps = [...summary.skillGaps]
    .sort((x, y) => y.gap - x.gap)
    .slice(0, 4);
  const nextMilestone = summary.roadmap?.[0];

  // Today's goal from the plan
  const todayItems = plan?.todayItems ?? [];
  const todayTotal = todayItems.length;
  const todayDone = todayItems.filter((i) => i.done).length;
  const todayLeft = todayTotal - todayDone;
  const goalComplete = todayTotal > 0 && todayLeft === 0;
  const restDay = todayTotal === 0;
  const weeklyPct = plan?.progress?.pct ?? 0;

  const goalChip = (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground shadow-xs">
      <Flame
        className={
          goalComplete
            ? "size-3.5 text-emerald-600"
            : restDay
              ? "size-3.5 text-muted-foreground"
              : "size-3.5 text-primary"
        }
      />
      {goalComplete
        ? "Goal complete! 🎉"
        : restDay
          ? "Rest day ☕"
          : `${todayLeft} problem${todayLeft === 1 ? "" : "s"} left today`}
    </span>
  );

  return (
    <>
      <PageHeader
        title={`Hi, ${firstName}`}
        description="Here's a snapshot of where you stand and what to do next."
      >
        {goalChip}
      </PageHeader>

      {/* Top row: hero + career match */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Hero */}
        <Card className="overflow-hidden">
          <CardContent className="p-6">
            <div className="grid gap-6 sm:grid-cols-[1fr_auto] sm:items-center">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge
                    variant="secondary"
                    className="bg-primary/10 text-primary"
                  >
                    <TargetIcon className="size-3" />
                    Target career
                  </Badge>
                  <Badge variant="outline">{summary.career.category}</Badge>
                  {summary.stageLabel && (
                    <Badge variant="outline">{summary.stageLabel}</Badge>
                  )}
                </div>
                <h2 className="mt-3 text-2xl font-semibold tracking-tight text-foreground">
                  {summary.career.title}
                </h2>
                <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
                  {summary.career.summary}
                </p>
                {summary.career.avgSalary && (
                  <p className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-foreground">
                    <Trophy className="size-4 text-primary" />
                    Avg. package {summary.career.avgSalary}
                  </p>
                )}
                <div className="mt-5 flex flex-wrap gap-2">
                  {a.hasAssessment ? (
                    <Button asChild>
                      <Link href="/dashboard/student/problems">
                        Solve today&apos;s problems
                        <ArrowRight className="size-4" />
                      </Link>
                    </Button>
                  ) : (
                    <Button asChild>
                      <Link href="/dashboard/student/assessment">
                        Take assessment
                        <ArrowRight className="size-4" />
                      </Link>
                    </Button>
                  )}
                  {a.hasAssessment && (
                    <Button asChild variant="outline">
                      <Link href="/dashboard/student/assessment">
                        <ClipboardCheck className="size-4" />
                        Retake assessment
                      </Link>
                    </Button>
                  )}
                  <Button asChild variant="outline">
                    <Link href="/dashboard/student/ai-chat">
                      <Sparkles className="size-4" />
                      Ask AI mentor
                    </Link>
                  </Button>
                </div>
              </div>

              {/* Readiness ring */}
              <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-secondary/40 p-5 sm:w-56">
                <div className="relative flex size-32 items-center justify-center">
                  <svg viewBox="0 0 120 120" className="size-32 -rotate-90">
                    <circle
                      cx="60"
                      cy="60"
                      r="52"
                      fill="none"
                      stroke="oklch(0.915 0.006 240)"
                      strokeWidth="10"
                    />
                    <circle
                      cx="60"
                      cy="60"
                      r="52"
                      fill="none"
                      stroke={meta.ringStroke}
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray={`${(a.readinessPct / 100) * 2 * Math.PI * 52} ${
                        2 * Math.PI * 52
                      }`}
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="text-2xl font-bold text-foreground">
                      {a.readinessPct}%
                    </span>
                    <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                      readiness
                    </span>
                  </div>
                </div>
                <p className={`mt-3 text-sm font-medium ${meta.color}`}>
                  {meta.label}
                </p>
                <p className="mt-1 text-center text-xs text-muted-foreground">
                  {a.hasAssessment
                    ? `Avg. ${a.avgCurrent} / target ${a.avgTarget}`
                    : "Take the assessment to measure readiness."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Career match */}
        <CareerMatchCard
          recommendations={careerMatch?.recommendations ?? []}
          chosen={careerMatch?.chosen ?? null}
        />
      </div>

      {/* Stat cards */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard
          label="Avg score"
          value={a.hasAssessment ? a.avgCurrent : "—"}
          hint={a.hasAssessment ? `out of ${a.avgTarget}` : "No assessment yet"}
          icon={TrendingUp}
          tone={
            a.hasAssessment
              ? a.avgCurrent >= READY_THRESHOLD
                ? "success"
                : a.avgCurrent < AT_RISK_THRESHOLD
                  ? "warning"
                  : "primary"
              : "default"
          }
        />
        <StatCard
          label="Readiness"
          value={`${a.readinessPct}%`}
          hint={meta.label}
          icon={TargetIcon}
          tone="primary"
        />
        <StatCard
          label="Skills to improve"
          value={a.gapCount}
          hint={`${summary.requiredSkills.length} total`}
          icon={ClipboardCheck}
          tone={a.gapCount > 0 ? "warning" : "success"}
        />
        <StatCard
          label="Problems solved"
          value={`${a.solvedProblems}/${a.totalProblems}`}
          hint={`${a.availableProblems} available`}
          icon={Code2}
          tone="default"
        />
        <StatCard
          label="Weekly progress"
          value={`${weeklyPct}%`}
          hint={
            plan && plan.progress.total > 0
              ? `${plan.progress.done}/${plan.progress.total} this week`
              : "No plan yet"
          }
          icon={TrendingUp}
          tone={
            weeklyPct >= 100
              ? "success"
              : weeklyPct >= 50
                ? "primary"
                : "default"
          }
        />
      </div>

      {/* Two-column: today/plan + radar/gaps */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Left column */}
        <div className="space-y-6">
          <TodayProblemsCard todayItems={todayItems} />
          {plan ? (
            <WeeklyPlanCard
              days={plan.days}
              progress={plan.progress}
              today={plan.today}
            />
          ) : (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Weekly plan</CardTitle>
                <CardDescription>
                  Your weekly practice schedule.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Couldn&apos;t load the weekly plan. Try refreshing.
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right column */}
        <div className="space-y-6">
          <SkillRadar
            skillGaps={summary.skillGaps}
            hasAssessment={a.hasAssessment}
          />

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Top skill gaps</CardTitle>
              <CardDescription>
                {a.hasAssessment
                  ? "Close these gaps to boost your readiness the fastest."
                  : "Take the assessment to see your skill gaps."}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {a.hasAssessment && topGaps.length > 0 ? (
                topGaps.map((g) => {
                  const pct =
                    g.target > 0
                      ? Math.min(100, Math.round((g.current / g.target) * 100))
                      : 0;
                  return (
                    <div key={g.skill}>
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="font-medium text-foreground">
                          {g.skill}
                        </span>
                        <span className="text-muted-foreground">
                          {g.current}
                          <span className="text-muted-foreground/70">
                            {" "}
                            / {g.target}
                          </span>
                        </span>
                      </div>
                      <Progress value={pct} className="mt-1.5 h-2" />
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-muted-foreground">
                  No gaps measured yet. Your first assessment takes about a
                  minute.
                </p>
              )}
              <Button
                asChild
                variant="outline"
                size="sm"
                className="mt-1 w-full"
              >
                <Link href="/dashboard/student/skill-gap">
                  View full skill gap
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Next milestone */}
      <Card className="mt-6">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <MapPin className="size-4 text-primary" />
            Next milestone
          </CardTitle>
          <CardDescription>
            The first step on your roadmap to {summary.career.title}.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {nextMilestone ? (
            <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div className="min-w-0">
                <h3 className="text-base font-semibold text-foreground">
                  {nextMilestone.title}
                </h3>
                <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
                  {nextMilestone.description}
                </p>
                {nextMilestone.skills && nextMilestone.skills.length > 0 ? (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {nextMilestone.skills.slice(0, 6).map((s) => (
                      <Badge
                        key={s}
                        variant="secondary"
                        className="font-normal"
                      >
                        {s}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <Badge variant="outline" className="mt-3">
                    Milestone
                  </Badge>
                )}
              </div>
              <Button asChild variant="outline" size="sm" className="shrink-0">
                <Link href="/dashboard/student/roadmap">
                  View full roadmap
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No roadmap steps for this career yet.
            </p>
          )}
        </CardContent>
      </Card>
    </>
  );
}
