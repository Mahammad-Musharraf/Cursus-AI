"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { ClipboardCheck, Target as TargetIcon, TrendingUp } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { StatCard } from "@/components/stat-card";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

type Summary = {
  stage: string | null;
  stageLabel: string | null;
  career: {
    id: string;
    title: string;
    category: string;
    summary: string;
    avgSalary: string | null;
  } | null;
  requiredSkills: { skill: string; target: number; weight?: number }[];
  roadmap: { title: string; description: string; skills?: string[] }[];
  aggregates: {
    hasAssessment: boolean;
    avgCurrent: number;
    avgTarget: number;
    readinessPct: number;
    gapCount: number;
    solvedProblems: number;
    totalProblems: number;
    availableProblems: number;
    status: "no-assessment" | "at-risk" | "on-track" | "ready";
  };
  skillGaps: {
    skill: string;
    target: number;
    current: number;
    gap: number;
    band: { label: string; tone: "low" | "mid" | "high" };
  }[];
  scores: Record<string, number>;
};

const PRIMARY_BLUE = "#1d4ed8";
const MUTED_GRAY = "#cbd5e1";

function bandClass(tone: "low" | "mid" | "high") {
  switch (tone) {
    case "high":
      return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200/60";
    case "mid":
      return "bg-primary/10 text-primary border-primary/20";
    case "low":
    default:
      return "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border-amber-200/60";
  }
}

export default function SkillGapPage() {
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Summary>("/api/student/summary").then((res) => {
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load skill-gap analysis.");
    });
  }, []);

  if (loading) {
    return (
      <>
        <PageHeader
          title="Skill gap"
          description="See where you stand versus your target for each required skill."
        />
        <LoadingState label="Loading skill-gap analysis…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader title="Skill gap" />
        <ErrorState message={error} />
      </>
    );
  }
  if (!data || !data.career) {
    return (
      <>
        <PageHeader title="Skill gap" />
        <EmptyState
          title="No career selected"
          description="Pick a target career in onboarding to see your skill gaps."
        />
      </>
    );
  }
  if (!data.aggregates.hasAssessment) {
    return (
      <>
        <PageHeader title="Skill gap" />
        <EmptyState
          title="No assessment yet"
          description="Take the assessment to unlock your skill-gap analysis and personalized recommendations."
          icon={ClipboardCheck}
          action={
            <Button asChild>
              <Link href="/dashboard/student/assessment">
                Take assessment
              </Link>
            </Button>
          }
        />
      </>
    );
  }

  const a = data.aggregates;
  const chartData = data.skillGaps
    .map((g) => ({
      skill: g.skill,
      current: g.current,
      target: g.target,
      gap: g.gap,
    }))
    .sort((x, y) => y.gap - x.gap);

  return (
    <>
      <PageHeader
        title="Skill gap"
        description={`How you compare to the target for ${data.career.title}.`}
      >
        <Button asChild variant="outline">
          <Link href="/dashboard/student/assessment">
            <ClipboardCheck className="size-4" />
            Retake assessment
          </Link>
        </Button>
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          label="Your average"
          value={a.avgCurrent}
          hint={`Target avg. ${a.avgTarget}`}
          icon={TrendingUp}
          tone="primary"
        />
        <StatCard
          label="Readiness"
          value={`${a.readinessPct}%`}
          hint={
            a.readinessPct >= 70
              ? "Placement-ready"
              : a.readinessPct >= 40
                ? "On track"
                : "Needs focus"
          }
          icon={TargetIcon}
          tone={
            a.readinessPct >= 70
              ? "success"
              : a.readinessPct >= 40
                ? "primary"
                : "warning"
          }
        />
        <StatCard
          label="Open skill gaps"
          value={a.gapCount}
          hint={`of ${data.requiredSkills.length} required skills`}
          icon={ClipboardCheck}
          tone={a.gapCount > 0 ? "warning" : "success"}
        />
      </div>

      {chartData.length > 0 && (
        <Card className="mt-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Current vs target</CardTitle>
            <CardDescription>
              Bars grouped per skill — close the gap to climb your readiness.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 8, right: 12, left: -16, bottom: 8 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="oklch(0.915 0.006 240)"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="skill"
                    tick={{ fontSize: 11, fill: "oklch(0.5 0.012 250)" }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                    height={56}
                  />
                  <YAxis
                    domain={[0, 100]}
                    tick={{ fontSize: 11, fill: "oklch(0.5 0.012 250)" }}
                  />
                  <Tooltip
                    cursor={{ fill: "oklch(0.965 0.005 240)" }}
                    contentStyle={{
                      borderRadius: 8,
                      border: "1px solid oklch(0.915 0.006 240)",
                      fontSize: 12,
                    }}
                  />
                  <Legend
                    wrapperStyle={{ fontSize: 12 }}
                    iconType="circle"
                  />
                  <Bar
                    dataKey="current"
                    name="Your level"
                    fill={PRIMARY_BLUE}
                    radius={[4, 4, 0, 0]}
                  >
                    {chartData.map((entry, i) => (
                      <Cell
                        key={i}
                        fill={
                          entry.current >= entry.target
                            ? "#10b981"
                            : PRIMARY_BLUE
                        }
                      />
                    ))}
                  </Bar>
                  <Bar
                    dataKey="target"
                    name="Target"
                    fill={MUTED_GRAY}
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="mt-6">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Skill-by-skill breakdown</CardTitle>
          <CardDescription>
            Each skill shows your level, the target, and the gap to close.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {data.skillGaps.map((g) => {
            const pct =
              g.target > 0
                ? Math.min(100, Math.round((g.current / g.target) * 100))
                : 0;
            return (
              <div
                key={g.skill}
                className="rounded-lg border border-border bg-secondary/30 p-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-foreground">
                      {g.skill}
                    </span>
                    <Badge
                      variant="outline"
                      className={`font-medium ${bandClass(g.band.tone)}`}
                    >
                      {g.band.label}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <span className="font-semibold text-foreground">
                      {g.current}
                    </span>
                    <span className="text-muted-foreground/70"> / {g.target}</span>
                    <span className="ml-3 inline-flex items-center gap-1">
                      Gap:
                      <span
                        className={
                          g.gap === 0
                            ? "font-semibold text-emerald-600"
                            : "font-semibold text-amber-600"
                        }
                      >
                        {g.gap === 0 ? "closed" : `−${g.gap}`}
                      </span>
                    </span>
                  </div>
                </div>
                <Progress value={pct} className="mt-3 h-2" />
              </div>
            );
          })}
        </CardContent>
      </Card>
    </>
  );
}
