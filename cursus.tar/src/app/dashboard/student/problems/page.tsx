"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ExternalLink,
  Code2,
  CheckCircle2,
  Filter,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  PLATFORM_LABELS,
  DIFFICULTY_LABELS,
  type Platform,
  type Difficulty,
} from "@/lib/constants";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";

type Problem = {
  id: string;
  title: string;
  platform: Platform;
  difficulty: Difficulty;
  topic: string | null;
  url: string;
  skillSlug: string;
  done: boolean;
};

type ProblemsResponse = {
  problems: Problem[];
  career: { id: string } | null;
};

function difficultyClass(d: Difficulty) {
  switch (d) {
    case "EASY":
      return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200/60";
    case "MEDIUM":
      return "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 border-amber-200/60";
    case "HARD":
      return "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400 border-red-200/60";
    default:
      return "";
  }
}

export default function ProblemsPage() {
  const [data, setData] = useState<Problem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [skill, setSkill] = useState<string>("all");
  const [difficulty, setDifficulty] = useState<string>("all");
  const [platform, setPlatform] = useState<string>("all");
  const [status, setStatus] = useState<string>("all");

  const [togglingId, setTogglingId] = useState<string | null>(null);

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (skill !== "all") p.set("skill", skill);
    if (difficulty !== "all") p.set("difficulty", difficulty);
    if (platform !== "all") p.set("platform", platform);
    if (status !== "all") p.set("status", status);
    return p.toString();
  }, [skill, difficulty, platform, status]);

  useEffect(() => {
    let cancelled = false;
    api<ProblemsResponse>(`/api/problems${qs ? `?${qs}` : ""}`).then((res) => {
      if (cancelled) return;
      setLoading(false);
      if (res.data) setData(res.data.problems);
      else setError(res.error || "Failed to load problems.");
    });
    return () => {
      cancelled = true;
    };
  }, [qs]);

  function changeFilter<T extends string>(setter: (v: T) => void) {
    return (v: T) => {
      setLoading(true);
      setError(null);
      setter(v);
    };
  }

  // distinct skill slugs from currently-loaded list
  const skillOptions = useMemo(() => {
    const set = new Set<string>();
    for (const p of data) set.add(p.skillSlug);
    return Array.from(set).sort();
  }, [data]);

  const solvedCount = data.filter((p) => p.done).length;
  const total = data.length;
  const solvedPct = total > 0 ? Math.round((solvedCount / total) * 100) : 0;

  // First unsolved problem (per current filter list) gets primary Solve CTA
  const firstUnsolvedId = useMemo(() => {
    const found = data.find((p) => !p.done);
    return found?.id ?? null;
  }, [data]);

  const hasFilters =
    skill !== "all" ||
    difficulty !== "all" ||
    platform !== "all" ||
    status !== "all";

  function clearFilters() {
    setLoading(true);
    setError(null);
    setSkill("all");
    setDifficulty("all");
    setPlatform("all");
    setStatus("all");
  }

  async function toggleDone(p: Problem, next: boolean) {
    // optimistic update
    setData((prev) =>
      prev.map((x) => (x.id === p.id ? { ...x, done: next } : x))
    );
    setTogglingId(p.id);
    const res = await api<{ ok: boolean; solved: number; total: number }>(
      "/api/progress",
      {
        method: "POST",
        body: JSON.stringify({ problemId: p.id, done: next }),
      }
    );
    setTogglingId(null);
    if (res.data) {
      toast.success(
        next ? "Marked as solved." : "Marked as not done yet.",
        {
          description: next ? `${res.data.solved}/${res.data.total} solved total` : undefined,
        }
      );
    } else {
      // revert on failure
      setData((prev) =>
        prev.map((x) => (x.id === p.id ? { ...x, done: !next } : x))
      );
      toast.error(res.error || "Could not update progress.");
    }
  }

  return (
    <>
      <PageHeader
        title="Practice problems"
        description="Curated problems matched to the skills your career requires."
      >
        <Button asChild variant="outline">
          <Link href="/dashboard/student/ai-chat">
            Ask AI mentor
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </PageHeader>

      {/* Progress summary */}
      <Card className="mb-4">
        <CardContent className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-muted-foreground">
                Progress this view
              </p>
              <p className="mt-1 text-2xl font-semibold tracking-tight text-foreground">
                {solvedCount}
                <span className="text-muted-foreground"> / {total}</span>
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  ({solvedPct}%)
                </span>
              </p>
            </div>
            <Badge
              variant={solvedPct === 100 && total > 0 ? "default" : "secondary"}
              className={
                solvedPct === 100 && total > 0
                  ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border-emerald-200/60"
                  : ""
              }
            >
              {solvedPct === 100 && total > 0
                ? "All done! 🎉"
                : `${total - solvedCount} left`}
            </Badge>
          </div>
          <Progress value={solvedPct} className="mt-3 h-2" />
        </CardContent>
      </Card>

      {/* Filters */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">Skill</Label>
              <Select value={skill} onValueChange={changeFilter(setSkill)}>
                <SelectTrigger className="w-[180px]" size="sm">
                  <SelectValue placeholder="All skills" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All skills</SelectItem>
                  {skillOptions.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">Difficulty</Label>
              <Select value={difficulty} onValueChange={changeFilter(setDifficulty)}>
                <SelectTrigger className="w-[150px]" size="sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="EASY">Easy</SelectItem>
                  <SelectItem value="MEDIUM">Medium</SelectItem>
                  <SelectItem value="HARD">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">Platform</Label>
              <Select value={platform} onValueChange={changeFilter(setPlatform)}>
                <SelectTrigger className="w-[170px]" size="sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  {(["LEETCODE", "GEEKSFORGEEKS", "CODECHEF"] as Platform[]).map(
                    (p) => (
                      <SelectItem key={p} value={p}>
                        {PLATFORM_LABELS[p]}
                      </SelectItem>
                    )
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label className="text-xs text-muted-foreground">Status</Label>
              <Select value={status} onValueChange={changeFilter(setStatus)}>
                <SelectTrigger className="w-[150px]" size="sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="done">Done</SelectItem>
                  <SelectItem value="undone">Undone</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {hasFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="ml-auto"
              >
                Clear filters
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Body */}
      {loading ? (
        <LoadingState label="Loading problems…" />
      ) : error ? (
        <ErrorState message={error} />
      ) : data.length === 0 ? (
        hasFilters ? (
          <EmptyState
            title="No problems match your filters"
            description="Try widening your filters or clearing them to see more problems."
            icon={Filter}
            action={
              <Button onClick={clearFilters} variant="outline">
                Clear filters
              </Button>
            }
          />
        ) : (
          <EmptyState
            title="No problems available yet"
            description="Your career doesn't have curated problems yet. Check back soon."
            icon={Code2}
          />
        )
      ) : (
        <div className="max-h-[28rem] overflow-y-auto scrollbar-thin pr-1">
          <div className="grid gap-3">
            {data.map((p) => {
              const isPrimary = p.id === firstUnsolvedId;
              return (
                <Card
                  key={p.id}
                  className={
                    p.done
                      ? "border-emerald-200/60 bg-emerald-50/30 dark:bg-emerald-950/10"
                      : ""
                  }
                >
                  <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-semibold text-foreground">
                          {p.title}
                        </h3>
                        <Badge
                          variant="outline"
                          className={`font-medium ${difficultyClass(
                            p.difficulty
                          )}`}
                        >
                          {DIFFICULTY_LABELS[p.difficulty]}
                        </Badge>
                        <Badge variant="secondary" className="font-normal">
                          {PLATFORM_LABELS[p.platform]}
                        </Badge>
                        <Badge variant="outline" className="font-normal">
                          {p.skillSlug}
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {p.topic || "—"}
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-2">
                      <label className="flex cursor-pointer select-none items-center gap-2 rounded-md border border-border bg-background px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent">
                        <Checkbox
                          checked={p.done}
                          disabled={togglingId === p.id}
                          onCheckedChange={(v) =>
                            toggleDone(p, v === true)
                          }
                        />
                        <span className="hidden sm:inline">
                          {p.done ? "Solved" : "Mark done"}
                        </span>
                      </label>
                      <Button asChild variant={isPrimary ? "default" : "outline"} size="sm">
                        <a
                          href={p.url}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="size-4" />
                          Solve
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          {solvedCount === total && total > 0 && (
            <div className="mt-3 flex items-center gap-2 rounded-md border border-emerald-200/60 bg-emerald-50/50 px-3 py-2 text-sm text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400">
              <CheckCircle2 className="size-4" />
              All problems in this view are solved. Onward!
            </div>
          )}
        </div>
      )}
    </>
  );
}
