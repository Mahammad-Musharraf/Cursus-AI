import { redirect } from "next/navigation";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";

export default async function StudentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?callbackUrl=/dashboard/student");
  if (user.role !== "STUDENT") {
    redirect(`/dashboard/${user.role.toLowerCase()}`);
  }
  // Students must complete onboarding before entering their dashboard.
  const rec = await getCurrentUserRecord();
  if (!rec?.stage || !rec?.targetCareerId) {
    redirect("/onboarding");
  }
  return <>{children}</>;
}
