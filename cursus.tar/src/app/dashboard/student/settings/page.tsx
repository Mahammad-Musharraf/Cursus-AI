"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { User, Mail, GraduationCap, Briefcase } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

type Summary = {
  stage: string | null;
  stageLabel: string | null;
  career: {
    id: string;
    title: string;
    category: string;
    summary: string;
    avgSalary: string | null;
  } | null;
};

function Row({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3 py-3">
      <span className="mt-0.5 inline-flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <div className="mt-0.5 break-words text-sm font-medium text-foreground">
          {value || "—"}
        </div>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const { data: session } = useSession();
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Summary>("/api/student/summary").then((res) => {
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load profile.");
    });
  }, []);

  if (loading) {
    return (
      <>
        <PageHeader title="Profile" description="Your account details at a glance." />
        <LoadingState label="Loading profile…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader title="Profile" />
        <ErrorState message={error} />
      </>
    );
  }
  if (!data) return null;

  const name = session?.user?.name || "—";
  const email = session?.user?.email || "—";

  return (
    <>
      <PageHeader
        title="Profile"
        description="Your account details and target career."
      >
        <Tooltip>
          <TooltipTrigger asChild>
            <span>
              <Button disabled>Edit</Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>Profile editing coming soon</TooltipContent>
        </Tooltip>
      </PageHeader>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>
            Read-only view of your information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Row icon={User} label="Name" value={name} />
          <Separator />
          <Row icon={Mail} label="Email" value={email} />
          <Separator />
          <Row
            icon={GraduationCap}
            label="Stage"
            value={
              data.stageLabel ? (
                <span className="flex flex-wrap items-center gap-2">
                  {data.stageLabel}
                  <Badge variant="secondary" className="font-normal">
                    {data.stage}
                  </Badge>
                </span>
              ) : (
                "—"
              )
            }
          />
          <Separator />
          <Row
            icon={Briefcase}
            label="Target career"
            value={
              data.career ? (
                <span className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold">{data.career.title}</span>
                  <Badge variant="outline" className="font-normal">
                    {data.career.category}
                  </Badge>
                  {data.career.avgSalary && (
                    <Badge variant="secondary" className="font-normal">
                      {data.career.avgSalary} avg.
                    </Badge>
                  )}
                </span>
              ) : (
                "—"
              )
            }
          />
        </CardContent>
      </Card>

      <p className="mt-4 text-center text-xs text-muted-foreground">
        Need to change something? Contact your T&P cell or{" "}
        <a
          href="mailto:hello@cursus.ai"
          className="font-medium text-primary hover:underline"
        >
          reach out to support
        </a>
        .
      </p>
    </>
  );
}
