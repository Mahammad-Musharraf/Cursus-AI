"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Map, ArrowRight, Flag } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Summary = {
  career: {
    id: string;
    title: string;
    category: string;
    summary: string;
    avgSalary: string | null;
  } | null;
  roadmap: {
    title: string;
    description: string;
    skills?: string[];
  }[];
};

export default function RoadmapPage() {
  const [data, setData] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Summary>("/api/student/summary").then((res) => {
      setLoading(false);
      if (res.data) setData(res.data);
      else setError(res.error || "Failed to load roadmap.");
    });
  }, []);

  if (loading) {
    return (
      <>
        <PageHeader
          title="Roadmap"
          description="A step-by-step path from where you are to placement-ready."
        />
        <LoadingState label="Loading your roadmap…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader title="Roadmap" />
        <ErrorState message={error} />
      </>
    );
  }
  if (!data || !data.career) {
    return (
      <>
        <PageHeader title="Roadmap" />
        <EmptyState
          title="No career selected"
          description="Pick a target career in onboarding to generate your roadmap."
          icon={Map}
        />
      </>
    );
  }
  if (!data.roadmap || data.roadmap.length === 0) {
    return (
      <>
        <PageHeader title="Roadmap" />
        <EmptyState
          title="No roadmap steps yet"
          description="Your career doesn't have a published roadmap. Try another career or check back soon."
          icon={Map}
          action={
            <Button asChild>
              <Link href="/dashboard/student/problems">
                Go to practice
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          }
        />
      </>
    );
  }

  const steps = data.roadmap;
  const last = steps.length - 1;

  return (
    <>
      <PageHeader
        title="Roadmap"
        description={`A guided path to becoming placement-ready as a ${data.career.title}.`}
      >
        <Button asChild>
          <Link href="/dashboard/student/problems">
            Go to practice
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </PageHeader>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Your journey, step by step</CardTitle>
          <CardDescription>
            {steps.length} {steps.length === 1 ? "step" : "steps"} to reach
            your goal.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="relative">
            {steps.map((step, i) => {
              const hasSkills = step.skills && step.skills.length > 0;
              return (
                <li
                  key={`${i}-${step.title}`}
                  className="relative flex gap-4 pb-8 last:pb-0"
                >
                  {/* Connector line */}
                  {i !== last && (
                    <span
                      aria-hidden
                      className="absolute left-[15px] top-8 bottom-0 w-px bg-border"
                    />
                  )}
                  {/* Numbered circle */}
                  <div className="relative z-10 flex size-8 shrink-0 items-center justify-center rounded-full border-2 border-primary bg-primary text-xs font-bold text-primary-foreground">
                    {i + 1}
                  </div>

                  <div className="min-w-0 flex-1 pt-0.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-semibold text-foreground">
                        {step.title}
                      </h3>
                      {!hasSkills && (
                        <Badge variant="outline" className="font-normal">
                          <Flag className="size-3" />
                          Milestone
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {step.description}
                    </p>
                    {hasSkills && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {step.skills!.map((s) => (
                          <Badge
                            key={s}
                            variant="secondary"
                            className="bg-primary/5 font-normal text-primary"
                          >
                            {s}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        </CardContent>
      </Card>
    </>
  );
}
