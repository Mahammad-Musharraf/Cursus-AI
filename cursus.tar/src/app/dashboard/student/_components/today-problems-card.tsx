"use client";

import Link from "next/link";
import {
  ArrowRight,
  CalendarCheck,
  CheckCircle2,
  Circle,
  Coffee,
  ExternalLink,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DIFFICULTY_LABELS,
  PLATFORM_LABELS,
  type Difficulty,
} from "@/lib/constants";
import type { PlanItem } from "./types";

function difficultyDotClass(d: Difficulty) {
  switch (d) {
    case "EASY":
      return "bg-emerald-500";
    case "MEDIUM":
      return "bg-amber-500";
    case "HARD":
      return "bg-red-500";
    default:
      return "bg-muted-foreground";
  }
}

export function TodayProblemsCard({ todayItems }: { todayItems: PlanItem[] }) {
  const total = todayItems.length;
  const done = todayItems.filter((i) => i.done).length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  const allDone = total > 0 && done === total;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <CalendarCheck className="size-4 text-primary" />
          Today&apos;s problems
        </CardTitle>
        <CardDescription>
          {total > 0
            ? `${done} of ${total} done today`
            : "Your daily practice plan."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {total > 0 ? (
          <>
            <div className="flex items-center gap-3">
              <Progress value={pct} className="h-2 flex-1" />
              <span className="text-xs font-medium text-muted-foreground">
                {pct}%
              </span>
            </div>
            <ul className="space-y-3">
              {todayItems.map((item) => (
                <li
                  key={item.assignmentId}
                  className={`rounded-lg border p-3 ${
                    item.done
                      ? "border-emerald-200/60 bg-emerald-50/40 dark:bg-emerald-950/10"
                      : "border-border bg-card"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start gap-2">
                        {item.done ? (
                          <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                        ) : (
                          <Circle className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                        )}
                        <div className="min-w-0">
                          <h4 className="text-sm font-semibold text-foreground">
                            {item.problem.title}
                          </h4>
                          <div className="mt-1 flex flex-wrap items-center gap-1.5">
                            <span
                              className={`inline-block size-2 rounded-full ${difficultyDotClass(
                                item.problem.difficulty
                              )}`}
                            />
                            <Badge
                              variant="outline"
                              className="px-1.5 py-0 font-normal text-[10px]"
                            >
                              {DIFFICULTY_LABELS[item.problem.difficulty]}
                            </Badge>
                            <Badge
                              variant="secondary"
                              className="px-1.5 py-0 font-normal text-[10px]"
                            >
                              {PLATFORM_LABELS[item.problem.platform]}
                            </Badge>
                            {item.problem.topic && (
                              <Badge
                                variant="outline"
                                className="px-1.5 py-0 font-normal text-[10px]"
                              >
                                {item.problem.topic}
                              </Badge>
                            )}
                          </div>
                          {item.reason && (
                            <p className="mt-1.5 text-xs text-muted-foreground">
                              {item.reason}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button asChild variant="outline" size="sm">
                      <a
                        href={item.problem.url}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="size-3.5" />
                        Solve
                      </a>
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
            {allDone && (
              <div className="flex items-center gap-2 rounded-md border border-emerald-200/60 bg-emerald-50/50 px-3 py-2 text-sm text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400">
                <CheckCircle2 className="size-4" />
                Day complete! You crushed it.
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-secondary/20 px-4 py-8 text-center">
            <Coffee className="size-6 text-muted-foreground" />
            <p className="mt-2 text-sm font-medium text-foreground">
              No problems assigned today
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Enjoy the rest day, or jump ahead.
            </p>
          </div>
        )}

        <Button asChild variant="outline" size="sm" className="w-full">
          <Link href="/dashboard/student/problems">
            Open weekly plan
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
