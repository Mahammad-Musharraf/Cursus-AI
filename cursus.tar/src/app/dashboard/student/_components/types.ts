import type { Difficulty, Platform } from "@/lib/constants";

export type PlanItem = {
  assignmentId: string;
  reason: string;
  problem: {
    id: string;
    title: string;
    platform: Platform;
    difficulty: Difficulty;
    topic: string;
    url: string;
    skillSlug: string;
  };
  done: boolean;
};

export type DayGroup = { day: string; items: PlanItem[] };

export type PlanProgress = { done: number; total: number; pct: number };

export type PlanData = {
  weekKey: string;
  today: string;
  days: DayGroup[];
  todayItems: PlanItem[];
  progress: PlanProgress;
  generated: boolean;
};
