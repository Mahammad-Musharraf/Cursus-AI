"use client";

import Link from "next/link";
import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";
import { ClipboardCheck } from "lucide-react";
import { EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

type SkillGap = {
  skill: string;
  target: number;
  current: number;
  gap: number;
  band: { label: string; tone: "low" | "mid" | "high" };
};

const PRIMARY_BLUE = "#1d4ed8";
const MUTED_GRAY = "#cbd5e1";

export function SkillRadar({
  skillGaps,
  hasAssessment,
}: {
  skillGaps: SkillGap[];
  hasAssessment: boolean;
}) {
  if (!hasAssessment) {
    return (
      <Card className="h-full">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Skill radar</CardTitle>
          <CardDescription>
            Take the assessment to map your skill profile.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <EmptyState
            title="No assessment yet"
            description="Take the assessment to see a radar chart of your current level vs target for each required skill."
            icon={ClipboardCheck}
            action={
              <Button asChild size="sm" variant="outline">
                <Link href="/dashboard/student/assessment">
                  Take assessment
                </Link>
              </Button>
            }
          />
        </CardContent>
      </Card>
    );
  }

  const chartData = skillGaps.map((g) => ({
    skill: g.skill,
    current: g.current,
    target: g.target,
  }));

  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Skill radar</CardTitle>
        <CardDescription>
          Current level vs the target for each required skill.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No skills to chart yet for this career.
          </p>
        ) : (
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={chartData} outerRadius="68%">
                <PolarGrid stroke="oklch(0.915 0.006 240)" />
                <PolarAngleAxis
                  dataKey="skill"
                  tick={{ fontSize: 11, fill: "oklch(0.5 0.012 250)" }}
                />
                <PolarRadiusAxis
                  domain={[0, 100]}
                  tick={{ fontSize: 10, fill: "oklch(0.5 0.012 250)" }}
                  angle={90}
                />
                <Radar
                  name="Target"
                  dataKey="target"
                  stroke={MUTED_GRAY}
                  fill={MUTED_GRAY}
                  fillOpacity={0.15}
                  strokeWidth={1.5}
                />
                <Radar
                  name="Current"
                  dataKey="current"
                  stroke={PRIMARY_BLUE}
                  fill={PRIMARY_BLUE}
                  fillOpacity={0.35}
                  strokeWidth={2}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: "1px solid oklch(0.915 0.006 240)",
                    fontSize: 12,
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
