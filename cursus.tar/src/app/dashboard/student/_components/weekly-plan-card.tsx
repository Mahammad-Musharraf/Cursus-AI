"use client";

import { CalendarDays, CheckCircle2, Circle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Difficulty } from "@/lib/constants";
import type { DayGroup, PlanProgress } from "./types";

const DAYS: { day: string; label: string }[] = [
  { day: "MON", label: "Mon" },
  { day: "TUE", label: "Tue" },
  { day: "WED", label: "Wed" },
  { day: "THU", label: "Thu" },
  { day: "FRI", label: "Fri" },
  { day: "SAT", label: "Sat" },
  { day: "SUN", label: "Sun" },
];

function difficultyDotClass(d: Difficulty) {
  switch (d) {
    case "EASY":
      return "bg-emerald-500";
    case "MEDIUM":
      return "bg-amber-500";
    case "HARD":
      return "bg-red-500";
    default:
      return "bg-muted-foreground";
  }
}

export function WeeklyPlanCard({
  days,
  progress,
  today,
}: {
  days: DayGroup[];
  progress: PlanProgress;
  today: string;
}) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <CalendarDays className="size-4 text-primary" />
          Weekly plan
        </CardTitle>
        <CardDescription>
          {progress.total > 0
            ? `${progress.done} of ${progress.total} done this week`
            : "Your weekly practice schedule."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {progress.total > 0 ? (
          <>
            <div className="flex items-center gap-3">
              <Progress value={progress.pct} className="h-2 flex-1" />
              <span className="text-xs font-medium text-muted-foreground">
                {progress.pct}%
              </span>
            </div>
            <div className="max-h-96 overflow-y-auto scrollbar-thin pr-1">
              <div className="grid gap-2">
                {DAYS.map(({ day, label }) => {
                  const dayItems =
                    days.find((d) => d.day === day)?.items ?? [];
                  const isToday = today === day;
                  const dayDone = dayItems.filter((i) => i.done).length;
                  const dayTotal = dayItems.length;
                  return (
                    <div
                      key={day}
                      className={`rounded-lg border p-3 ${
                        isToday
                          ? "border-primary/40 bg-primary/5"
                          : "border-border bg-card"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                            {label}
                          </span>
                          {isToday && (
                            <Badge
                              variant="secondary"
                              className="bg-primary/10 px-1.5 py-0 text-[10px] font-medium text-primary"
                            >
                              Today
                            </Badge>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {dayTotal > 0 ? `${dayDone}/${dayTotal}` : "Rest"}
                        </span>
                      </div>
                      {dayTotal > 0 ? (
                        <ul className="mt-2 space-y-1.5">
                          {dayItems.map((item) => (
                            <li
                              key={item.assignmentId}
                              className="flex items-center gap-2 text-xs"
                            >
                              <span
                                className={`inline-block size-1.5 shrink-0 rounded-full ${difficultyDotClass(
                                  item.problem.difficulty
                                )}`}
                              />
                              <span
                                className={`truncate ${
                                  item.done
                                    ? "text-muted-foreground line-through"
                                    : "text-foreground"
                                }`}
                              >
                                {item.problem.title}
                              </span>
                              {item.done ? (
                                <CheckCircle2 className="ml-auto size-3.5 shrink-0 text-emerald-600" />
                              ) : (
                                <Circle className="ml-auto size-3.5 shrink-0 text-muted-foreground" />
                              )}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-1.5 text-xs italic text-muted-foreground">
                          No problems — recovery day.
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">
            No weekly plan yet. Add a target career to generate one.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
