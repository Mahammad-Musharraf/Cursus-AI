"use client";

import Link from "next/link";
import { RefreshCw, Sparkles, Trophy } from "lucide-react";
import { EmptyState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

type Recommendation = {
  careerId: string;
  slug: string;
  title: string;
  category: string;
  matchPct: number;
  reasons: string[];
};

type Chosen = {
  id: string;
  title: string;
  slug: string;
  category: string;
} | null;

export function CareerMatchCard({
  recommendations,
  chosen,
}: {
  recommendations: Recommendation[];
  chosen: Chosen;
}) {
  const top = recommendations[0];

  // No recommendations and no chosen career
  if (recommendations.length === 0 && !chosen) {
    return (
      <Card className="h-full">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="size-4 text-primary" />
            Career match
          </CardTitle>
          <CardDescription>
            Discover the career that fits you best.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <EmptyState
            title="Take the career quiz"
            description="Answer a few quick questions to get AI-matched career recommendations."
            icon={Sparkles}
            action={
              <Button asChild size="sm" variant="outline">
                <Link href="/onboarding">Take career quiz</Link>
              </Button>
            }
          />
        </CardContent>
      </Card>
    );
  }

  const mismatch = top && (!chosen || chosen.slug !== top.slug);

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="size-4 text-primary" />
          Career match
        </CardTitle>
        <CardDescription>
          {top
            ? "Your top AI-matched career, based on the quiz."
            : "No AI recommendation available yet."}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {top ? (
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  Best AI match
                </p>
                <h3 className="mt-0.5 text-base font-semibold text-foreground">
                  {top.title}
                </h3>
                <p className="text-xs text-muted-foreground">{top.category}</p>
              </div>
              <span className="inline-flex shrink-0 items-center gap-1 rounded-md bg-primary px-2 py-1 text-xs font-bold text-primary-foreground">
                {top.matchPct}%
              </span>
            </div>
            {top.reasons.length > 0 && (
              <ul className="mt-3 space-y-1">
                {top.reasons.slice(0, 2).map((r, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-1.5 text-xs text-muted-foreground"
                  >
                    <span className="mt-1 size-1 shrink-0 rounded-full bg-primary" />
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ) : null}

        {chosen ? (
          <div className="rounded-lg border border-border bg-secondary/30 p-4">
            <div className="flex items-center gap-2">
              <Trophy className="size-4 text-primary" />
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                You chose
              </p>
            </div>
            <h3 className="mt-1 text-sm font-semibold text-foreground">
              {chosen.title}
            </h3>
            <p className="text-xs text-muted-foreground">{chosen.category}</p>
            {mismatch ? (
              <p className="mt-2 text-xs text-muted-foreground">
                You picked{" "}
                <span className="font-medium text-foreground">
                  {chosen.title}
                </span>
                ; your best match was{" "}
                <span className="font-medium text-foreground">{top?.title}</span>{" "}
                ({top?.matchPct}%).
              </p>
            ) : (
              <p className="mt-2 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                Matches your top recommendation — great pick.
              </p>
            )}
          </div>
        ) : null}

        <Button asChild variant="outline" size="sm" className="w-full">
          <Link href="/onboarding?retake=1">
            <RefreshCw className="size-4" />
            Retake career quiz
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
