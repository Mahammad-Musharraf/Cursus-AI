"use client";

import * as React from "react";
import Link from "next/link";
import {
  ClipboardCheck,
  Clock,
  ListChecks,
  Play,
  Building2,
  CheckCircle2,
  XCircle,
  Hourglass,
  Trophy,
  Timer,
} from "lucide-react";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { api } from "@/lib/api";

// ---------------- Types ----------------

type AvailableExam = {
  id: string;
  title: string;
  description: string;
  durationMin: number;
  questionsToPick: number;
  passScorePct: number;
  companyName: string;
  jobTitle: string | null;
  questionCount: number;
  hasAttempted: boolean;
  submitted: boolean;
  scorePct: number | null;
  passed: boolean | null;
};

type AvailableResponse = { exams: AvailableExam[] };

// ---------------- Page ----------------

export default function StudentExamsPage() {
  const [exams, setExams] = React.useState<AvailableExam[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    let active = true;
    api<AvailableResponse>("/api/exams/available").then((res) => {
      if (!active) return;
      setLoading(false);
      if (res.data) {
        setExams(res.data.exams);
        setError(null);
      } else {
        setError(res.error || "Failed to load exams.");
      }
    });
    return () => {
      active = false;
    };
  }, []);

  function load() {
    setLoading(true);
    setError(null);
    api<AvailableResponse>("/api/exams/available").then((res) => {
      setLoading(false);
      if (res.data) setExams(res.data.exams);
      else setError(res.error || "Failed to load exams.");
    });
  }

  const available = exams.filter((e) => !e.hasAttempted || !e.submitted);
  const results = exams.filter((e) => e.submitted);

  return (
    <div className="mx-auto w-full max-w-5xl space-y-8">
      <PageHeader
        title="Exams"
        description="Take screening exams from recruiters and track your results."
      />

      {/* Available exams */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">
          {available.length > 0
            ? `Available to you (${available.length})`
            : "Available to you"}
        </h2>

        {loading ? (
          <LoadingState label="Loading exams…" />
        ) : error ? (
          <ErrorState
            message={error}
            action={
              <Button variant="outline" size="sm" onClick={load}>
                Try again
              </Button>
            }
          />
        ) : available.length === 0 ? (
          <EmptyState
            icon={ClipboardCheck}
            title="No exams available right now"
            description="When a recruiter assigns you a screening exam, it will appear here. Check back later."
          />
        ) : (
          <div className="grid gap-3">
            {available.map((exam) => (
              <AvailableExamCard key={exam.id} exam={exam} />
            ))}
          </div>
        )}
      </section>

      {/* My results */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">
          My results
        </h2>

        {!loading && !error && results.length === 0 ? (
          <EmptyState
            icon={Trophy}
            title="No results yet"
            description="Once you submit an exam, your score and pass/fail status will appear here."
          />
        ) : !loading && !error ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {results.map((exam) => (
              <ResultCard key={exam.id} exam={exam} />
            ))}
          </div>
        ) : null}
      </section>
    </div>
  );
}

// ---------------- Sub-components ----------------

function AvailableExamCard({ exam }: { exam: AvailableExam }) {
  // In-progress (started, not submitted) — exam.hasAttempted && !submitted
  const inProgress = exam.hasAttempted && !exam.submitted;

  return (
    <Card>
      <CardContent className="p-4 sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-semibold text-foreground">
                {exam.title}
              </h3>
              {inProgress && (
                <Badge className="border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400">
                  <Hourglass className="size-3" />
                  In progress
                </Badge>
              )}
              {exam.jobTitle && <Badge variant="outline">{exam.jobTitle}</Badge>}
            </div>
            <p className="mt-1 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
              <Building2 className="size-3.5" />
              {exam.companyName}
            </p>
            {exam.description && (
              <p className="mt-2 line-clamp-2 max-w-2xl text-sm text-muted-foreground">
                {exam.description}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Clock className="size-3.5" />
                {exam.durationMin} min
              </span>
              <span className="inline-flex items-center gap-1.5">
                <ListChecks className="size-3.5" />
                {exam.questionsToPick} questions
              </span>
              <span className="inline-flex items-center gap-1.5">
                Pass {exam.passScorePct}%
              </span>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            {inProgress ? (
              <Button asChild>
                <Link href={`/dashboard/student/exams/${exam.id}`}>
                  Resume
                  <Play className="size-4" />
                </Link>
              </Button>
            ) : (
              <Button asChild>
                <Link href={`/dashboard/student/exams/${exam.id}`}>
                  Start exam
                  <Play className="size-4" />
                </Link>
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ResultCard({ exam }: { exam: AvailableExam }) {
  const passed = exam.passed === true;
  const failed = exam.passed === false;
  const score = exam.scorePct ?? 0;
  const passMark = exam.passScorePct;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <CardTitle className="truncate text-base">{exam.title}</CardTitle>
            <CardDescription className="inline-flex items-center gap-1.5">
              <Building2 className="size-3.5" />
              {exam.companyName}
            </CardDescription>
          </div>
          {passed ? (
            <Badge className="border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
              <CheckCircle2 className="size-3" />
              Passed
            </Badge>
          ) : failed ? (
            <Badge className="border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400">
              <XCircle className="size-3" />
              Failed
            </Badge>
          ) : (
            <Badge variant="secondary">Submitted</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline justify-between">
          <p className="text-xs font-medium text-muted-foreground">Your score</p>
          <p className="text-sm text-muted-foreground">Pass {passMark}%</p>
        </div>
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-3xl font-semibold tracking-tight text-foreground">
            {score}%
          </span>
        </div>
        <Progress
          value={score}
          className="mt-2 h-1.5"
          aria-label="Your score"
        />
        <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Timer className="size-3.5" />
          {exam.durationMin} min exam
        </div>
      </CardContent>
    </Card>
  );
}
