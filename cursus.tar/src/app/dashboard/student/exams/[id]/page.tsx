"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  Clock,
  AlertTriangle,
  Send,
  Loader2,
  CheckCircle2,
  XCircle,
  Timer as TimerIcon,
  ListChecks,
  EyeOff,
  Trophy,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { api } from "@/lib/api";

// ---------------- Types ----------------

type QuestionType = "MCQ" | "SHORT_ANSWER" | "CODING";
type Difficulty = "EASY" | "MEDIUM" | "HARD";

type StartQuestion = {
  id: string;
  type: QuestionType;
  prompt: string;
  options: string[] | null;
  skillSlug: string | null;
  difficulty: Difficulty;
  points: number;
};

type StartResponse = {
  attemptId: string;
  exam: {
    id: string;
    title: string;
    durationMin: number;
    passScorePct: number;
  };
  questions: StartQuestion[];
  totalQuestions: number;
};

type SubmitResponse = {
  ok: boolean;
  scorePct: number;
  passed: boolean;
  totalQuestions: number;
  correctCount: number;
  timeSpentSec: number;
  submittedAt: string;
};

const DIFFICULTY_BADGE: Record<Difficulty, string> = {
  EASY:
    "border-transparent bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
  MEDIUM:
    "border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400",
  HARD: "border-transparent bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400",
};

// ---------------- Page ----------------

type Phase =
  | { kind: "starting" }
  | { kind: "alreadyAttempted" }
  | { kind: "taking"; data: StartResponse }
  | { kind: "submitting"; data: StartResponse }
  | { kind: "done"; data: StartResponse; result: SubmitResponse }
  | { kind: "error"; message: string };

export default function StudentTakeExamPage() {
  const params = useParams<{ id: string }>();
  const examId = params.id;

  const [phase, setPhase] = React.useState<Phase>({ kind: "starting" });
  const [answers, setAnswers] = React.useState<Record<string, string>>({});
  const [secondsLeft, setSecondsLeft] = React.useState<number | null>(null);
  const [tabSwitches, setTabSwitches] = React.useState(0);
  const [submitDialogOpen, setSubmitDialogOpen] = React.useState(false);
  const [startedAt, setStartedAt] = React.useState<number | null>(null);

  // ---------------- Start the exam on mount ----------------
  React.useEffect(() => {
    if (!examId) return;
    let active = true;

    api<StartResponse>(`/api/exams/${examId}/start`, { method: "POST" }).then(
      (res) => {
        if (!active) return;
        if (res.status === 409) {
          setPhase({ kind: "alreadyAttempted" });
          return;
        }
        if (res.data?.attemptId) {
          setPhase({ kind: "taking", data: res.data });
          setSecondsLeft(res.data.exam.durationMin * 60);
          setStartedAt(Date.now());
          return;
        }
        setPhase({
          kind: "error",
          message:
            res.error ||
            (res.status === 404
              ? "This exam is no longer available."
              : "Could not start the exam."),
        });
      }
    );

    return () => {
      active = false;
    };
  }, [examId]);

  // ---------------- Timer ----------------
  // Use a ref so the auto-submit effect doesn't depend on the changing
  // secondsLeft value.
  const autoSubmitRef = React.useRef<(() => void) | null>(null);

  React.useEffect(() => {
    if (phase.kind !== "taking") return;
    if (secondsLeft === null) return;

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev === null) return null;
        if (prev <= 0) return 0; // hold at 0 — don't re-fire auto-submit
        if (prev <= 1) {
          // Time's up — trigger auto-submit.
          clearInterval(interval);
          if (autoSubmitRef.current) {
            autoSubmitRef.current();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [phase.kind]);

  // ---------------- Tab-switch warning ----------------
  React.useEffect(() => {
    if (phase.kind !== "taking") return;

    function onVisibility() {
      if (document.hidden) {
        setTabSwitches((n) => n + 1);
        toast.warning("Please don't switch tabs — this is recorded.", {
          description: "Tab switches are counted and sent with your submission.",
        });
      }
    }

    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [phase.kind]);

  // ---------------- Leave guard (beforeunload + popstate + link clicks) ----
  const inExam = phase.kind === "taking";

  React.useEffect(() => {
    if (!inExam) return;

    function onBeforeUnload(e: BeforeUnloadEvent) {
      e.preventDefault();
      e.returnValue =
        "Your exam progress will be lost. Are you sure you want to leave?";
      return e.returnValue;
    }

    function onClick(e: MouseEvent) {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const anchor = target.closest("a");
      if (!anchor) return;
      const href = anchor.getAttribute("href");
      if (!href || href.startsWith("#")) return;
      if (anchor.target === "_blank") return;
      // Same-page hash links
      try {
        const url = new URL(href, window.location.href);
        if (url.pathname === window.location.pathname) return;
      } catch {
        // ignore
      }
      const ok = window.confirm(
        "Your exam progress will be lost. Are you sure you want to leave?"
      );
      if (!ok) {
        e.preventDefault();
        e.stopPropagation();
      }
    }

    window.addEventListener("beforeunload", onBeforeUnload);
    document.addEventListener("click", onClick, true);
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      document.removeEventListener("click", onClick, true);
    };
  }, [inExam]);

  // ---------------- Submit handler ----------------
  const submitRef = React.useRef(false);

  const doSubmit = React.useCallback(async () => {
    if (submitRef.current) return;
    if (phase.kind !== "taking") return;
    submitRef.current = true;

    const data = phase.data;
    const responses = data.questions.map((q) => ({
      questionId: q.id,
      answer: (answers[q.id] ?? "").toString(),
    }));
    const timeSpentSec = startedAt
      ? Math.max(0, Math.round((Date.now() - startedAt) / 1000))
      : 0;

    setPhase({ kind: "submitting", data });

    const res = await api<SubmitResponse>(`/api/exams/${examId}/submit`, {
      method: "POST",
      body: JSON.stringify({
        attemptId: data.attemptId,
        responses,
        timeSpentSec,
        tabSwitches,
      }),
    });

    if (res.data?.ok) {
      setPhase({ kind: "done", data, result: res.data });
      toast.success("Exam submitted!");
    } else {
      setPhase({ kind: "taking", data });
      submitRef.current = false;
      toast.error(res.error || "Could not submit the exam. Please try again.");
    }
  }, [phase, answers, startedAt, tabSwitches, examId]);

  // Keep the auto-submit ref in sync.
  React.useEffect(() => {
    if (phase.kind === "taking") {
      autoSubmitRef.current = doSubmit;
    } else {
      autoSubmitRef.current = null;
    }
  }, [phase.kind, doSubmit]);

  // ---------------- Answer handlers ----------------
  function setAnswer(questionId: string, value: string) {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  }

  // ---------------- Render ----------------

  if (phase.kind === "starting") {
    return (
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <PageHeader title="Starting exam…" />
        <LoadingState label="Loading your exam…" />
      </div>
    );
  }

  if (phase.kind === "error") {
    return (
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <PageHeader title="Exam unavailable" />
        <ErrorState
          message={phase.message}
          action={
            <Button asChild variant="outline" size="sm">
              <Link href="/dashboard/student/exams">
                <ArrowLeft className="size-4" />
                Back to exams
              </Link>
            </Button>
          }
        />
      </div>
    );
  }

  if (phase.kind === "alreadyAttempted") {
    return (
      <div className="mx-auto w-full max-w-3xl space-y-6">
        <PageHeader
          title="Already attempted"
          description="You can only take each exam once."
        />
        <Card>
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <span className="inline-flex size-12 items-center justify-center rounded-full bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400">
              <AlertTriangle className="size-6" />
            </span>
            <h2 className="text-lg font-semibold text-foreground">
              You&apos;ve already taken this exam
            </h2>
            <p className="max-w-md text-sm text-muted-foreground">
              Each exam allows a single attempt. Check your results to see how
              you did.
            </p>
            <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
              <Button asChild>
                <Link href="/dashboard/student/exams">
                  <ArrowLeft className="size-4" />
                  Back to exams
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Taking / Submitting
  if (phase.kind === "taking" || phase.kind === "submitting") {
    const data = phase.data;
    const submitting = phase.kind === "submitting";
    const total = data.questions.length;
    const answered = data.questions.filter(
      (q) => (answers[q.id] ?? "").toString().trim().length > 0
    ).length;
    const progressPct = total > 0 ? Math.round((answered / total) * 100) : 0;
    const timeLow = secondsLeft !== null && secondsLeft <= 60;
    const timeUp = secondsLeft === 0;

    return (
      <div className="mx-auto w-full max-w-3xl space-y-5">
        {/* Sticky timer / progress header */}
        <div className="sticky top-0 z-10 -mx-4 border-b border-border bg-background/95 px-4 py-3 backdrop-blur supports-[backdrop-filter]:bg-background/80 sm:mx-0 sm:rounded-md sm:border">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <h1 className="truncate text-lg font-semibold text-foreground">
                {data.exam.title}
              </h1>
              <p className="text-xs text-muted-foreground">
                Pass mark {data.exam.passScorePct}% · {total} questions
              </p>
            </div>
            <div className="flex items-center gap-3">
              {tabSwitches > 0 && (
                <Badge
                  variant="outline"
                  className="border-transparent bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400"
                  title="Tab switches recorded"
                >
                  <EyeOff className="size-3" />
                  {tabSwitches} tab switch{tabSwitches === 1 ? "" : "es"}
                </Badge>
              )}
              <div
                className={
                  "inline-flex items-center gap-2 rounded-md border px-3 py-1.5 font-mono text-lg font-semibold tabular-nums " +
                  (timeUp
                    ? "border-red-300 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-950/40 dark:text-red-400"
                    : timeLow
                      ? "border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-400"
                      : "border-border bg-muted/40 text-foreground")
                }
                aria-label="Time remaining"
              >
                <Clock className="size-4" />
                {formatTime(secondsLeft ?? 0)}
              </div>
            </div>
          </div>

          <div className="mt-3">
            <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
              <span>
                Question{" "}
                <span className="font-medium text-foreground">{answered}</span>{" "}
                of {total} answered
              </span>
              <span>{progressPct}%</span>
            </div>
            <Progress value={progressPct} className="h-1.5" />
          </div>
        </div>

        {/* Time-up banner */}
        {timeUp && (
          <div className="flex items-center gap-2 rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700 dark:border-red-800 dark:bg-red-950/40 dark:text-red-400">
            <TimerIcon className="size-4" />
            Time&apos;s up — submitting your exam…
          </div>
        )}

        {/* Questions */}
        <div className="space-y-4">
          {data.questions.map((q, i) => (
            <QuestionBlock
              key={q.id}
              index={i}
              question={q}
              value={answers[q.id] ?? ""}
              onChange={(v) => setAnswer(q.id, v)}
              disabled={submitting}
            />
          ))}
        </div>

        {/* Submit */}
        <Card>
          <CardContent className="p-4 sm:p-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="text-sm text-muted-foreground">
                <p>
                  You&apos;ve answered{" "}
                  <span className="font-medium text-foreground">{answered}</span>{" "}
                  of {total} questions.
                </p>
                <p className="mt-0.5 text-xs">
                  You can&apos;t retake this exam after submitting.
                </p>
              </div>
              <Button
                onClick={() => setSubmitDialogOpen(true)}
                disabled={submitting || timeUp}
                className="sm:ml-auto"
              >
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Submitting…
                  </>
                ) : (
                  <>
                    <Send className="size-4" />
                    Submit exam
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Submit confirmation */}
        <AlertDialog
          open={submitDialogOpen}
          onOpenChange={(open) => {
            if (!submitting) setSubmitDialogOpen(open);
          }}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Submit your exam?</AlertDialogTitle>
              <AlertDialogDescription>
                {answered < total
                  ? `You've only answered ${answered} of ${total} questions. Unanswered questions will be marked incorrect. This cannot be undone.`
                  : "You've answered all questions. This will finalize your submission and you can't retake the exam. This cannot be undone."}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={submitting}>
                Keep working
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  setSubmitDialogOpen(false);
                  void doSubmit();
                }}
                disabled={submitting}
              >
                {submitting ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Submitting…
                  </>
                ) : (
                  "Submit exam"
                )}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    );
  }

  // Done
  if (phase.kind === "done") {
    const { result, data } = phase;
    const passed = result.passed;
    const passMark = data.exam.passScorePct;

    return (
      <div className="mx-auto w-full max-w-2xl space-y-6">
        <PageHeader
          title="Exam submitted"
          description={data.exam.title}
        />

        <Card>
          <CardContent className="flex flex-col items-center gap-4 p-6 text-center sm:p-8">
            <span
              className={
                "inline-flex size-16 items-center justify-center rounded-full " +
                (passed
                  ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400"
                  : "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400")
              }
            >
              {passed ? (
                <CheckCircle2 className="size-8" />
              ) : (
                <XCircle className="size-8" />
              )}
            </span>

            <div>
              <h2 className="text-xl font-semibold text-foreground">
                {passed ? "You passed! 🎉" : "Below the pass threshold"}
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {passed
                  ? "Congratulations — you met the bar for this exam."
                  : "You can review your answers below and try other exams."}
              </p>
            </div>

            <div className="mt-2 grid w-full grid-cols-3 gap-3">
              <ResultStat
                label="Your score"
                value={`${result.scorePct}%`}
                highlight
              />
              <ResultStat label="Correct" value={`${result.correctCount}/${result.totalQuestions}`} />
              <ResultStat label="Pass mark" value={`${passMark}%`} />
            </div>

            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <TimerIcon className="size-3.5" />
              Time spent: {formatTime(result.timeSpentSec)}
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-wrap items-center justify-center gap-2">
          <Button asChild>
            <Link href="/dashboard/student/exams">
              <Trophy className="size-4" />
              Back to exams
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  // Fallback (should never reach)
  return null;
}

// ---------------- Sub-components ----------------

function formatTime(total: number): string {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function ResultStat({
  label,
  value,
  highlight,
}: {
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="rounded-md border border-border bg-muted/30 px-3 py-2">
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </p>
      <p
        className={
          "mt-0.5 text-lg font-semibold tracking-tight " +
          (highlight ? "text-primary" : "text-foreground")
        }
      >
        {value}
      </p>
    </div>
  );
}

function QuestionBlock({
  index,
  question,
  value,
  onChange,
  disabled,
}: {
  index: number;
  question: StartQuestion;
  value: string;
  onChange: (v: string) => void;
  disabled: boolean;
}) {
  const options = question.options ?? [];
  const isAnswered = value.trim().length > 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex size-6 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
              {index + 1}
            </span>
            <CardTitle className="text-sm font-semibold">
              Question {index + 1}
              <span className="ml-1 text-xs font-normal text-muted-foreground">
                · {question.points} {question.points === 1 ? "point" : "points"}
              </span>
            </CardTitle>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant="outline">{question.type}</Badge>
            <Badge
              variant="outline"
              className={DIFFICULTY_BADGE[question.difficulty]}
            >
              {question.difficulty}
            </Badge>
            {question.skillSlug && (
              <Badge variant="secondary">{question.skillSlug}</Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-foreground">{question.prompt}</p>

        <Separator className="my-3" />

        {/* Render based on type */}
        {question.type === "MCQ" ? (
          options.length === 0 ? (
            <p className="text-xs text-muted-foreground">
              No options provided.
            </p>
          ) : (
            <RadioGroup
              value={value}
              onValueChange={onChange}
              className="gap-2"
            >
              {options.map((opt, i) => {
                const checked = value === String(i);
                return (
                  <div
                    key={i}
                    className={
                      "flex items-start gap-3 rounded-md border bg-card px-3 py-2 text-sm transition-colors hover:bg-muted/40 " +
                      (checked ? "border-primary" : "border-border")
                    }
                  >
                    <RadioGroupItem
                      value={String(i)}
                      id={`q-${question.id}-opt-${i}`}
                      disabled={disabled}
                      className="mt-0.5"
                    />
                    <Label
                      htmlFor={`q-${question.id}-opt-${i}`}
                      className="flex-1 cursor-pointer font-normal text-foreground"
                    >
                      <span className="mr-1.5 font-semibold text-muted-foreground">
                        {String.fromCharCode(65 + i)}.
                      </span>
                      {opt}
                    </Label>
                  </div>
                );
              })}
            </RadioGroup>
          )
        ) : question.type === "SHORT_ANSWER" ? (
          <div className="grid gap-1.5">
            <Label htmlFor={`q-${question.id}-answer`} className="text-xs">
              Your answer
            </Label>
            <Input
              id={`q-${question.id}-answer`}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="Type your answer…"
              disabled={disabled}
              autoComplete="off"
            />
          </div>
        ) : (
          // CODING
          <div className="grid gap-1.5">
            <Label htmlFor={`q-${question.id}-code`} className="text-xs">
              Your code
            </Label>
            <Textarea
              id={`q-${question.id}-code`}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="// Write your solution here…"
              disabled={disabled}
              rows={10}
              className="font-mono text-xs"
              spellCheck={false}
            />
            <p className="text-xs text-muted-foreground">
              Coding answers are reviewed manually after submission.
            </p>
          </div>
        )}

        {isAnswered && (
          <p className="mt-2 inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="size-3" />
            Answered
          </p>
        )}
      </CardContent>
    </Card>
  );
}
