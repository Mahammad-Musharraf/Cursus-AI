"use client";

import { useEffect, useRef, useState } from "react";
import { Sparkles, Send, Info, Loader2, Bot } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { api } from "@/lib/api";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt?: string;
};

type ChatResponse = {
  messages: ChatMessage[];
  aiEnabled: boolean;
};

const SUGGESTIONS = [
  "What should I focus on next?",
  "Explain my skill gaps",
  "Suggest a problem to solve",
];

function fmtTime(iso?: string) {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

export default function AiChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [aiEnabled, setAiEnabled] = useState<boolean>(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  const scrollRef = useRef<HTMLDivElement | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    api<ChatResponse>("/api/ai-chat").then((res) => {
      setLoading(false);
      if (res.data) {
        setMessages(res.data.messages);
        setAiEnabled(res.data.aiEnabled);
      } else {
        setError(res.error || "Failed to load conversation.");
      }
    });
  }, []);

  // Auto-scroll to bottom whenever messages change
  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [messages, sending]);

  async function send(text?: string) {
    const content = (text ?? input).trim();
    if (!content || sending) return;
    setInput("");
    setSending(true);

    const tempId = `temp-${Date.now()}`;
    const userMsg: ChatMessage = {
      id: tempId,
      role: "user",
      content,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);

    const res = await api<{ reply: string; usedAI: boolean }>(
      "/api/ai-chat",
      {
        method: "POST",
        body: JSON.stringify({ message: content }),
      }
    );
    setSending(false);

    if (res.data) {
      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: "assistant",
        content: res.data.reply,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } else {
      toast.error(res.error || "Couldn't get a reply. Please try again.");
      // remove the optimistic user msg
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // Enter sends; Shift+Enter newline
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  if (loading) {
    return (
      <>
        <PageHeader
          title="AI mentor"
          description="Ask anything about your path — skills, next steps, problems, careers."
        />
        <LoadingState label="Loading your conversation…" />
      </>
    );
  }
  if (error) {
    return (
      <>
        <PageHeader title="AI mentor" />
        <ErrorState message={error} />
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="AI mentor"
        description="Your personal guide for skills, roadmaps, and practice."
      />

      {!aiEnabled && (
        <Alert className="mb-4">
          <Info className="size-4" />
          <AlertDescription>
            Running in guidance mode (set <code className="rounded bg-muted px-1 py-0.5 text-xs">ZAI_API_KEY</code> for full AI). Responses use rule-based advice for now.
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardContent className="p-0">
          <div
            ref={scrollRef}
            className="h-[60vh] overflow-y-auto scrollbar-thin p-4 sm:p-6"
          >
            {messages.length === 0 && !sending ? (
              <div className="flex h-full items-center justify-center">
                <EmptyState
                  title="Ask me anything about your path"
                  description="Get help with your skill gaps, roadmap, or what to practice next."
                  icon={Sparkles}
                />
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((m) => {
                  const isUser = m.role === "user";
                  const time = fmtTime(m.createdAt);
                  return (
                    <div
                      key={m.id}
                      className={`flex gap-3 ${
                        isUser ? "flex-row-reverse" : ""
                      }`}
                    >
                      <div
                        className={`flex size-8 shrink-0 items-center justify-center rounded-full ${
                          isUser
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-foreground"
                        }`}
                      >
                        {isUser ? (
                          <span className="text-xs font-bold">You</span>
                        ) : (
                          <Bot className="size-4" />
                        )}
                      </div>
                      <div
                        className={`flex max-w-[80%] flex-col ${
                          isUser ? "items-end" : "items-start"
                        }`}
                      >
                        <div
                          className={`whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                            isUser
                              ? "rounded-tr-sm bg-primary text-primary-foreground"
                              : "rounded-tl-sm border border-border bg-card text-card-foreground"
                          }`}
                        >
                          {m.content}
                        </div>
                        {time && (
                          <span className="mt-1 px-1 text-[10px] text-muted-foreground">
                            {time}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}

                {sending && (
                  <div className="flex gap-3">
                    <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary text-foreground">
                      <Bot className="size-4" />
                    </div>
                    <div className="flex items-center gap-2 rounded-2xl rounded-tl-sm border border-border bg-card px-4 py-3 text-sm text-muted-foreground">
                      <Loader2 className="size-4 animate-spin" />
                      Thinking…
                    </div>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>
            )}
          </div>

          {/* Suggestions */}
          <div className="border-t border-border p-3">
            <div className="mb-3 flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setInput(s)}
                  disabled={sending}
                  className="rounded-full border border-border bg-background px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:bg-primary/5 hover:text-primary disabled:opacity-50"
                >
                  {s}
                </button>
              ))}
            </div>

            <div className="flex items-end gap-2">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder="Type your question… (Enter to send, Shift+Enter for newline)"
                className="min-h-[44px] flex-1 resize-none"
                rows={1}
                disabled={sending}
              />
              <Button
                onClick={() => send()}
                disabled={sending || !input.trim()}
                className="h-[44px]"
              >
                {sending ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Send className="size-4" />
                )}
                <span className="hidden sm:inline">
                  {sending ? "Sending…" : "Send"}
                </span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
