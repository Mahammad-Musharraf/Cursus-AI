"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, ArrowLeft, MapPin, CheckCircle2, AlertCircle } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState } from "@/components/states";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { api } from "@/lib/api";
import Link from "next/link";

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: string;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  companyName: string;
  hasApplied: boolean;
  applicationStage: string | null;
  eligible: boolean;
};

const STAGE_LABELS: Record<string, string> = {
  APPLIED: "Applied",
  SHORTLISTED: "Shortlisted",
  EXAM: "Exam",
  INTERVIEW: "Interview",
  OFFER: "Offer",
  REJECTED: "Rejected",
};

export default function StudentJobDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [coverNote, setCoverNote] = useState("");
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);

  async function load() {

    const [jobsRes, appsRes] = await Promise.all([
      api<{ jobs: Job[] }>("/api/jobs"),
      api<{ applications: { job: { id: string }; stage: string }[] }>("/api/student/applications"),
    ]);
    setLoading(false);
    if (jobsRes.error || !jobsRes.data) {
      setError(jobsRes.error || "Failed to load job");
      return;
    }
    const found = jobsRes.data.jobs.find((j) => j.id === params.id);
    if (!found) {
      setError("Job not found.");
      return;
    }
    const app = appsRes.data?.applications.find((a) => a.job.id === params.id);
    setJob({ ...found, hasApplied: !!app, applicationStage: app?.stage ?? null });
    setApplied(!!app);
  }

  useEffect(() => {
    // Inline the initial fetch so setState stays out of the effect body
    // (initial state is loading:true). The standalone load() is used by
    // the retry button as an event handler.
    Promise.resolve().then(() => load());
  }, []);

  async function apply() {
    setApplying(true);
    const res = await api<{ ok?: boolean; error?: string }>(
      `/api/jobs/${params.id}/apply`,
      {
        method: "POST",
        body: JSON.stringify({ coverNote: coverNote || undefined }),
      }
    );
    setApplying(false);
    if (res.error) {
      toast.error(res.data?.error || res.error);
      return;
    }
    toast.success("Application submitted!");
    setApplied(true);
  }

  if (loading) return <><PageHeader title="Job detail" /><LoadingState /></>;
  if (error) return <><PageHeader title="Job detail" /><ErrorState message={error} /></>;
  if (!job) return <><PageHeader title="Job detail" /><ErrorState message="Not found" /></>;

  return (
    <>
      <PageHeader
        title={job.title}
        description={job.description}
      >
        <Button asChild variant="outline" size="sm">
          <Link href="/dashboard/student/jobs"><ArrowLeft className="size-4" /> Back to jobs</Link>
        </Button>
      </PageHeader>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card><CardContent className="p-5">
            <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1"><MapPin className="size-4" /> {job.location}</span>
              <Badge variant="outline" className="font-normal">{job.jobType.replace("_", " ")}</Badge>
              {job.packageLpa && <span className="font-medium text-primary">{job.packageLpa}</span>}
            </div>
            <h3 className="mt-4 text-sm font-semibold">Required skills</h3>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {job.requiredSkills.split(",").filter(Boolean).map((s) => (
                <Badge key={s} variant="secondary" className="font-normal">{s.trim()}</Badge>
              ))}
            </div>
            <p className="mt-4 text-xs text-muted-foreground">Posted by {job.companyName}</p>
          </CardContent></Card>
        </div>

        <div>
          <Card><CardContent className="p-5">
            {applied ? (
              <div className="text-center">
                <div className="mb-3 inline-flex size-12 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                  <CheckCircle2 className="size-6" />
                </div>
                <h3 className="text-sm font-semibold">Application submitted</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  {job.applicationStage ? `Current stage: ${STAGE_LABELS[job.applicationStage] ?? job.applicationStage}` : "We'll notify you of updates."}
                </p>
              </div>
            ) : (
              <>
                {!job.eligible && (
                  <Alert className="mb-4 border-amber-200 bg-amber-50">
                    <AlertCircle className="size-4 text-amber-600" />
                    <AlertDescription className="text-amber-700">
                      You don&apos;t meet the minimum score requirement ({job.minAvgScore}%), but you can still apply.
                    </AlertDescription>
                  </Alert>
                )}
                <h3 className="text-sm font-semibold">Apply to this job</h3>
                <p className="mt-1 text-xs text-muted-foreground">Add an optional cover note.</p>
                <div className="mt-3 space-y-2">
                  <Label htmlFor="coverNote">Cover note (optional)</Label>
                  <Textarea
                    id="coverNote"
                    value={coverNote}
                    onChange={(e) => setCoverNote(e.target.value)}
                    placeholder="Why are you a great fit?"
                    rows={4}
                  />
                </div>
                <Button onClick={apply} disabled={applying} className="mt-4 w-full">
                  {applying && <Loader2 className="size-4 animate-spin" />}
                  Apply now
                </Button>
              </>
            )}
          </CardContent></Card>
        </div>
      </div>
    </>
  );
}
