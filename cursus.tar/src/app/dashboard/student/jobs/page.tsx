"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BriefcaseBusiness, MapPin, CheckCircle2, AlertCircle } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { LoadingState, ErrorState, EmptyState } from "@/components/states";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import Link from "next/link";

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: string;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  companyName: string;
  createdAt: string;
  hasApplied: boolean;
  applicationStage: string | null;
  eligible: boolean;
};

type Application = {
  id: string;
  stage: string;
  coverNote: string | null;
  createdAt: string;
  updatedAt: string;
  job: {
    id: string;
    title: string;
    location: string;
    jobType: string;
    packageLpa: string | null;
    companyName: string;
  };
};

const STAGE_LABELS: Record<string, string> = {
  APPLIED: "Applied",
  SHORTLISTED: "Shortlisted",
  EXAM: "Exam",
  INTERVIEW: "Interview",
  OFFER: "Offer",
  REJECTED: "Rejected",
};
const STAGE_TONES: Record<string, "default" | "secondary" | "destructive"> = {
  APPLIED: "secondary",
  SHORTLISTED: "default",
  EXAM: "secondary",
  INTERVIEW: "default",
  OFFER: "default",
  REJECTED: "destructive",
};

export default function StudentJobsPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [studentAvg, setStudentAvg] = useState(0);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {

    const [jobsRes, appsRes] = await Promise.all([
      api<{ studentAvg: number; jobs: Job[] }>("/api/jobs"),
      api<{ applications: Application[] }>("/api/student/applications"),
    ]);
    setLoading(false);
    if (jobsRes.data) {
      setJobs(jobsRes.data.jobs);
      setStudentAvg(jobsRes.data.studentAvg);
    } else {
      setError(jobsRes.error || "Failed to load jobs");
      return;
    }
    if (appsRes.data) setApplications(appsRes.data.applications);
  }

  useEffect(() => {
    // Inline the initial fetch so setState stays out of the effect body
    // (initial state is loading:true). The standalone load() is used by
    // the retry button as an event handler.
    Promise.resolve().then(() => load());
  }, []);

  if (loading) return <><PageHeader title="Jobs" description="Browse openings and track your applications." /><LoadingState /></>;
  if (error) return <><PageHeader title="Jobs" /><ErrorState message={error} action={<Button onClick={load}>Try again</Button>} /></>;

  return (
    <>
      <PageHeader title="Jobs" description={`Your avg score: ${studentAvg}%. Browse openings and apply.`} />
      <Tabs defaultValue="browse">
        <TabsList className="mb-4">
          <TabsTrigger value="browse">Browse jobs ({jobs.length})</TabsTrigger>
          <TabsTrigger value="applications">My applications ({applications.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="browse">
          {jobs.length === 0 ? (
            <EmptyState icon={BriefcaseBusiness} title="No open jobs yet" description="Recruiters' job postings will appear here." />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {jobs.map((job) => (
                <Card key={job.id} className="flex flex-col">
                  <CardContent className="flex flex-1 flex-col p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="text-base font-semibold">{job.title}</h3>
                        <p className="text-sm text-muted-foreground">{job.companyName}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1"><MapPin className="size-3" />{job.location}</span>
                          <Badge variant="outline" className="font-normal">{job.jobType.replace("_", " ")}</Badge>
                        </div>
                      </div>
                      {job.hasApplied && <Badge variant="default" className="font-normal">Applied</Badge>}
                    </div>
                    <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{job.description}</p>
                    <div className="mt-3 flex flex-wrap gap-1">
                      {job.requiredSkills.split(",").filter(Boolean).map((s) => (
                        <Badge key={s} variant="secondary" className="font-normal">{s.trim()}</Badge>
                      ))}
                    </div>
                    <div className="mt-auto flex items-center justify-between pt-4">
                      <div className="flex items-center gap-2 text-xs">
                        {job.eligible ? (
                          <span className="inline-flex items-center gap-1 text-emerald-600"><CheckCircle2 className="size-3" /> Eligible</span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-amber-600"><AlertCircle className="size-3" /> Min {job.minAvgScore}%</span>
                        )}
                        {job.packageLpa && <span className="text-muted-foreground">· {job.packageLpa}</span>}
                      </div>
                      <Button asChild size="sm">
                        <Link href={`/dashboard/student/jobs/${job.id}`}>{job.hasApplied ? "View" : "View & apply"}</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="applications">
          {applications.length === 0 ? (
            <EmptyState icon={BriefcaseBusiness} title="No applications yet" description="Jobs you apply to will show your status here." />
          ) : (
            <div className="space-y-3">
              {applications.map((app) => (
                <Card key={app.id}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="min-w-0">
                      <p className="font-medium">{app.job.title}</p>
                      <p className="text-sm text-muted-foreground">{app.job.companyName} · {app.job.location}</p>
                      <p className="mt-1 text-xs text-muted-foreground">Updated {new Date(app.updatedAt).toLocaleDateString()}</p>
                    </div>
                    <Badge variant={STAGE_TONES[app.stage] ?? "secondary"} className="font-normal">
                      {STAGE_LABELS[app.stage] ?? app.stage}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </>
  );
}
