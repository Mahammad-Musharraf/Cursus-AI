import type { Metadata } from "next";
import { Inter, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Providers } from "@/components/providers";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Cursus AI — Forge Your Career Path",
    template: "%s · Cursus AI",
  },
  description:
    "Cursus AI is an AI career-to-placement platform for engineering students — skill assessments, personalized roadmaps, curated practice problems, and an AI mentor.",
  keywords: [
    "Cursus AI",
    "career",
    "placement",
    "engineering students",
    "skill gap",
    "roadmap",
    "AI mentor",
  ],
  authors: [{ name: "Cursus AI" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Cursus AI — Forge Your Career Path",
    description:
      "AI career-to-placement platform for engineering students.",
    siteName: "Cursus AI",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
          <Sonner richColors position="top-right" />
        </Providers>
      </body>
    </html>
  );
}
