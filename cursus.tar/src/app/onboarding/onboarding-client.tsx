"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, ArrowRight, Sparkles, Check, RotateCcw, Trophy } from "lucide-react";
import { PublicHeader } from "@/components/public-header";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { api } from "@/lib/api";

type Option = { label: string };
type Question = {
  id: string;
  prompt: string;
  helpText?: string;
  options: Option[];
};

type Recommendation = {
  careerId: string;
  slug: string;
  title: string;
  category: string;
  matchPct: number;
  reasons: string[];
};

export function OnboardingClient({ isRetake }: { isRetake: boolean }) {
  const router = useRouter();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<
    { questionId: string; question: string; answer: string; optionIndex: number }[]
  >([]);
  const [stage, setStage] = useState<"chat" | "loading-recs" | "results">("chat");
  const [recs, setRecs] = useState<Recommendation[]>([]);
  const [chosenSlug, setChosenSlug] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    api<{ questions: Question[] }>("/api/onboarding/questions").then((res) => {
      setLoading(false);
      if (res.data) setQuestions(res.data.questions);
      else toast.error(res.error || "Couldn't load questions");
    });
  }, []);

  function answer(optionIndex: number) {
    const q = questions[current];
    if (!q) return;
    const next = [
      ...answers,
      {
        questionId: q.id,
        question: q.prompt,
        answer: q.options[optionIndex].label,
        optionIndex,
      },
    ];
    setAnswers(next);
    if (current + 1 < questions.length) {
      setCurrent(current + 1);
    } else {
      getRecommendations(next);
    }
  }

  async function getRecommendations(finalAnswers: typeof answers) {
    setStage("loading-recs");
    const res = await api<{ recommendations: Recommendation[] }>(
      "/api/onboarding/recommend",
      {
        method: "POST",
        body: JSON.stringify({ answers: finalAnswers }),
      }
    );
    if (res.error || !res.data) {
      toast.error(res.error || "Couldn't compute recommendations");
      setStage("chat");
      return;
    }
    setRecs(res.data.recommendations);
    setStage("results");
  }

  async function choose(slug: string) {
    setChosenSlug(slug);
    setConfirming(true);
    const res = await api<{ ok?: boolean }>("/api/onboarding/choose", {
      method: "POST",
      body: JSON.stringify({ careerSlug: slug }),
    });
    setConfirming(false);
    if (res.error) {
      toast.error(res.error);
      setChosenSlug(null);
      return;
    }
    toast.success("Career path confirmed!");
    // Hard navigation so the fresh target career is reflected server-side.
    window.location.assign("/dashboard/student");
  }

  if (loading) {
    return (
      <div className="flex min-h-svh flex-col">
        <PublicHeader />
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="size-5 animate-spin text-muted-foreground" />
        </div>
        <SiteFooter />
      </div>
    );
  }

  const q = questions[current];
  const progressPct =
    stage === "results"
      ? 100
      : Math.round(((current + (stage === "loading-recs" ? 1 : 0)) / questions.length) * 100);

  return (
    <div className="flex min-h-svh flex-col bg-background">
      <PublicHeader />
      <main className="mx-auto w-full max-w-2xl flex-1 px-4 py-10 sm:px-6">
        {/* Header */}
        <div className="mb-6">
          <Badge variant="secondary" className="mb-3 gap-1.5">
            <Sparkles className="size-3.5 text-primary" />
            AI onboarding
          </Badge>
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            {isRetake ? "Let's find a better fit" : "Let's find your path"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            A quick conversation to recommend the best career paths for you. Honest
            answers = better matches.
          </p>
        </div>

        {/* Progress */}
        {stage !== "results" && (
          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
              <span>
                Question {Math.min(current + 1, questions.length)} of {questions.length}
              </span>
              <span>{progressPct}%</span>
            </div>
            <Progress value={progressPct} />
          </div>
        )}

        {/* Chat stage */}
        {stage === "chat" && q && (
          <Card className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            <CardContent className="p-6">
              <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Q{current + 1}
              </p>
              <h2 className="text-lg font-semibold">{q.prompt}</h2>
              {q.helpText && (
                <p className="mt-1 text-sm text-muted-foreground">{q.helpText}</p>
              )}
              <div className="mt-5 grid gap-2.5">
                {q.options.map((o, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => answer(i)}
                    className="flex items-center justify-between rounded-lg border border-border bg-background p-3.5 text-left text-sm transition-colors hover:border-primary/40 hover:bg-primary/5"
                  >
                    <span className="font-medium text-foreground">{o.label}</span>
                    <ArrowRight className="size-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading recommendations */}
        {stage === "loading-recs" && (
          <Card>
            <CardContent className="flex flex-col items-center gap-3 p-10 text-center">
              <Loader2 className="size-6 animate-spin text-primary" />
              <p className="text-sm font-medium">Analyzing your answers…</p>
              <p className="text-xs text-muted-foreground">
                Matching you against 14 software career paths.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Results stage */}
        {stage === "results" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Trophy className="size-5 text-primary" />
              <h2 className="text-lg font-semibold">Your top career matches</h2>
            </div>
            <p className="text-sm text-muted-foreground">
              Based on your answers, here are the paths we&apos;d recommend. Pick
              one to confirm — you can retake this anytime.
            </p>

            {recs.slice(0, 3).map((r, idx) => (
              <Card
                key={r.slug}
                className={idx === 0 ? "border-primary/40 ring-1 ring-primary/20" : ""}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                          #{idx + 1} · {r.category}
                        </span>
                      </div>
                      <h3 className="mt-0.5 text-base font-semibold">{r.title}</h3>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-semibold text-primary">
                        {r.matchPct}%
                      </div>
                      <div className="text-xs text-muted-foreground">match</div>
                    </div>
                  </div>
                  <ul className="mt-3 space-y-1.5">
                    {r.reasons.map((reason, i) => (
                      <li
                        key={i}
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                      >
                        <span className="mt-1.5 inline-block size-1.5 shrink-0 rounded-full bg-primary" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4">
                    <Button
                      onClick={() => choose(r.slug)}
                      disabled={confirming}
                      className="w-full sm:w-auto"
                    >
                      {confirming && chosenSlug === r.slug ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : chosenSlug === r.slug ? (
                        <Check className="size-4" />
                      ) : null}
                      {chosenSlug === r.slug ? "Confirmed" : "Choose this path"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="pt-2 text-center">
              <Button variant="ghost" size="sm" onClick={() => getRecommendations(answers)}>
                <RotateCcw className="size-3.5" />
                Not sure? Re-analyze
              </Button>
            </div>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
