import { redirect } from "next/navigation";
import { getCurrentUser, getCurrentUserRecord } from "@/lib/session";
import { OnboardingClient } from "./onboarding-client";

export default async function OnboardingPage({
  searchParams,
}: {
  searchParams: Promise<{ retake?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?callbackUrl=/onboarding");
  if (user.role !== "STUDENT") redirect(`/dashboard/${user.role.toLowerCase()}`);

  const { retake } = await searchParams;
  const isRetake = retake === "1";

  const rec = await getCurrentUserRecord();
  // If already onboarded and not explicitly retaking, go to dashboard.
  if (rec?.stage && rec?.targetCareerId && !isRetake) {
    redirect("/dashboard/student");
  }

  return <OnboardingClient isRetake={isRetake} />;
}
