import {
  READY_THRESHOLD,
  AT_RISK_THRESHOLD,
  scoreBand,
} from "@/lib/constants";

export type RequiredSkill = { skill: string; target: number; weight?: number };
export type RoadmapStep = {
  title: string;
  description: string;
  milestone?: string;
  skills?: string[];
};

export type StudentWithRelations = {
  id: string;
  name: string;
  email: string;
  stage: string | null;
  collegeCodeRef: string | null;
  assessments: { scores: unknown; takenAt: Date }[];
  problemProgress: { done: boolean }[];
  targetCareer: {
    id: string;
    title: string;
    requiredSkills: unknown;
    roadmap: unknown;
  } | null;
};

export function asScores(s: unknown): Record<string, number> {
  if (s && typeof s === "object") return s as Record<string, number>;
  return {};
}

export function asRequiredSkills(s: unknown): RequiredSkill[] {
  if (Array.isArray(s)) return s as RequiredSkill[];
  return [];
}

export function asRoadmap(s: unknown): RoadmapStep[] {
  if (Array.isArray(s)) return s as RoadmapStep[];
  return [];
}

export function latestScores(u: StudentWithRelations): Record<string, number> {
  if (!u.assessments?.length) return {};
  // assessments sorted desc by takenAt ideally; sort defensively
  const sorted = [...u.assessments].sort(
    (a, b) => b.takenAt.getTime() - a.takenAt.getTime()
  );
  return asScores(sorted[0].scores);
}

export type SkillGap = {
  skill: string;
  target: number;
  current: number;
  gap: number;
  band: { label: string; tone: "low" | "mid" | "high" };
};

export function skillGapFor(
  required: RequiredSkill[],
  scores: Record<string, number>
): SkillGap[] {
  return required.map((r) => {
    const current = scores[r.skill] ?? 0;
    const gap = Math.max(0, r.target - current);
    return {
      skill: r.skill,
      target: r.target,
      current,
      gap,
      band: scoreBand(current),
    };
  });
}

export type StudentAggregates = {
  hasAssessment: boolean;
  requiredSkills: RequiredSkill[];
  scores: Record<string, number>;
  skillGaps: SkillGap[];
  avgCurrent: number;
  avgTarget: number;
  readinessPct: number; // 0..100
  gapCount: number;
  solvedProblems: number;
  totalProblems: number;
  status: "no-assessment" | "at-risk" | "on-track" | "ready";
};

export function studentAggregates(u: StudentWithRelations): StudentAggregates {
  const required = asRequiredSkills(u.targetCareer?.requiredSkills);
  const scores = latestScores(u);
  const gaps = skillGapFor(required, scores);
  const avgCurrent =
    required.length > 0
      ? Math.round(
          required.reduce((sum, r) => sum + (scores[r.skill] ?? 0), 0) /
            required.length
        )
      : 0;
  const avgTarget =
    required.length > 0
      ? Math.round(required.reduce((sum, r) => sum + r.target, 0) / required.length)
      : 0;
  const readinessPct =
    avgTarget > 0 ? Math.min(100, Math.round((avgCurrent / avgTarget) * 100)) : 0;
  const gapCount = gaps.filter((g) => g.gap > 0).length;
  const solvedProblems = u.problemProgress?.filter((p) => p.done).length ?? 0;
  const totalProblems = u.problemProgress?.length ?? 0;

  let status: StudentAggregates["status"] = "on-track";
  if (!u.assessments?.length || Object.keys(scores).length === 0) {
    status = "no-assessment";
  } else if (avgCurrent < AT_RISK_THRESHOLD) {
    status = "at-risk";
  } else if (avgCurrent >= READY_THRESHOLD) {
    status = "ready";
  }

  return {
    hasAssessment: !!u.assessments?.length,
    requiredSkills: required,
    scores,
    skillGaps: gaps,
    avgCurrent,
    avgTarget,
    readinessPct,
    gapCount,
    solvedProblems,
    totalProblems,
    status,
  };
}
