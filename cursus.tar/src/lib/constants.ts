// Shared constants & enums for Cursus AI.
// Stored as string unions (not Prisma enums) so the schema is portable
// between SQLite (dev) and PostgreSQL (Vercel).

export const ROLES = ["STUDENT", "COLLEGE", "RECRUITER"] as const;
export type Role = (typeof ROLES)[number];

export const STAGES = ["AFTER_10TH", "AFTER_12TH", "IN_BTECH"] as const;
export type Stage = (typeof STAGES)[number];

export const STAGE_LABELS: Record<Stage, string> = {
  AFTER_10TH: "After 10th",
  AFTER_12TH: "After 12th",
  IN_BTECH: "In B.Tech",
};

export const STAGE_DESCRIPTIONS: Record<Stage, string> = {
  AFTER_10TH:
    "You've finished Class 10. Explore streams and start building foundational skills.",
  AFTER_12TH:
    "You've finished Class 12. Choose an engineering track and prepare for college admissions.",
  IN_BTECH:
    "You're in your B.Tech. Sharpen skills, build projects, and get placement-ready.",
};

export const PLATFORMS = ["LEETCODE", "GEEKSFORGEEKS", "CODECHEF"] as const;
export type Platform = (typeof PLATFORMS)[number];

export const PLATFORM_LABELS: Record<Platform, string> = {
  LEETCODE: "LeetCode",
  GEEKSFORGEEKS: "GeeksforGeeks",
  CODECHEF: "CodeChef",
};

export const DIFFICULTIES = ["EASY", "MEDIUM", "HARD"] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

export const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  EASY: "Easy",
  MEDIUM: "Medium",
  HARD: "Hard",
};

export const ROLE_LABELS: Record<Role, string> = {
  STUDENT: "Student",
  COLLEGE: "College T&P",
  RECRUITER: "Recruiter",
};

export const ROLE_DESCRIPTIONS: Record<Role, string> = {
  STUDENT: "Take assessments, get a personalized roadmap, and practice to get placement-ready.",
  COLLEGE: "Track batch readiness, spot at-risk students, and export reports.",
  RECRUITER: "Discover and shortlist verified, placement-ready candidates.",
};

// Thresholds for "at-risk" and "readiness"
export const AT_RISK_THRESHOLD = 40; // avg score below this => at-risk
export const READY_THRESHOLD = 70; // avg score >= this => placement-ready

export function scoreBand(score: number): {
  label: string;
  tone: "low" | "mid" | "high";
} {
  if (score < AT_RISK_THRESHOLD)
    return { label: "Needs work", tone: "low" };
  if (score < READY_THRESHOLD)
    return { label: "On track", tone: "mid" };
  return { label: "Placement-ready", tone: "high" };
}
