// All 14 software career paths for Cursus AI onboarding recommendations.
// Each career has: required skills (with target levels), a roadmap, and
// a set of tags used by the recommendation engine to match student answers.

export type CareerTag =
  | "coding" | "math" | "design" | "data" | "systems" | "security"
  | "frontend" | "backend" | "fullstack" | "ml" | "cloud" | "mobile"
  | "hardware" | "qa" | "research" | "product" | "creative";

export type CareerDef = {
  slug: string;
  title: string;
  category: string;
  stages: string;
  summary: string;
  avgSalary: string;
  icon: string;
  tags: CareerTag[];
  // skill -> target proficiency (0-100)
  requiredSkills: { skill: string; target: number; weight?: number }[];
  roadmap: { title: string; description: string; skills?: string[] }[];
  problems: {
    title: string;
    platform: "LEETCODE" | "GEEKSFORGEEKS" | "CODECHEF";
    difficulty: "EASY" | "MEDIUM" | "HARD";
    topic: string;
    url: string;
    skillSlug: string;
  }[];
};

export const CAREERS: CareerDef[] = [
  {
    slug: "ai-engineer",
    title: "AI Engineer",
    category: "Data & AI",
    stages: "IN_BTECH",
    summary:
      "Build and ship intelligent systems — LLM apps, agents, RAG pipelines and ML-powered features.",
    avgSalary: "₹10–22 LPA",
    icon: "brain",
    tags: ["coding", "ml", "data", "research", "backend"],
    requiredSkills: [
      { skill: "Python", target: 85, weight: 3 },
      { skill: "Machine Learning", target: 80, weight: 3 },
      { skill: "Data Structures", target: 75, weight: 2 },
      { skill: "Linear Algebra", target: 70, weight: 2 },
      { skill: "System Design", target: 65, weight: 2 },
      { skill: "NLP / LLMs", target: 75, weight: 2 },
    ],
    roadmap: [
      { title: "Master Python & ML foundations", description: "Python, NumPy, Pandas, scikit-learn and the ML lifecycle.", skills: ["Python", "Machine Learning"] },
      { title: "Deep Learning & LLMs", description: "Transformers, fine-tuning, embeddings and RAG.", skills: ["NLP / LLMs", "Linear Algebra"] },
      { title: "Build AI features end-to-end", description: "Agents, vector DBs, evaluation and deployment.", skills: ["System Design"] },
      { title: "Ship a portfolio project", description: "An LLM-powered app with evaluation and monitoring.", skills: [] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Data Structures" },
      { title: "Implement Linear Regression", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "ML", url: "https://www.geeksforgeeks.org/ml-linear-regression/", skillSlug: "Machine Learning" },
      { title: "Text Classification with Naive Bayes", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "NLP", url: "https://www.geeksforgeeks.org/ml-naive-bayes-classifier/", skillSlug: "NLP / LLMs" },
      { title: "Matrix Multiplication", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Linear Algebra", url: "https://www.geeksforgeeks.org/python-multiply-two-matrices/", skillSlug: "Linear Algebra" },
    ],
  },
  {
    slug: "ml-engineer",
    title: "ML Engineer",
    category: "Data & AI",
    stages: "IN_BTECH",
    summary:
      "Train, evaluate and deploy machine learning models into production systems.",
    avgSalary: "₹9–20 LPA",
    icon: "brain",
    tags: ["coding", "ml", "data", "math", "systems", "cloud"],
    requiredSkills: [
      { skill: "Python", target: 85, weight: 3 },
      { skill: "Machine Learning", target: 85, weight: 3 },
      { skill: "Statistics", target: 80, weight: 3 },
      { skill: "MLOps", target: 70, weight: 2 },
      { skill: "SQL", target: 70, weight: 2 },
      { skill: "Linear Algebra", target: 75, weight: 2 },
    ],
    roadmap: [
      { title: "Maths & Stats for ML", description: "Linear algebra, probability and statistics.", skills: ["Statistics", "Linear Algebra"] },
      { title: "Classical ML", description: "Regression, trees, clustering and model evaluation.", skills: ["Machine Learning"] },
      { title: "Deep Learning", description: "Neural nets, CNNs, RNNs and transformers.", skills: ["Machine Learning"] },
      { title: "MLOps & Deployment", description: "Pipelines, monitoring and serving models at scale.", skills: ["MLOps"] },
    ],
    problems: [
      { title: "Basic SQL Select", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "SQL", url: "https://www.geeksforgeeks.org/sql-select/", skillSlug: "SQL" },
      { title: "Logistic Regression from scratch", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "ML", url: "https://www.geeksforgeeks.org/implementation-of-logistic-regression-from-scratch-using-python/", skillSlug: "Machine Learning" },
      { title: "Statistics: Mean, Median, Mode", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Statistics", url: "https://www.geeksforgeeks.org/statistics-mean-median-mode/", skillSlug: "Statistics" },
    ],
  },
  {
    slug: "data-analyst",
    title: "Data Analyst",
    category: "Data & AI",
    stages: "IN_BTECH",
    summary:
      "Turn raw data into clear insights with SQL, dashboards and statistics.",
    avgSalary: "₹6–14 LPA",
    icon: "chart",
    tags: ["data", "math", "coding", "product"],
    requiredSkills: [
      { skill: "SQL", target: 85, weight: 3 },
      { skill: "Statistics", target: 75, weight: 3 },
      { skill: "Python", target: 70, weight: 2 },
      { skill: "Excel", target: 75, weight: 2 },
      { skill: "Data Visualization", target: 80, weight: 2 },
      { skill: "Communication", target: 70, weight: 1 },
    ],
    roadmap: [
      { title: "SQL mastery", description: "Joins, window functions and aggregations.", skills: ["SQL"] },
      { title: "Statistics & Excel", description: "Distributions, hypothesis testing and pivot tables.", skills: ["Statistics", "Excel"] },
      { title: "Python for analysis", description: "Pandas, NumPy and data wrangling.", skills: ["Python"] },
      { title: "Dashboards & storytelling", description: "Tableau/Power BI and clear charts.", skills: ["Data Visualization", "Communication"] },
    ],
    problems: [
      { title: "Second Highest Salary", platform: "LEETCODE", difficulty: "MEDIUM", topic: "SQL", url: "https://leetcode.com/problems/second-highest-salary/", skillSlug: "SQL" },
      { title: "Combine Two Tables", platform: "LEETCODE", difficulty: "EASY", topic: "SQL Joins", url: "https://leetcode.com/problems/combine-two-tables/", skillSlug: "SQL" },
      { title: "Pandas DataFrame Basics", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Python", url: "https://www.geeksforgeeks.org/python-pandas-dataframe/", skillSlug: "Python" },
    ],
  },
  {
    slug: "data-scientist",
    title: "Data Scientist",
    category: "Data & AI",
    stages: "IN_BTECH",
    summary:
      "Combine statistics, ML and business sense to solve open-ended problems.",
    avgSalary: "₹9–20 LPA",
    icon: "brain",
    tags: ["data", "ml", "math", "research", "coding"],
    requiredSkills: [
      { skill: "Python", target: 85, weight: 3 },
      { skill: "Statistics", target: 80, weight: 3 },
      { skill: "SQL", target: 75, weight: 2 },
      { skill: "Machine Learning", target: 80, weight: 3 },
      { skill: "Data Visualization", target: 65, weight: 1 },
      { skill: "Linear Algebra", target: 70, weight: 2 },
    ],
    roadmap: [
      { title: "Python for Data", description: "NumPy, Pandas and wrangling.", skills: ["Python"] },
      { title: "Statistics & Probability", description: "Distributions, testing, regression.", skills: ["Statistics", "Linear Algebra"] },
      { title: "Machine Learning", description: "Supervised, unsupervised and evaluation.", skills: ["Machine Learning"] },
      { title: "Portfolio & Kaggle", description: "2 end-to-end ML projects.", skills: ["Data Visualization"] },
    ],
    problems: [
      { title: "Basic SQL Select", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "SQL", url: "https://www.geeksforgeeks.org/sql-select/", skillSlug: "SQL" },
      { title: "Linear Regression From Scratch", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "ML", url: "https://www.geeksforgeeks.org/ml-linear-regression/", skillSlug: "Machine Learning" },
    ],
  },
  {
    slug: "data-engineer",
    title: "Data Engineer",
    category: "Data & AI",
    stages: "IN_BTECH",
    summary:
      "Build the pipelines and warehouses that move data reliably at scale.",
    avgSalary: "₹8–18 LPA",
    icon: "database",
    tags: ["data", "systems", "coding", "cloud", "backend"],
    requiredSkills: [
      { skill: "SQL", target: 85, weight: 3 },
      { skill: "Python", target: 80, weight: 3 },
      { skill: "Data Structures", target: 75, weight: 2 },
      { skill: "System Design", target: 70, weight: 2 },
      { skill: "Cloud & Big Data", target: 70, weight: 2 },
      { skill: "Databases", target: 80, weight: 2 },
    ],
    roadmap: [
      { title: "SQL & databases", description: "Schema design, indexing, warehousing.", skills: ["SQL", "Databases"] },
      { title: "Python pipelines", description: "ETL, Airflow and orchestration.", skills: ["Python"] },
      { title: "Big data & cloud", description: "Spark, Kafka, S3 and data lakes.", skills: ["Cloud & Big Data"] },
      { title: "Build a data platform", description: "Ingest, transform and serve analytics.", skills: ["System Design"] },
    ],
    problems: [
      { title: "Combine Two Tables", platform: "LEETCODE", difficulty: "EASY", topic: "SQL Joins", url: "https://leetcode.com/problems/combine-two-tables/", skillSlug: "SQL" },
      { title: "Design a Rate Limiter", platform: "GEEKSFORGEEKS", difficulty: "HARD", topic: "System Design", url: "https://www.geeksforgeeks.org/system-design/rate-limiting-system-design/", skillSlug: "System Design" },
    ],
  },
  {
    slug: "full-stack-developer",
    title: "Full Stack Developer",
    category: "Software Engineering",
    stages: "IN_BTECH",
    summary:
      "Own features end-to-end — from database to polished UI.",
    avgSalary: "₹8–17 LPA",
    icon: "layers",
    tags: ["fullstack", "frontend", "backend", "coding"],
    requiredSkills: [
      { skill: "HTML & CSS", target: 80, weight: 2 },
      { skill: "JavaScript", target: 85, weight: 3 },
      { skill: "React", target: 80, weight: 3 },
      { skill: "Node.js", target: 80, weight: 3 },
      { skill: "Databases", target: 75, weight: 2 },
      { skill: "Data Structures", target: 75, weight: 2 },
    ],
    roadmap: [
      { title: "Frontend foundations", description: "HTML, CSS, JavaScript, React.", skills: ["HTML & CSS", "JavaScript", "React"] },
      { title: "Backend with Node.js", description: "Express, REST, auth, middleware.", skills: ["Node.js"] },
      { title: "Databases", description: "SQL & NoSQL schema design.", skills: ["Databases"] },
      { title: "Deploy a full-stack app", description: "CI/CD, hosting, monitoring.", skills: [] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Data Structures" },
      { title: "Promise Pool", platform: "LEETCODE", difficulty: "MEDIUM", topic: "JavaScript", url: "https://leetcode.com/problems/promise-pool/", skillSlug: "JavaScript" },
      { title: "Build a REST API with Express", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "Node.js", url: "https://www.geeksforgeeks.org/express-js/", skillSlug: "Node.js" },
    ],
  },
  {
    slug: "frontend-developer",
    title: "Frontend Developer",
    category: "Software Engineering",
    stages: "IN_BTECH",
    summary:
      "Build fast, accessible and beautiful user interfaces for the web.",
    avgSalary: "₹7–16 LPA",
    icon: "layout",
    tags: ["frontend", "design", "coding", "creative", "product"],
    requiredSkills: [
      { skill: "HTML & CSS", target: 85, weight: 2 },
      { skill: "JavaScript", target: 85, weight: 3 },
      { skill: "React", target: 80, weight: 3 },
      { skill: "TypeScript", target: 70, weight: 2 },
      { skill: "UI/UX Basics", target: 65, weight: 1 },
      { skill: "Testing", target: 60, weight: 1 },
    ],
    roadmap: [
      { title: "Master HTML, CSS & JS", description: "Semantic markup, modern CSS, ES6+.", skills: ["HTML & CSS", "JavaScript"] },
      { title: "Learn React deeply", description: "Components, hooks, state, routing.", skills: ["React"] },
      { title: "Add TypeScript", description: "Type safety for larger codebases.", skills: ["TypeScript"] },
      { title: "Ship a portfolio", description: "2–3 production-quality projects.", skills: ["UI/UX Basics"] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "JavaScript" },
      { title: "Debounce Function", platform: "LEETCODE", difficulty: "MEDIUM", topic: "Closures", url: "https://leetcode.com/problems/debounce/", skillSlug: "JavaScript" },
      { title: "Build a Todo App in React", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "React", url: "https://www.geeksforgeeks.org/reactjs-todo-app/", skillSlug: "React" },
    ],
  },
  {
    slug: "backend-developer",
    title: "Backend Developer",
    category: "Software Engineering",
    stages: "IN_BTECH",
    summary:
      "Design and build scalable backend services, APIs and data systems.",
    avgSalary: "₹8–18 LPA",
    icon: "server",
    tags: ["backend", "systems", "coding", "data", "cloud"],
    requiredSkills: [
      { skill: "Data Structures", target: 85, weight: 3 },
      { skill: "Algorithms", target: 85, weight: 3 },
      { skill: "DBMS", target: 75, weight: 2 },
      { skill: "Operating Systems", target: 70, weight: 2 },
      { skill: "System Design", target: 65, weight: 2 },
      { skill: "Backend Development", target: 80, weight: 3 },
    ],
    roadmap: [
      { title: "DSA mastery", description: "Arrays, trees, graphs, hashing. 150+ problems.", skills: ["Data Structures", "Algorithms"] },
      { title: "Core CS", description: "DBMS, OS, networks.", skills: ["DBMS", "Operating Systems"] },
      { title: "Backend projects", description: "REST APIs, auth, databases.", skills: ["Backend Development"] },
      { title: "System design", description: "Scaling, caching, load balancing.", skills: ["System Design"] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays / Hashing", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Data Structures" },
      { title: "Reverse Linked List", platform: "LEETCODE", difficulty: "EASY", topic: "Linked Lists", url: "https://leetcode.com/problems/reverse-linked-list/", skillSlug: "Data Structures" },
      { title: "Course Schedule", platform: "LEETCODE", difficulty: "MEDIUM", topic: "Graphs / Topo Sort", url: "https://leetcode.com/problems/course-schedule/", skillSlug: "Algorithms" },
      { title: "Design a URL Shortener", platform: "GEEKSFORGEEKS", difficulty: "HARD", topic: "System Design", url: "https://www.geeksforgeeks.org/system-design/system-design-url-shortener-like-tinyurl/", skillSlug: "System Design" },
    ],
  },
  {
    slug: "mobile-app-developer",
    title: "Mobile App Developer",
    category: "Software Engineering",
    stages: "IN_BTECH",
    summary:
      "Build native and cross-platform mobile apps for iOS and Android.",
    avgSalary: "₹7–16 LPA",
    icon: "smartphone",
    tags: ["mobile", "frontend", "coding", "product"],
    requiredSkills: [
      { skill: "JavaScript", target: 80, weight: 2 },
      { skill: "React Native", target: 80, weight: 3 },
      { skill: "Mobile UI/UX", target: 70, weight: 2 },
      { skill: "Data Structures", target: 70, weight: 2 },
      { skill: "APIs & Networking", target: 70, weight: 2 },
      { skill: "Testing", target: 60, weight: 1 },
    ],
    roadmap: [
      { title: "JavaScript & React foundations", description: "ES6+, hooks, state.", skills: ["JavaScript", "React Native"] },
      { title: "React Native deep dive", description: "Navigation, native modules, performance.", skills: ["React Native"] },
      { title: "Mobile UI & APIs", description: "Design systems and REST integration.", skills: ["Mobile UI/UX", "APIs & Networking"] },
      { title: "Ship an app", description: "Deploy to stores.", skills: [] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Data Structures" },
      { title: "Debounce Function", platform: "LEETCODE", difficulty: "MEDIUM", topic: "Closures", url: "https://leetcode.com/problems/debounce/", skillSlug: "JavaScript" },
    ],
  },
  {
    slug: "devops-cloud-engineer",
    title: "DevOps / Cloud Engineer",
    category: "Infrastructure",
    stages: "IN_BTECH",
    summary:
      "Automate deployments, manage cloud infra and keep systems reliable.",
    avgSalary: "₹8–18 LPA",
    icon: "cloud",
    tags: ["cloud", "systems", "backend", "coding", "security"],
    requiredSkills: [
      { skill: "Linux & Scripting", target: 80, weight: 3 },
      { skill: "Cloud Platforms", target: 75, weight: 3 },
      { skill: "Docker & Kubernetes", target: 75, weight: 3 },
      { skill: "CI/CD", target: 75, weight: 2 },
      { skill: "System Design", target: 70, weight: 2 },
      { skill: "Networking", target: 65, weight: 2 },
    ],
    roadmap: [
      { title: "Linux & shell scripting", description: "Bash, processes, permissions.", skills: ["Linux & Scripting"] },
      { title: "Cloud fundamentals", description: "AWS/GCP core services and IAM.", skills: ["Cloud Platforms"] },
      { title: "Containers & orchestration", description: "Docker, Kubernetes, Helm.", skills: ["Docker & Kubernetes"] },
      { title: "CI/CD pipelines", description: "GitHub Actions, Terraform, monitoring.", skills: ["CI/CD"] },
    ],
    problems: [
      { title: "Implement a Load Balancer", platform: "GEEKSFORGEEKS", difficulty: "HARD", topic: "System Design", url: "https://www.geeksforgeeks.org/system-design/system-design-load-balancer/", skillSlug: "System Design" },
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Linux & Scripting" },
    ],
  },
  {
    slug: "cybersecurity-engineer",
    title: "Cybersecurity Engineer",
    category: "Security",
    stages: "IN_BTECH",
    summary:
      "Defend systems from threats — pentesting, forensics and secure design.",
    avgSalary: "₹8–18 LPA",
    icon: "shield",
    tags: ["security", "systems", "coding", "networking"],
    requiredSkills: [
      { skill: "Networking", target: 80, weight: 3 },
      { skill: "Operating Systems", target: 75, weight: 2 },
      { skill: "Cryptography", target: 70, weight: 2 },
      { skill: "Python", target: 70, weight: 2 },
      { skill: "Web Security", target: 80, weight: 3 },
      { skill: "Linux & Scripting", target: 75, weight: 2 },
    ],
    roadmap: [
      { title: "Networking & OS fundamentals", description: "TCP/IP, Linux internals.", skills: ["Networking", "Operating Systems"] },
      { title: "Web security", description: "OWASP Top 10, SQLi, XSS, CSRF.", skills: ["Web Security"] },
      { title: "Cryptography & scripting", description: "Encryption, hashing, Python tooling.", skills: ["Cryptography", "Python"] },
      { title: "Pentesting & CTFs", description: "Hands-on labs and reports.", skills: ["Linux & Scripting"] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "Python" },
      { title: "OWASP Top 10", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "Web Security", url: "https://www.geeksforgeeks.org/owasp-top-10-vulnerabilities/", skillSlug: "Web Security" },
    ],
  },
  {
    slug: "qa-automation-engineer",
    title: "QA Automation Engineer",
    category: "Software Engineering",
    stages: "IN_BTECH",
    summary:
      "Ensure quality with automated test suites, CI gates and bug hunting.",
    avgSalary: "₹6–14 LPA",
    icon: "check-circle",
    tags: ["qa", "coding", "systems", "product"],
    requiredSkills: [
      { skill: "Testing", target: 85, weight: 3 },
      { skill: "Python", target: 70, weight: 2 },
      { skill: "JavaScript", target: 70, weight: 2 },
      { skill: "Selenium / Cypress", target: 75, weight: 3 },
      { skill: "CI/CD", target: 65, weight: 2 },
      { skill: "Debugging", target: 70, weight: 2 },
    ],
    roadmap: [
      { title: "Testing fundamentals", description: "Manual vs automated, test pyramids.", skills: ["Testing"] },
      { title: "Automation tools", description: "Selenium, Cypress, Playwright.", skills: ["Selenium / Cypress"] },
      { title: "API & performance testing", description: "Postman, JMeter, k6.", skills: ["JavaScript", "Python"] },
      { title: "CI integration", description: "Test pipelines and reporting.", skills: ["CI/CD"] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "JavaScript" },
      { title: "Implement a Test Framework", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "Testing", url: "https://www.geeksforgeeks.org/software-testing-tutorial/", skillSlug: "Testing" },
    ],
  },
  {
    slug: "ui-ux-designer",
    title: "UI/UX Designer",
    category: "Design",
    stages: "IN_BTECH",
    summary:
      "Design intuitive, beautiful product experiences backed by research.",
    avgSalary: "₹6–15 LPA",
    icon: "pen-tool",
    tags: ["design", "creative", "product", "frontend"],
    requiredSkills: [
      { skill: "Design Thinking", target: 80, weight: 3 },
      { skill: "Figma", target: 85, weight: 3 },
      { skill: "User Research", target: 70, weight: 2 },
      { skill: "Visual Design", target: 75, weight: 2 },
      { skill: "Prototyping", target: 75, weight: 2 },
      { skill: "HTML & CSS", target: 60, weight: 1 },
    ],
    roadmap: [
      { title: "Design fundamentals", description: "Color, typography, layout, hierarchy.", skills: ["Visual Design"] },
      { title: "Figma mastery", description: "Components, auto-layout, design systems.", skills: ["Figma"] },
      { title: "UX research", description: "Interviews, personas, usability testing.", skills: ["User Research", "Design Thinking"] },
      { title: "Portfolio & case studies", description: "3–4 end-to-end design projects.", skills: ["Prototyping"] },
    ],
    problems: [
      { title: "Design a Login Screen in Figma", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Design", url: "https://www.geeksforgeeks.org/figma-tutorial/", skillSlug: "Figma" },
      { title: "User Research Methods", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "UX", url: "https://www.geeksforgeeks.org/user-research-methods/", skillSlug: "User Research" },
    ],
  },
  {
    slug: "embedded-iot-engineer",
    title: "Embedded / IoT Engineer",
    category: "Hardware",
    stages: "IN_BTECH",
    summary:
      "Program microcontrollers and build connected devices at the hardware-software edge.",
    avgSalary: "₹7–16 LPA",
    icon: "cpu",
    tags: ["hardware", "systems", "coding", "c-language", "networking"],
    requiredSkills: [
      { skill: "C / C++", target: 85, weight: 3 },
      { skill: "Microcontrollers", target: 75, weight: 3 },
      { skill: "Electronics", target: 70, weight: 2 },
      { skill: "RTOS", target: 65, weight: 2 },
      { skill: "Networking", target: 65, weight: 2 },
      { skill: "Python", target: 60, weight: 1 },
    ],
    roadmap: [
      { title: "C/C++ & electronics", description: "Pointers, memory, circuits, oscilloscope.", skills: ["C / C++", "Electronics"] },
      { title: "Microcontrollers", description: "Arduino, ESP32, sensors, actuators.", skills: ["Microcontrollers"] },
      { title: "RTOS & protocols", description: "FreeRTOS, I2C, SPI, MQTT.", skills: ["RTOS", "Networking"] },
      { title: "Build an IoT project", description: "End-to-end connected device + cloud.", skills: ["Python"] },
    ],
    problems: [
      { title: "Two Sum", platform: "LEETCODE", difficulty: "EASY", topic: "Arrays", url: "https://leetcode.com/problems/two-sum/", skillSlug: "C / C++" },
      { title: "Pointers in C", platform: "GEEKSFORGEEKS", difficulty: "MEDIUM", topic: "C", url: "https://www.geeksforgeeks.org/c-pointers/", skillSlug: "C / C++" },
    ],
  },
];

// Foundation careers for younger students (After 10th / After 12th) — not part
// of the 14 software paths but available for stage-based selection.
export const FOUNDATION_CAREERS: CareerDef[] = [
  {
    slug: "engineering-aspirant",
    title: "Engineering Aspirant",
    category: "Entrance Prep",
    stages: "AFTER_12TH",
    summary: "Prepare for engineering entrance exams like JEE.",
    avgSalary: "Admissions",
    icon: "rocket",
    tags: ["math", "research"],
    requiredSkills: [
      { skill: "Physics", target: 85, weight: 3 },
      { skill: "Mathematics", target: 85, weight: 3 },
      { skill: "Chemistry", target: 80, weight: 3 },
      { skill: "Logical Reasoning", target: 75, weight: 2 },
      { skill: "Programming Basics", target: 60, weight: 1 },
    ],
    roadmap: [
      { title: "Master Class 11–12 syllabus", description: "Physics, Chemistry, Mathematics depth.", skills: ["Physics", "Mathematics", "Chemistry"] },
      { title: "Practice previous papers", description: "JEE Main & Advanced pattern problems.", skills: ["Logical Reasoning"] },
      { title: "Mock tests & analysis", description: "Time management and weak-area focus.", skills: [] },
    ],
    problems: [
      { title: "Newton's Laws of Motion", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Physics", url: "https://www.geeksforgeeks.org/newtons-laws-of-motion/", skillSlug: "Physics" },
      { title: "Quadratic Equations", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Mathematics", url: "https://www.geeksforgeeks.org/quadratic-equations/", skillSlug: "Mathematics" },
    ],
  },
  {
    slug: "science-stream-explorer",
    title: "Science Stream Explorer",
    category: "Foundations",
    stages: "AFTER_10TH",
    summary: "Build strong foundations to take up the Science stream.",
    avgSalary: "Foundations",
    icon: "flask",
    tags: ["math", "research"],
    requiredSkills: [
      { skill: "Mathematics", target: 70, weight: 3 },
      { skill: "Science Basics", target: 70, weight: 3 },
      { skill: "Logical Reasoning", target: 65, weight: 2 },
      { skill: "English", target: 60, weight: 1 },
      { skill: "Computer Basics", target: 55, weight: 1 },
    ],
    roadmap: [
      { title: "Strengthen Maths basics", description: "Algebra, geometry, mensuration.", skills: ["Mathematics"] },
      { title: "Explore Science", description: "Physics, Chemistry, Biology fundamentals.", skills: ["Science Basics"] },
      { title: "Develop reasoning", description: "Puzzles and logical thinking.", skills: ["Logical Reasoning"] },
    ],
    problems: [
      { title: "Basic Algebra Practice", platform: "GEEKSFORGEEKS", difficulty: "EASY", topic: "Mathematics", url: "https://www.geeksforgeeks.org/algebra/", skillSlug: "Mathematics" },
    ],
  },
];
