import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import type { Role } from "@/lib/constants";

export async function getCurrentUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return null;
  return session.user as { id: string; email: string; name: string; role: Role };
}

export async function getCurrentUserRecord() {
  const u = await getCurrentUser();
  if (!u) return null;
  return db.user.findUnique({ where: { id: u.id } });
}

export function requireRole(role: Role) {
  return async () => {
    const u = await getCurrentUser();
    if (!u) {
      return { status: "unauthenticated" as const };
    }
    if (u.role !== role) {
      return { status: "forbidden" as const, user: u };
    }
    return { status: "ok" as const, user: u };
  };
}
