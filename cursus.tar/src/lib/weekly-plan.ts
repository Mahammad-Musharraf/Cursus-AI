// Weekly problem assignment + "today's problems" engine.
// Picks problems from the student's chosen career, biased toward their weakest
// skills, and schedules them across the week. Re-generates if the week changes
// or if the student completes/skips most of them.

import { db } from "@/lib/db";
import { asRequiredSkills, type StudentWithRelations } from "@/lib/student-stats";

const DAYS = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"] as const;

function isoWeekKey(date = new Date()): string {
  // Compute ISO week number + year.
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

export function currentWeekKey(): string {
  return isoWeekKey();
}

export function todayDayOfWeek(): string {
  const jsDay = new Date().getDay(); // 0=Sun..6=Sat
  // Map so Monday=0..Sunday=6
  const idx = (jsDay + 6) % 7;
  return DAYS[idx];
}

type ProblemLite = {
  id: string;
  title: string;
  platform: string;
  difficulty: string;
  topic: string;
  url: string;
  skillSlug: string;
};

export async function getWeeklyPlan(userId: string) {
  const user = await db.user.findUnique({
    where: { id: userId },
    include: {
      targetCareer: { include: { problems: true } },
      assessments: { orderBy: { takenAt: "desc" }, take: 1 },
      problemProgress: { include: { problem: true } },
    },
  });

  if (!user || !user.targetCareer) {
    return { weekKey: currentWeekKey(), days: [], generated: false };
  }

  const career = user.targetCareer;
  const problems: ProblemLite[] = career.problems;
  if (problems.length === 0) {
    return { weekKey: currentWeekKey(), days: [], generated: false };
  }

  const weekKey = currentWeekKey();

  // Existing assignments for this week
  let assignments = await db.problemAssignment.findMany({
    where: { userId, weekKey },
    include: { problem: true },
  });

  // If no plan yet, generate one for the week.
  if (assignments.length === 0) {
    const required = asRequiredSkills(career.requiredSkills);
    const scores =
      (user.assessments?.[0]?.scores as Record<string, number>) ?? {};

    // Build a difficulty progression across the week + bias to weak skills.
    // Sort problems: weakest skill first, then easy->hard.
    const skillWeakness = new Map<string, number>();
    for (const r of required) {
      const cur = scores[r.skill] ?? 0;
      const gap = Math.max(0, r.target - cur);
      skillWeakness.set(r.skill, gap);
    }

    const sorted = [...problems].sort((a, b) => {
      const wa = skillWeakness.get(a.skillSlug) ?? 0;
      const wb = skillWeakness.get(b.skillSlug) ?? 0;
      if (wb !== wa) return wb - wa; // weakest skill first
      const diffOrder: Record<string, number> = { EASY: 0, MEDIUM: 1, HARD: 2 };
      return (diffOrder[a.difficulty] ?? 1) - (diffOrder[b.difficulty] ?? 1);
    });

    // Assign up to 2 problems/day across up to 6 days (rest day Sunday).
    const perDay = 2;
    const daysToFill = 6;
    const toAssign = sorted.slice(0, perDay * daysToFill);
    const reasonForSkill = (skill: string) => {
      const gap = skillWeakness.get(skill) ?? 0;
      if (gap >= 30) return `Your biggest gap is ${skill} — let's chip away at it.`;
      if (gap >= 10) return `Strengthen ${skill} to lift your readiness.`;
      return `Keep ${skill} sharp with deliberate practice.`;
    };

    const rows: { problemId: string; dayOfWeek: string; reason: string }[] = [];
    toAssign.forEach((p, i) => {
      const dayIdx = Math.floor(i / perDay);
      if (dayIdx >= daysToFill) return;
      rows.push({
        problemId: p.id,
        dayOfWeek: DAYS[dayIdx],
        reason: reasonForSkill(p.skillSlug),
      });
    });

    // Use individual creates (createMany+skipDuplicates isn't supported on SQLite)
    for (const r of rows) {
      try {
        await db.problemAssignment.create({
          data: {
            userId,
            problemId: r.problemId,
            weekKey,
            dayOfWeek: r.dayOfWeek,
            reason: r.reason,
          },
        });
      } catch {
        // unique constraint violation → already assigned, skip
      }
    }

    assignments = await db.problemAssignment.findMany({
      where: { userId, weekKey },
      include: { problem: true },
    });
  }

  // Group by day, attach progress
  const progressMap = new Map(user.problemProgress.map((p) => [p.problemId, p.done]));
  const days = DAYS.map((day) => ({
    day,
    items: assignments
      .filter((a) => a.dayOfWeek === day)
      .map((a) => ({
        assignmentId: a.id,
        reason: a.reason,
        problem: {
          id: a.problem.id,
          title: a.problem.title,
          platform: a.problem.platform,
          difficulty: a.problem.difficulty,
          topic: a.problem.topic,
          url: a.problem.url,
          skillSlug: a.problem.skillSlug,
        },
        done: progressMap.get(a.problemId) ?? false,
      })),
  }));

  const today = todayDayOfWeek();
  const todayItems = days.find((d) => d.day === today)?.items ?? [];

  const total = assignments.length;
  const done = assignments.filter((a) => progressMap.get(a.problemId)).length;

  return {
    weekKey,
    today,
    days,
    todayItems,
    progress: { done, total, pct: total > 0 ? Math.round((done / total) * 100) : 0 },
    generated: true,
  };
}

// Adjust next problems based on completion. Called when a problem is marked done.
// For now: if the student completes >= 70% of the week, mark a note to regenerate
// next week with harder problems. Lightweight + transparent.
export async function noteProgressAndAdjust(userId: string) {
  const weekKey = currentWeekKey();
  const plan = await getWeeklyPlan(userId);
  if (plan.progress.total === 0) return;

  // If the student has completed everything, create a celebratory notification.
  if (plan.progress.done >= plan.progress.total && plan.progress.total >= 2) {
    const existing = await db.notification.findFirst({
      where: {
        userId,
        title: "Week plan complete! 🎉",
        // rough dedupe by createdAt same day
        createdAt: { gte: new Date(Date.now() - 1000 * 60 * 60 * 12) },
      },
    });
    if (!existing) {
      await db.notification.create({
        data: {
          userId,
          type: "success",
          title: "Week plan complete! 🎉",
          body: "You finished every assigned problem this week. Next week's plan will push you a bit harder.",
          link: "/dashboard/student/problems",
        },
      });
    }
  }
}
