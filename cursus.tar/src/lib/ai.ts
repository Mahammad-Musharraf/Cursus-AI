import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import {
  STAGE_LABELS,
  scoreBand,
  type Stage,
} from "@/lib/constants";

export type ChatTurn = { role: "user" | "assistant"; content: string };

export type StudentContext = {
  name: string;
  stage: Stage | null;
  careerTitle: string | null;
  careerSummary: string | null;
  requiredSkills: { skill: string; target: number }[];
  scores: Record<string, number>;
  totalProblems: number;
  solvedProblems: number;
  roadmap: { title: string; description: string }[];
};

export async function loadStudentContext(
  userId: string
): Promise<StudentContext> {
  const user = await db.user.findUnique({
    where: { id: userId },
    include: {
      targetCareer: true,
      assessments: { orderBy: { takenAt: "desc" }, take: 1 },
      problemProgress: { include: { problem: true } },
    },
  });

  const career = user?.targetCareer;
  const requiredSkills =
    (career?.requiredSkills as { skill: string; target: number }[]) ?? [];
  const latestScores =
    (user?.assessments?.[0]?.scores as Record<string, number>) ?? {};
  const problems = user?.problemProgress ?? [];
  const solved = problems.filter((p) => p.done).length;

  return {
    name: user?.name ?? "student",
    stage: (user?.stage as Stage) ?? null,
    careerTitle: career?.title ?? null,
    careerSummary: career?.summary ?? null,
    requiredSkills,
    scores: latestScores,
    totalProblems: problems.length,
    solvedProblems: solved,
    roadmap: (career?.roadmap as { title: string; description: string }[]) ?? [],
  };
}

function buildSystemPrompt(ctx: StudentContext): string {
  const gaps = ctx.requiredSkills
    .map((s) => {
      const have = ctx.scores[s.skill] ?? 0;
      const gap = Math.max(0, s.target - have);
      return `- ${s.skill}: current ${Math.round(have)}, target ${s.target}, gap ${Math.round(
        gap
      )} (${scoreBand(have).label})`;
    })
    .join("\n");

  const roadmapText = ctx.roadmap
    .map((i, idx) => `${idx + 1}. ${i.title} — ${i.description}`)
    .join("\n");

  return `You are Cursus AI, an encouraging, concise career mentor for engineering students.

Student profile:
- Name: ${ctx.name}
- Stage: ${ctx.stage ? STAGE_LABELS[ctx.stage] : "not set"}
- Target career: ${ctx.careerTitle ?? "not chosen"}
- Career summary: ${ctx.careerSummary ?? "n/a"}

Current skill scores vs targets:
${gaps || "- no assessment taken yet"}

Practice progress: ${ctx.solvedProblems}/${ctx.totalProblems} problems solved.

Roadmap steps:
${roadmapText || "- no roadmap yet"}

Your job:
- Give concrete, actionable next steps based ONLY on the data above.
- Be specific: reference the student's weakest skill, the next roadmap step, or the next practice problem to solve.
- Keep replies under 150 words, friendly, and structured with short paragraphs or bullets.
- If the student hasn't taken the assessment or chosen a career, tell them to do that first.
- Never invent scores, problems, or links that aren't in the data.`;
}

function fallbackReply(ctx: StudentContext, userMessage: string): string {
  const msg = userMessage.toLowerCase();
  if (!ctx.careerTitle) {
    return `Hi ${ctx.name}! Let's get you started. First, pick a target career from your dashboard — once you choose one, I can build your skill-gap analysis and roadmap. What career are you aiming for?`;
  }
  if (ctx.requiredSkills.length === 0 || Object.keys(ctx.scores).length === 0) {
    return `You've chosen ${ctx.careerTitle} — great choice. The next step is to take your skill assessment so we can find your gaps. Head to the Assessment page and rate your current skills, then I'll suggest exactly what to improve first.`;
  }
  // find weakest skill
  const weakest = [...ctx.requiredSkills].sort(
    (a, b) => (ctx.scores[a.skill] ?? 0) - (ctx.scores[b.skill] ?? 0)
  )[0];
  const nextRoadmap = ctx.roadmap[0];

  if (msg.includes("roadmap") || msg.includes("plan") || msg.includes("next")) {
    const lines: string[] = [];
    if (nextRoadmap) {
      lines.push(
        `Here's your next milestone: **${nextRoadmap.title}** — ${nextRoadmap.description}.`
      );
    }
    if (weakest) {
      lines.push(
        `Your weakest area right now is **${weakest.skill}** (current ${Math.round(
          ctx.scores[weakest.skill] ?? 0
        )}/${weakest.target}). Solve a few practice problems on the Problems page targeting that skill.`
      );
    }
    lines.push(
      `Progress so far: ${ctx.solvedProblems}/${ctx.totalProblems} problems solved. Keep going!`
    );
    return lines.join("\n\n");
  }
  if (weakest) {
    return `Based on your assessment, focus on **${weakest.skill}** — you're at ${Math.round(
      ctx.scores[weakest.skill] ?? 0
    )} of a ${weakest.target} target. ${
      nextRoadmap
        ? `Your next milestone is "${nextRoadmap.title}".`
        : "Open the Problems page to find practice problems for this skill."
      } You've solved ${ctx.solvedProblems}/${ctx.totalProblems} problems so far — keep the momentum going!`;
  }
  return `You're on the ${ctx.careerTitle} track. Take the skill assessment next so I can pinpoint exactly what to work on.`;
}

export async function getAssistantReply(
  ctx: StudentContext,
  history: ChatTurn[],
  userMessage: string
): Promise<{ reply: string; usedAI: boolean }> {
  const hasKey = !!process.env.ZAI_API_KEY;
  if (!hasKey) {
    return { reply: fallbackReply(ctx, userMessage), usedAI: false };
  }

  try {
    const zai = await ZAI.create();
    const messages: { role: "assistant" | "user"; content: string }[] = [
      { role: "assistant", content: buildSystemPrompt(ctx) },
      ...history.slice(-8).map((h) => ({
        role: h.role,
        content: h.content,
      })),
      { role: "user", content: userMessage },
    ];

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });
    const reply = completion.choices?.[0]?.message?.content?.trim();
    if (!reply) throw new Error("Empty AI response");
    return { reply, usedAI: true };
  } catch (err) {
    console.error("[ai] LLM call failed, using fallback:", err);
    return { reply: fallbackReply(ctx, userMessage), usedAI: false };
  }
}
