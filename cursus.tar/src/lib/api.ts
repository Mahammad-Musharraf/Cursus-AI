import { NextResponse } from "next/server";
import type { ZodSchema, ZodError } from "zod";

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status });
}

export function errorResponse(
  message: string,
  status = 400,
  extra?: Record<string, unknown>
) {
  return NextResponse.json({ error: message, ...extra }, { status });
}

export function unauthorized() {
  return errorResponse("You must be signed in.", 401);
}

export function forbidden() {
  return errorResponse("You don't have access to this resource.", 403);
}

export function notFound(message = "Not found.") {
  return errorResponse(message, 404);
}

export async function parseBody<T>(
  schema: ZodSchema<T>,
  req: Request
): Promise<{ ok: true; data: T } | { ok: false; error: ZodError }> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const res = schema.safeParse(body);
  if (res.success) return { ok: true, data: res.data };
  return { ok: false, error: res.error };
}

export function zodErrors(err: ZodError) {
  return err.flatten().fieldErrors;
}

// Standard fetch wrapper for client components.
export async function api<T = unknown>(
  url: string,
  options?: RequestInit
): Promise<{ data?: T; error?: string; status: number }> {
  try {
    const res = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    const text = await res.text();
    const data = text ? JSON.parse(text) : null;
    if (!res.ok) {
      return {
        error: data?.error || `Request failed (${res.status})`,
        status: res.status,
      };
    }
    return { data: data as T, status: res.status };
  } catch (e) {
    return {
      error: e instanceof Error ? e.message : "Network error",
      status: 0,
    };
  }
}
