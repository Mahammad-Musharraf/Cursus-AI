// Generate a unique, human-readable college join code from a name.
export function generateCollegeCode(name: string): string {
  const base = (name || "COL")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 3)
    .padEnd(3, "X");
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${base}-${rand}`;
}
