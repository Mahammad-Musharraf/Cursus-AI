// AI onboarding engine for Cursus AI.
// Asks 10–12 adaptive questions, then ranks the 14 software career paths by
// match percentage using a transparent scoring model. Falls back to LLM-based
// reasoning summaries when ZAI_API_KEY is set; otherwise uses rule-based text.

import { db } from "@/lib/db";
import { CAREERS, type CareerDef, type CareerTag } from "@/lib/careers-data";

export type OnboardingQuestion = {
  id: string;
  prompt: string;
  helpText?: string;
  // MCQ options. Each option contributes weighted tag scores.
  options: { label: string; scores: Partial<Record<CareerTag, number>> }[];
};

// 12 adaptive questions covering interests, subjects, comfort, projects,
// work style, goals, industries, and satisfaction.
export const ONBOARDING_QUESTIONS: OnboardingQuestion[] = [
  {
    id: "interest",
    prompt: "Which of these activities excites you the most?",
    helpText: "Pick the one that feels most like play, not work.",
    options: [
      { label: "Building apps & websites", scores: { frontend: 3, fullstack: 2, coding: 2 } },
      { label: "Finding patterns in data", scores: { data: 3, ml: 2, math: 2, research: 2 } },
      { label: "Designing visuals & flows", scores: { design: 3, creative: 2, product: 1 } },
      { label: "Securing & breaking systems", scores: { security: 3, systems: 2 } },
      { label: "Working with hardware & devices", scores: { hardware: 3, systems: 1, coding: 1 } },
    ],
  },
  {
    id: "fav_subject",
    prompt: "Which was your favourite subject in college/school?",
    options: [
      { label: "Mathematics", scores: { math: 3, ml: 1, research: 1 } },
      { label: "Computer Science / Programming", scores: { coding: 3, backend: 1, fullstack: 1 } },
      { label: "Electronics / Circuits", scores: { hardware: 3, systems: 1 } },
      { label: "Statistics / Probability", scores: { data: 3, ml: 2, math: 1 } },
      { label: "Design / Arts", scores: { design: 3, creative: 2 } },
    ],
  },
  {
    id: "math_comfort",
    prompt: "How comfortable are you with math (algebra, calculus, linear algebra)?",
    helpText: "Be honest — this helps us recommend data & ML paths accurately.",
    options: [
      { label: "Love it, it's my strong suit", scores: { math: 3, ml: 2, research: 2, data: 1 } },
      { label: "Comfortable with practice", scores: { math: 2, ml: 1, data: 1 } },
      { label: "I get by, prefer applied stuff", scores: { coding: 2, frontend: 1, fullstack: 1 } },
      { label: "Not my thing", scores: { design: 2, frontend: 2, creative: 1, qa: 1 } },
    ],
  },
  {
    id: "coding_comfort",
    prompt: "How would you rate your coding comfort today?",
    options: [
      { label: "I can build full apps on my own", scores: { fullstack: 3, backend: 2, frontend: 1, coding: 2 } },
      { label: "I can solve DSA problems comfortably", scores: { coding: 3, backend: 2, systems: 1 } },
      { label: "I've done small scripts / projects", scores: { coding: 2, data: 1, qa: 1 } },
      { label: "Just starting out", scores: { design: 2, creative: 1 } },
    ],
  },
  {
    id: "projects",
    prompt: "What kind of projects have you built (or want to build)?",
    options: [
      { label: "Web apps / websites", scores: { frontend: 3, fullstack: 2, backend: 1 } },
      { label: "Data analysis / ML notebooks", scores: { data: 3, ml: 2, research: 1 } },
      { label: "Mobile apps", scores: { mobile: 3, frontend: 1, coding: 1 } },
      { label: "IoT / hardware gadgets", scores: { hardware: 3, systems: 1 } },
      { label: "Design mockups / prototypes", scores: { design: 3, creative: 2, product: 1 } },
      { label: "None yet, but eager to start", scores: {} },
    ],
  },
  {
    id: "work_style",
    prompt: "How do you like to work?",
    options: [
      { label: "Build visible things people use", scores: { frontend: 3, fullstack: 2, mobile: 1, product: 1 } },
      { label: "Solve deep, invisible problems", scores: { backend: 2, systems: 2, ml: 2, research: 1 } },
      { label: "Analyse & find insights", scores: { data: 3, ml: 1, math: 1, research: 1 } },
      { label: "Protect & harden systems", scores: { security: 3, systems: 1 } },
      { label: "Design how things should look & feel", scores: { design: 3, creative: 2, product: 1 } },
    ],
  },
  {
    id: "goal",
    prompt: "What matters most to you in your first role?",
    options: [
      { label: "High pay & growth", scores: { ml: 2, fullstack: 2, backend: 2, data: 1 } },
      { label: "Creative, visual work", scores: { design: 3, frontend: 2, creative: 1 } },
      { label: "Impact & ownership", scores: { fullstack: 3, product: 1, backend: 1 } },
      { label: "Research & innovation", scores: { research: 3, ml: 2, data: 1 } },
      { label: "Stability & reliability work", scores: { qa: 3, cloud: 2, systems: 1 } },
    ],
  },
  {
    id: "industry",
    prompt: "Which industries excite you? (pick the strongest)",
    options: [
      { label: "Tech / SaaS products", scores: { fullstack: 2, frontend: 1, backend: 1 } },
      { label: "AI / Research labs", scores: { ml: 3, research: 2, data: 1 } },
      { label: "Finance / Fintech", scores: { data: 2, backend: 2, security: 1 } },
      { label: "Healthcare / Biotech", scores: { data: 2, ml: 1, research: 1 } },
      { label: "Cloud / Infra", scores: { cloud: 3, systems: 1, backend: 1 } },
      { label: "Hardware / Automotive", scores: { hardware: 3, systems: 1 } },
    ],
  },
  {
    id: "team_role",
    prompt: "In a team project, you're usually the one who…",
    options: [
      { label: "Builds the product/features", scores: { fullstack: 2, frontend: 2, backend: 1, coding: 1 } },
      { label: "Designs the experience", scores: { design: 3, creative: 1, product: 1 } },
      { label: "Sets up infra & deployment", scores: { cloud: 3, systems: 1, backend: 1 } },
      { label: "Analyses data & finds insights", scores: { data: 3, ml: 1, math: 1 } },
      { label: "Tests & ensures quality", scores: { qa: 3, systems: 1 } },
    ],
  },
  {
    id: "learning_pref",
    prompt: "How do you learn best?",
    options: [
      { label: "Building real projects", scores: { fullstack: 2, frontend: 2, backend: 1, coding: 1 } },
      { label: "Reading papers & theory", scores: { research: 3, ml: 1, math: 1 } },
      { label: "Tinkering with tools/systems", scores: { systems: 2, cloud: 1, hardware: 1, security: 1 } },
      { label: "Designing & sketching", scores: { design: 3, creative: 1 } },
    ],
  },
  {
    id: "satisfaction",
    prompt: "How satisfied do you feel with your current career direction?",
    helpText: "There's no wrong answer — this helps us tailor your roadmap.",
    options: [
      { label: "Very clear, just need a plan", scores: {} },
      { label: "Somewhat clear, exploring options", scores: {} },
      { label: "Confused, need guidance", scores: {} },
      { label: "Want to switch direction", scores: {} },
    ],
  },
  {
    id: "time_commit",
    prompt: "How many hours/week can you commit to upskilling?",
    options: [
      { label: "10+ hours (all in)", scores: { ml: 1, fullstack: 1, backend: 1 } },
      { label: "5–10 hours", scores: { frontend: 1, data: 1, design: 1 } },
      { label: "2–5 hours", scores: { qa: 1, design: 1 } },
      { label: "Flexible / weekends", scores: {} },
    ],
  },
];

export type Answer = {
  questionId: string;
  question: string;
  answer: string;
  optionIndex: number;
};

export type CareerRecommendation = {
  careerId: string;
  slug: string;
  title: string;
  category: string;
  matchPct: number;
  reasons: string[];
};

// Map answers -> cumulative tag scores -> per-career match %.
export function recommendCareers(answers: Answer[]): CareerRecommendation[] {
  // 1. Tally tag scores from answers
  const tagScores = new Map<CareerTag, number>();
  for (const a of answers) {
    const q = ONBOARDING_QUESTIONS.find((x) => x.id === a.questionId);
    if (!q) continue;
    const opt = q.options[a.optionIndex];
    if (!opt) continue;
    for (const [tag, val] of Object.entries(opt.scores)) {
      const t = tag as CareerTag;
      tagScores.set(t, (tagScores.get(t) ?? 0) + (val as number));
    }
  }

  // 2. Score each career by overlap with the user's tag profile.
  const scored = CAREERS.map((career) => {
    const reasons: string[] = [];
    let raw = 0;
    let maxPossible = 0;
    for (const tag of career.tags) {
      const userScore = tagScores.get(tag) ?? 0;
      // weight: each tag contributes up to a capped amount
      const contribution = Math.min(6, userScore);
      raw += contribution;
      maxPossible += 6;
      if (userScore >= 3) {
        reasons.push(
          `You showed strong interest in ${humanTag(tag)} — central to ${career.title}.`
        );
      }
    }
    // Normalise to 0–100. Add a baseline so top picks feel meaningful.
    const base = maxPossible > 0 ? raw / maxPossible : 0;
    // Map [0,1] -> [45, 98] so recommendations feel actionable but honest.
    let matchPct = Math.round(45 + base * 53);

    // Tag-specific reason boosts
    if (career.slug === "data-scientist" && (tagScores.get("math") ?? 0) >= 3) {
      reasons.push("Your maths comfort maps well to statistics-heavy work.");
    }
    if (career.slug === "frontend-developer" && (tagScores.get("design") ?? 0) >= 3) {
      reasons.push("Your design interest pairs naturally with frontend craft.");
    }
    if (career.slug === "devops-cloud-engineer" && (tagScores.get("systems") ?? 0) >= 3) {
      reasons.push("You enjoy systems thinking — the heart of DevOps.");
    }
    if (reasons.length === 0) {
      reasons.push("A solid all-round fit based on your interests.");
    }
    // cap
    matchPct = Math.min(98, Math.max(40, matchPct));
    return {
      careerId: career.slug, // we'll resolve the real id after DB lookup
      slug: career.slug,
      title: career.title,
      category: career.category,
      matchPct,
      reasons: reasons.slice(0, 3),
    } as CareerRecommendation;
  });

  // 3. Sort by match desc, take top 5 (we'll return top 5 but UI shows top 3).
  return scored.sort((a, b) => b.matchPct - a.matchPct).slice(0, 5);
}

function humanTag(t: CareerTag): string {
  const map: Record<CareerTag, string> = {
    coding: "coding",
    math: "mathematics",
    design: "design",
    data: "working with data",
    systems: "systems thinking",
    security: "security",
    frontend: "frontend development",
    backend: "backend development",
    fullstack: "full-stack development",
    ml: "AI & machine learning",
    cloud: "cloud & infrastructure",
    mobile: "mobile apps",
    hardware: "hardware & devices",
    qa: "quality & testing",
    research: "research",
    product: "product thinking",
    creative: "creative work",
  };
  return map[t];
}

// Persist onboarding result + (optionally) set the chosen career on the user.
export async function saveOnboardingResult(
  userId: string,
  answers: Answer[],
  recommendations: CareerRecommendation[],
  chosenCareerSlug?: string
) {
  // Resolve career ids from slugs
  const careers = await db.career.findMany({
    where: { slug: { in: CAREERS.map((c) => c.slug) } },
    select: { id: true, slug: true, title: true, category: true },
  });
  const slugToId = new Map(careers.map((c) => [c.slug, c.id]));

  const recsWithIds = recommendations.map((r) => ({
    ...r,
    careerId: slugToId.get(r.slug) ?? r.slug,
  }));

  let chosenCareerId: string | null = null;
  if (chosenCareerSlug) {
    chosenCareerId = slugToId.get(chosenCareerSlug) ?? null;
  }

  const result = await db.onboardingResult.create({
    data: {
      userId,
      answers: answers as unknown as object,
      recommendations: recsWithIds as unknown as object,
      chosenCareerId,
      confirmed: !!chosenCareerSlug,
    },
  });

  // If a path was chosen, set it on the user + mark stage IN_BTECH.
  if (chosenCareerId) {
    await db.user.update({
      where: { id: userId },
      data: {
        targetCareerId: chosenCareerId,
        stage: "IN_BTECH",
      },
    });
  }

  return { result, chosenCareerId };
}

export async function getLatestOnboarding(userId: string) {
  const latest = await db.onboardingResult.findFirst({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  if (!latest) return null;
  return {
    id: latest.id,
    answers: latest.answers as Answer[],
    recommendations: latest.recommendations as CareerRecommendation[],
    chosenCareerId: latest.chosenCareerId,
    confirmed: latest.confirmed,
    createdAt: latest.createdAt,
  };
}
