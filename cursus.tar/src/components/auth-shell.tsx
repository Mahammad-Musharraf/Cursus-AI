import { Logo } from "@/components/logo";

export function AuthShell({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="grid min-h-svh lg:grid-cols-2">
      {/* Brand panel */}
      <div className="relative hidden flex-col justify-between bg-primary p-10 text-primary-foreground lg:flex">
        <div className="flex items-center gap-2.5">
          <Logo className="[&_span]:text-primary-foreground" />
        </div>
        <div className="max-w-md">
          <h2 className="text-3xl font-semibold leading-tight">
            Forge a clear path from campus to career.
          </h2>
          <p className="mt-3 text-sm text-primary-foreground/80">
            Skill assessments, personalized roadmaps, curated practice problems,
            and an AI mentor — built for engineering students, colleges and
            recruiters.
          </p>
          <ul className="mt-6 space-y-2 text-sm text-primary-foreground/90">
            {[
              "Find your skill gaps in minutes",
              "Get a step-by-step roadmap to your target role",
              "Practice with curated problems from LeetCode, GFG & CodeChef",
              "Talk to an AI mentor that knows your progress",
            ].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <span className="inline-block size-1.5 rounded-full bg-primary-foreground/80" />
                {t}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-primary-foreground/60">
          © {new Date().getFullYear()} Cursus AI
        </p>
      </div>

      {/* Form panel */}
      <div className="flex flex-col">
        <header className="flex h-14 items-center justify-between px-6">
          <Logo className="lg:hidden" />
          <div className="ml-auto" />
        </header>
        <div className="flex flex-1 items-center justify-center px-6 pb-16">
          <div className="w-full max-w-sm">
            <div className="mb-6">
              <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
              <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
            </div>
            {children}
            {footer && <div className="mt-6 text-sm text-muted-foreground">{footer}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
