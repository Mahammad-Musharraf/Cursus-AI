import { Navbar } from "@/components/navbar";
import { RoleSidebar } from "@/components/role-sidebar";
import { Sidebar, SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import type { Role } from "@/lib/constants";

export function AppShell({
  user,
  children,
}: {
  user: { name: string; email: string; role: Role };
  children: React.ReactNode;
}) {
  return (
    <SidebarProvider>
      <Sidebar collapsible="offcanvas" className="bg-sidebar">
        <RoleSidebar role={user.role} />
      </Sidebar>
      <SidebarInset className="flex min-h-svh flex-col">
        <Navbar user={user} />
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  );
}
