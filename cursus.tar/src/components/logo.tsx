import Link from "next/link";
import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm",
        className
      )}
      aria-hidden
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        className="size-5"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M4 18c4-9 12-9 16 0" />
        <path d="M4 18l3-3" />
        <circle cx="4" cy="18" r="1.4" fill="currentColor" stroke="none" />
        <circle cx="12" cy="9.5" r="1.4" fill="currentColor" stroke="none" />
        <circle cx="20" cy="18" r="1.4" fill="currentColor" stroke="none" />
      </svg>
    </span>
  );
}

export function Logo({
  className,
  href = "/",
  showText = true,
}: {
  className?: string;
  href?: string;
  showText?: boolean;
}) {
  return (
    <Link
      href={href}
      className={cn("inline-flex items-center gap-2.5", className)}
    >
      <LogoMark />
      {showText && (
        <span className="text-lg font-semibold tracking-tight text-foreground">
          Cursus<span className="text-primary"> AI</span>
        </span>
      )}
    </Link>
  );
}
