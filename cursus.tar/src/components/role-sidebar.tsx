"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  ClipboardCheck,
  Target,
  Map,
  Code2,
  Sparkles,
  Users,
  Download,
  Bookmark,
  Building2,
  Briefcase,
  GraduationCap,
  Award,
  ShieldCheck,
  FileText,
  BriefcaseBusiness,
  KanbanSquare,
  type LucideIcon,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/utils";
import type { Role } from "@/lib/constants";

type NavItem = { href: string; label: string; icon: LucideIcon };

const NAV: Record<Role, NavItem[]> = {
  STUDENT: [
    { href: "/dashboard/student", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/student/assessment", label: "Assessment", icon: ClipboardCheck },
    { href: "/dashboard/student/skill-gap", label: "Skill Gap", icon: Target },
    { href: "/dashboard/student/roadmap", label: "Roadmap", icon: Map },
    { href: "/dashboard/student/problems", label: "Practice", icon: Code2 },
    { href: "/dashboard/student/jobs", label: "Jobs", icon: BriefcaseBusiness },
    { href: "/dashboard/student/exams", label: "Exams", icon: FileText },
    { href: "/dashboard/student/ai-chat", label: "AI Mentor", icon: Sparkles },
    { href: "/dashboard/student/certificates", label: "Certificates", icon: Award },
  ],
  COLLEGE: [
    { href: "/dashboard/college", label: "Dashboard", icon: LayoutDashboard },
    { href: "/dashboard/college/students", label: "Students", icon: Users },
    { href: "/dashboard/college/certificates", label: "Certificates", icon: ShieldCheck },
    { href: "/dashboard/college/export", label: "Export CSV", icon: Download },
  ],
  RECRUITER: [
    { href: "/dashboard/recruiter", label: "Candidates", icon: Users },
    { href: "/dashboard/recruiter/jobs", label: "Jobs", icon: BriefcaseBusiness },
    { href: "/dashboard/recruiter/exams", label: "Exams", icon: FileText },
    { href: "/dashboard/recruiter/pipeline", label: "Pipeline", icon: KanbanSquare },
    { href: "/dashboard/recruiter/shortlist", label: "Shortlist", icon: Bookmark },
  ],
};

const ROLE_ICON: Record<Role, LucideIcon> = {
  STUDENT: GraduationCap,
  COLLEGE: Building2,
  RECRUITER: Briefcase,
};

export function RoleSidebar({ role }: { role: Role }) {
  const pathname = usePathname();
  const items = NAV[role];
  const RoleIcon = ROLE_ICON[role];

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center border-b border-sidebar-border px-4">
        <Logo />
      </div>
      <div className="flex items-center gap-2 px-4 py-3">
        <span className="inline-flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
          <RoleIcon className="size-4" />
        </span>
        <div className="leading-tight">
          <p className="text-xs text-muted-foreground">Signed in as</p>
          <p className="text-sm font-medium capitalize">
            {role === "COLLEGE" ? "College T&P" : role.toLowerCase()}
          </p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 px-3 py-2">
        {items.map((item) => {
          const active =
            item.href === `/dashboard/${role.toLowerCase()}`
              ? pathname === item.href
              : pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-sidebar-border p-4 text-xs text-muted-foreground">
        <p className="font-medium text-foreground">Cursus AI</p>
        <p>Forge your career path.</p>
      </div>
    </div>
  );
}
