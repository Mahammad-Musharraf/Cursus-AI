import { withAuth } from "next-auth/middleware";

// Stable fallback secret (mirrors src/lib/auth.ts) so the middleware can
// decode the JWT even if NEXTAUTH_SECRET env var is missing in dev.
const DEV_FALLBACK_SECRET =
  "cursus-ai-dev-fallback-secret-do-not-use-in-prod-9f3k2l5m8n1q7r4t6w0y";

// Role-aware middleware. Protects /dashboard and /onboarding.
// - Unauthenticated users are sent to /login.
// - Authenticated users hitting a route not meant for their role are bounced
//   to their own dashboard, avoiding redirect loops.
export default withAuth({
  pages: { signIn: "/login" },
  secret:
    (process.env.NEXTAUTH_SECRET && process.env.NEXTAUTH_SECRET.length > 10
      ? process.env.NEXTAUTH_SECRET
      : DEV_FALLBACK_SECRET),
  callbacks: {
    authorized: ({ token, req }) => {
      const path = req.nextUrl.pathname;
      const role = (token?.role as string) || null;

      // Not signed in -> NextAuth will redirect to /login (authorized=false).
      if (!token) return false;

      // Onboarding is only for students who haven't completed it.
      // (The page itself does the granular redirects; just allow students in.)
      if (path.startsWith("/onboarding")) {
        return role === "STUDENT";
      }

      // /dashboard/<role>/* must match the user's role.
      const dashMatch = path.match(/^\/dashboard\/([a-z]+)/);
      if (dashMatch) {
        const routeRole = dashMatch[1].toUpperCase();
        // /dashboard (index) is allowed for all roles; it redirects by role.
        if (routeRole === "") return true;
        return role === routeRole;
      }

      // Fallback: allow.
      return true;
    },
    // When authorized returns false for an authenticated user (role mismatch),
    // send them to their own dashboard instead of /login.
    async redirect({ url, baseUrl, token }) {
      const role = (token?.role as string) || null;
      // If the user IS authenticated but was bounced (mismatch), go to their home.
      if (token) {
        if (role === "STUDENT") return `${baseUrl}/dashboard/student`;
        if (role === "COLLEGE") return `${baseUrl}/dashboard/college`;
        if (role === "RECRUITER") return `${baseUrl}/dashboard/recruiter`;
        return `${baseUrl}/dashboard`;
      }
      // Not authenticated: use the original url (NextAuth sends to /login).
      return url.startsWith(baseUrl) ? url : baseUrl;
    },
  },
});

export const config = {
  // Protect all dashboard & onboarding routes. Everything else is public.
  matcher: ["/dashboard/:path*", "/dashboard", "/onboarding/:path*"],
};
