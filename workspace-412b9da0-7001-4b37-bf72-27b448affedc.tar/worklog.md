# Cursus AI — Build Worklog

Shared worklog for all agents working on Cursus AI.
Append new sections (separated by `---`) — do NOT overwrite.

---
Task ID: 0
Agent: orchestrator (main)
Task: Initialize project plan and worklog for Cursus AI

Work Log:
- Reviewed existing Next.js 16 scaffold (Tailwind v4, shadcn/ui, Prisma sqlite, NextAuth available, z-ai-web-dev-sdk installed).
- Read LLM skill docs: use `import ZAI from 'z-ai-web-dev-sdk'` server-side; `ZAI.create()` then `zai.chat.completions.create({ messages, thinking:{type:'disabled'} })`.
- Decided architecture: NextAuth credentials (email/password) with bcrypt, 3 roles (STUDENT/COLLEGE/RECRUITER), role-based dashboard routes under /dashboard/<role>.
- DB: schema written postgres-portable; provider set to `sqlite` for the local/sandbox dev DB (runs + testable now); README documents switching provider to `postgresql` + Neon/Supabase DATABASE_URL for Vercel. No sqlite-only features used (String-based enums, Json for complex fields) so the switch is a one-line provider change + migrations.
- Design: Inter font, white/soft-neutral bg, single deep-blue accent (`--primary`), sticky footer, top navbar + role sidebar.

Stage Summary:
- Foundation plan locked. Beginning Task 1 (design system + schema + lib).

---
Task ID: 1-6
Agent: orchestrator (main)
Task: Foundation, auth, shared UI, landing, onboarding, all API routes, seed

Work Log:
- Design system: globals.css set to Inter font + single deep-blue accent (--primary oklch(0.45 0.18 264)); layout.tsx uses Inter; ThemeProvider (light/dark) + SessionProvider added.
- Prisma schema (postgres-portable, sqlite for dev) pushed; migrations/0001_init/migration.sql generated via `prisma migrate diff` for Vercel deploy.
- NextAuth credentials (email/password + bcrypt) at /api/auth/[...nextauth]; signup at /api/auth/signup (zod-validated, role-aware, generates college codes). middleware protects /dashboard and /onboarding.
- Shared UI: Logo, PublicHeader, Navbar (with user menu + theme toggle + SidebarTrigger), RoleSidebar (role-specific nav), AppShell (SidebarProvider + Sidebar + SidebarInset), PageHeader, EmptyState/LoadingState/ErrorState, StatCard + PrimaryAction, SiteFooter (sticky).
- Landing page (/) with hero, how-it-works, roles, features, CTA, sticky footer.
- Auth pages /login + /signup (branded AuthShell). /onboarding (server gate + client 2-step flow: stage → career). /dashboard redirect index.
- Dashboard layouts: /dashboard/layout.tsx (AppShell), per-role layouts gate role + student-onboarding redirect.
- API routes (all auth-protected + zod-validated, read/write real DB):
  - GET /api/careers?stage= ; POST /api/onboarding
  - GET/POST /api/assessment ; GET /api/student/summary ; GET /api/problems ; POST /api/progress
  - GET/POST /api/ai-chat (server-side z-ai-web-dev-sdk with rule-based fallback when ZAI_API_KEY unset)
  - GET /api/college/dashboard ; GET /api/college/students ; GET /api/college/export (CSV)
  - GET /api/recruiter/candidates (filter/rank) ; GET/POST/DELETE /api/recruiter/shortlist
- Shared lib: constants (roles/stages/platforms/difficulties/labels/thresholds/scoreBand), api helpers (json/error/parseBody/api client), ai.ts (loadStudentContext + getAssistantReply), student-stats.ts (aggregates + skill-gap), codes.ts.
- Seed script prisma/seed.ts run successfully: 3 demo accounts + 6 careers + ~28 problems + 6 students (with assessments/progress) + 2 demo shortlists.
- Verified: /login /signup 200, /onboarding 307 (redirect, no session), all protected APIs 401, no compile errors in dev.log.

Stage Summary:
- Foundation + all API routes + seed data are complete and compiling cleanly.
- Demo logins (password password123): student@cursus.ai, college@cursus.ai, recruiter@cursus.ai.
- Next: dispatch 3 parallel subagents (7-a student UI, 7-b college UI, 7-c recruiter UI) to build dashboard pages that consume the existing API routes + shared components per AGENT_CONTRACT.md.

---
Task ID: 7-b
Agent: college-ui-builder
Task: Build the College T&P dashboard UI (dashboard overview, detailed students table, CSV export page, college profile/settings) for Cursus AI.

Work Log:
- Read AGENT_CONTRACT.md + worklog.md; reused shared components (PageHeader, states, StatCard, shadcn ui/*, api, constants) and existing college API routes — did NOT touch anything outside src/app/dashboard/college/.
- Created src/app/dashboard/college/_components/ with three small client helpers: status-badge.tsx (color-coded status badge), readiness-ring.tsx (circular SVG progress ring with explicit hex colors), skill-bar.tsx (compact current-vs-target skill bar with target marker).
- page.tsx (dashboard): GET /api/college/dashboard. Empty-state branch (batch.total===0) shows college join code prominently + "Copy college code" primary button + toast. Hero card with ReadinessRing + summary line "X of Y placement-ready". Stat cards row (Total, Ready, On-track, At-risk). Recharts horizontal BarChart heatmap with per-Cell band coloring (red<40, amber 40-69, green>=70) + inline EmptyState. At-risk list inside max-h-96 overflow-y-auto scrollbar-thin with positive EmptyState when empty. Primary: "Export CSV" (window.location.href). Secondary: "View all students" link. Loading + Error states wired.
- students/page.tsx: GET /api/college/students. shadcn Table (overflow-x-auto) with columns Name(+email), Career, Stage, Assessment Yes/No badge, Avg, Readiness %, Status badge, Problems solved (/total). Expandable rows on click → inline per-skill scores (current/target/gap) via SkillBar in 2-col grid; used keyed <Fragment> to avoid React key warnings. Empty state. Primary "Export CSV". Secondary "Back to dashboard". Loading + Error states.
- export/page.tsx: GET /api/college/students for preview count ("N students will be exported"). 2-col grid of included fields with check icons. Big size="lg" primary "Download CSV" → window.location.href = "/api/college/export" + filename hint. Empty state if batch empty. Loading + Error states.
- settings/page.tsx: useSession() for name/email + GET /api/college/dashboard for collegeName/collegeCode. Read-only account card (Name, Email, College name) + college code card with dashed primary-tinted box + big mono code + "Copy code" primary button + toast. Loading + Error states.
- Verified: bunx eslint on src/app/dashboard/college/ → 0 errors. bunx tsc --noEmit caught an import-path bug in page.tsx (`../_components` instead of `./_components`, since page.tsx lives directly in college/); fixed and re-ran → clean. dev.log shows no compile errors.
- The two remaining project-wide eslint errors are in OTHER agents' files (src/app/dashboard/recruiter/page.tsx, src/app/onboarding/onboarding-client.tsx) — out of scope for 7-b.

Stage Summary:
- Delivered: src/app/dashboard/college/page.tsx, students/page.tsx, export/page.tsx, settings/page.tsx + _components/{status-badge,readiness-ring,skill-bar}.tsx.
- All pages "use client", single deep-blue accent, semantic status colors, responsive, with Loading/Error/Empty states; every primary action hits a real API (dashboard, students, export via window.location.href).
- ESLint + TypeScript clean for the college scope.

---
Task ID: 7-c
Agent: recruiter-ui
Task: Build Recruiter dashboard UI (candidates filter/rank/shortlist, shortlist, settings)

Work Log:
- Read AGENT_CONTRACT.md + worklog.md to confirm shared components, API contract, design rules.
- Reused existing shared components: PageHeader, EmptyState/LoadingState/ErrorState, full shadcn/ui set (Card, Button, Badge, Select, Input, Progress, Separator, Avatar, Tooltip, Dialog, Textarea), api helper, STAGE_LABELS, sonner toast.
- Created src/app/dashboard/recruiter/shared.tsx with shared client helpers + types:
  - Candidate / ShortlistedCandidate / CandidateStatus / CandidateSkill types (match API contract exactly).
  - StatusBadge: ready=green, on-track=primary blue, at-risk=amber, no-assessment=gray.
  - SkillBars: top-N skills with current/target progress bars (uses shadcn Progress).
  - MetricBlock: small label/value/hint block.
  - initialsOf + formatDate helpers.
- src/app/dashboard/recruiter/page.tsx (Candidates):
  - "use client" page with PageHeader + "View shortlist" primary button (links to shortlist).
  - Filter bar Card: text search (q) with 300ms debounce, min-avg Select (0/40/60/70), stage Select (All + STAGE_LABELS), sort Select (avg/name/recent). Includes "Clear" ghost button when filters active.
  - Fetches GET /api/recruiter/candidates?<params> on filter change; results sorted server-side by avgCurrent desc by default.
  - Shows result count ("N candidates"); list scrolls with max-h-[32rem] overflow-y-auto scrollbar-thin.
  - Candidate cards: avatar+initials, name, status badge, email, careerTitle • stageLabel, big avg score, readiness % + progress, top 3 skill bars.
  - Shortlist toggle: "Shortlist" primary button (POST /api/recruiter/shortlist { studentId }) when not shortlisted; "Shortlisted ✓" outline button (DELETE ?studentId=) when shortlisted. Optimistic updates + toast + rollback on error.
  - Optional note dialog: ghost StickyNote icon button (only when shortlisted) opens dialog with Textarea (280 char limit). POSTs { studentId, note } (upserts note). Toast on success/error.
  - Empty states: "No candidates yet" (no students at all) vs "No matches for these filters" with "Clear filters" action.
  - Loading state, Error state with "Try again" (uses refreshKey state to refetch without changing filters).
- src/app/dashboard/recruiter/shortlist/page.tsx (Shortlist):
  - Fetches GET /api/recruiter/shortlist; renders grid of cards (md:grid-cols-2).
  - Each card: avatar+initials, name, status badge, email, careerTitle • stageLabel, avg score, readiness % + progress, top 3 skills, note (if any) in a callout, shortlisted date (formatted). "Contact" mailto button + "Remove" outline button (DELETE ?studentId=) with optimistic removal + restore on failure + toast.
  - Empty state: "Your shortlist is empty" with primary "Find candidates" button → /dashboard/recruiter.
  - Primary header button (when non-empty): "Find more candidates" → /dashboard/recruiter.
  - Loading/Error states.
- src/app/dashboard/recruiter/settings/page.tsx (Profile):
  - "use client" page using useSession() from next-auth/react (name + email). Shows "Recruiter" role badge. Company shown as "—" with hint "Not configured".
  - Two cards: Account (avatar, name, email, role badge, grid of fields: Full name / Email / Company / Role) and Permissions (3 permission rows).
  - Disabled "Edit profile" outline button wrapped in Tooltip ("Profile editing isn't available yet."). Wraps button in span with tabIndex so hover events still trigger tooltip on a disabled control.
  - Loading state while session loads.
- Verified: bun run lint on src/app/dashboard/recruiter/ passes with 0 errors (the 2 remaining global lint errors are in src/app/dashboard/student/problems/page.tsx and src/app/onboarding/onboarding-client.tsx — outside my scope).
- Verified: npx tsc --noEmit shows 0 errors in src/app/dashboard/recruiter/*.
- Verified: dev server compiles all three routes cleanly (GET /dashboard/recruiter, /shortlist, /settings all return 307 (auth redirect) with successful compile — no module resolution or TypeScript errors).

Stage Summary:
- Created 4 files (all within src/app/dashboard/recruiter/):
  - shared.tsx — shared client types + StatusBadge, SkillBars, MetricBlock, helpers.
  - page.tsx — Candidates page with debounced filters, ranked candidate cards, shortlist toggle, optional note dialog.
  - shortlist/page.tsx — Shortlisted candidates grid with note + date + remove action.
  - settings/page.tsx — Read-only recruiter profile using useSession().
- All async screens have Loading / Error / Empty states. Single primary button per screen. Responsive (grid collapses, max-h lists scroll). Single deep-blue accent + semantic status colors only.
- All API calls hit real endpoints (GET /api/recruiter/candidates, GET/POST/DELETE /api/recruiter/shortlist). No mock data.

---
Task ID: 7-a
Agent: student-ui
Task: Build all 7 student dashboard pages under src/app/dashboard/student/

Work Log:
- Read AGENT_CONTRACT.md + worklog.md to confirm the existing foundation (auth, layouts, API routes, shared components) and the page-by-page requirements.
- Created `page.tsx` (dashboard overview): greeting from useSession, hero card with target career + readiness ring (inline SVG) + status label, 4 StatCards (avg score, readiness %, skills to improve, problems solved), top-3 skill gaps mini list with progress bars, next milestone from roadmap[0], single primary button (Take/Retake assessment) + outline buttons (Practice, Ask AI mentor). Full loading/empty/error states.
- Created `assessment/page.tsx`: fetches `/api/assessment`, renders a labeled Slider (0–100) per required skill with target marker + live value + colored score; pre-fills from existing scores; "Save assessment" primary button POSTs `/api/assessment`; on success toast + redirect to `/skill-gap`; on 422 displays inline field errors. Shows last-taken date alert. Empty state with CTA to onboarding if no career.
- Created `skill-gap/page.tsx`: fetches `/api/student/summary`; if `!hasAssessment` shows EmptyState with primary "Take assessment" CTA. Else: 3 aggregate StatCards (avg, readiness %, gap count), recharts BarChart (current vs target per skill, green when met), per-skill breakdown list with Progress bar + gap value + scoreBand Badge colored by tone. Outline "Retake assessment" button.
- Created `roadmap/page.tsx`: vertical stepper with numbered circles connected by a line; each step shows title, description, skill chips; steps without skills show "Milestone" badge. Empty states for no career or no roadmap. Primary "Go to practice" button.
- Created `problems/page.tsx`: fetches `/api/problems` with refetch on filter change; progress bar showing solved/total; filters row (skill, difficulty, platform, status Selects) + Clear filters; cards list with title, platform Badge, difficulty Badge (colored green/amber/red), topic, skillSlug chip; "Solve" external link button (primary for first unsolved, outline for others) + "Done" checkbox that POSTs `/api/progress` (optimistic update + revert on failure + toast). List container uses `max-h-[28rem] overflow-y-auto scrollbar-thin`. Empty states for no problems and no-filter-match.
- Created `ai-chat/page.tsx`: fetches `/api/ai-chat`; subtle banner when `!aiEnabled` (guidance mode); message area `h-[60vh] overflow-y-auto scrollbar-thin`; user messages right-aligned primary bubble, assistant left-aligned card bubble, auto-scroll to bottom; suggestion chips above input; Enter to send / Shift+Enter newline; "Thinking…" typing indicator while waiting; POST `/api/ai-chat` with optimistic user message + assistant reply appended on success. Empty state when no messages.
- Created `settings/page.tsx`: read-only profile card using `/api/student/summary` + `useSession()`; rows for Name, Email, Stage (with stage code badge), Target career (with category + avg salary badge); disabled "Edit" button with tooltip "Profile editing coming soon".
- Ran `bun run lint`: fixed `react-hooks/set-state-in-effect` in `problems/page.tsx` by moving setLoading(true)/setError(null) into the filter-change handlers (event-driven) instead of the effect body. After fix, no errors remain in any student page.
- Ran `bunx tsc --noEmit`: fixed one TS error in `skill-gap/page.tsx` (chartData needed the `gap` field to sort by it). After fix, no TS errors in student pages.
- Verified all 7 student routes compile cleanly in dev.log by triggering each via curl (307 unauth redirects as expected; no compile errors).

Stage Summary:
- All 7 student dashboard pages delivered: `page.tsx`, `assessment/page.tsx`, `skill-gap/page.tsx`, `roadmap/page.tsx`, `problems/page.tsx`, `ai-chat/page.tsx`, `settings/page.tsx`.
- Every page is a client component using the shared `PageHeader`, `LoadingState/ErrorState/EmptyState`, `StatCard`, and full shadcn/ui set.
- One obvious `bg-primary` action per screen; semantic green/amber/red only on status badges.
- Real API integrations: `/api/student/summary`, `/api/assessment` (GET+POST), `/api/problems`, `/api/progress`, `/api/ai-chat` (GET+POST).
- `bun run lint` + `bunx tsc --noEmit` clean for all student files. Worklog agent-ctx file written at `/agent-ctx/7-a-student-ui.md`.

---
Task ID: 7-8
Agent: orchestrator (main)
Task: Integrate, verify end-to-end with Agent Browser, write README, finalize

Work Log:
- Dispatched 3 parallel subagents (7-a student UI, 7-b college UI, 7-c recruiter UI); all delivered lint-clean pages.
- Fixed 1 lint error in onboarding-client.tsx (moved synchronous setState out of effect).
- Made seed portable: installed tsx, set db:seed = `tsx prisma/seed.ts` + added prisma.seed config; re-ran successfully.
- Wrote README.md (overview, features, stack, local setup, demo accounts, Vercel/Postgres deploy, structure, env vars, backend rules).
- Agent Browser end-to-end verification (all from real seeded DB, no mock):
  - Landing /: renders, sticky footer, responsive mobile nav. ✓
  - Student login (student@cursus.ai) → /dashboard/student: greeting "Hi, Aarav", career, next milestone, stat cards. ✓
  - Skill-gap page: readiness "On track", avg vs target 77, recharts bar chart (current vs target per skill), per-skill bands (System Design "Needs work"). ✓
  - AI mentor chat: POST /api/ai-chat returns data-aware reply ("next milestone: Master DSA", "weakest: System Design 30/65", "3/3 problems solved"); reply rendered in UI. Guidance-mode banner shown (ZAI_API_KEY unset → rule-based fallback). ✓
  - Problems page: 3/8 (38%) progress, 8 curated problems with platform/difficulty/skill badges, mark-done + Solve links. ✓
  - College login (college@cursus.ai) → /dashboard/college: 6 students, 65% readiness, 2 ready/2 on-track/2 at-risk, skill heatmap (20 skills), at-risk list (Rohan 33avg, Vikram no-assessment). CSV export returns proper CSV with per-skill columns. ✓
  - Recruiter login (recruiter@cursus.ai) → /dashboard/recruiter: 5 candidates ranked by avg (Ananya 76, Priya 74, Sneha 60, Aarav 51, Rohan 33) with top skills + shortlist toggles. Shortlist page shows 2 seeded (Priya, Ananya) with notes. Toggle write-path verified: POST → count 2→3, DELETE → 3→2. ✓
  - Mobile viewport 390×844: condensed nav, footer at bottom. ✓
- `bun run lint` clean. dev.log shows real Prisma queries across all roles; no runtime errors.

Stage Summary:
- Cursus AI is COMPLETE and verified end-to-end. All three roles work against the real database.
- Demo logins (password password123): student@cursus.ai, college@cursus.ai, recruiter@cursus.ai.
- Postgres-for-Vercel path documented (one-line provider switch + migrate deploy + migrations/0001_init included).
- AI mentor uses server-side z-ai-web-dev-sdk (key via ZAI_API_KEY env) with a rule-based fallback so it works without a key.

---
Task ID: 9
Agent: orchestrator (main)
Task: Fix hydration error — <a> cannot be a descendant of <a> (from user screenshots)

Work Log:
- Analyzed 2 user screenshots with VLM (z-ai vision). Both showed the same root cause: a React hydration error "In HTML, <a> cannot be a descendant of <a>".
  - Screenshot 1 pointed to src/components/logo.tsx:42 (the Logo's own <Link>).
  - Screenshot 2 pointed to src/components/auth-shell.tsx:53 where <Logo /> was wrapped inside another <Link href="/" className="lg:hidden">.
- Root cause: the Logo component renders a next/link <Link> (=<a>), and auth-shell.tsx wrapped it in a second <Link> on the mobile header → nested <a> inside <a> → invalid HTML + hydration mismatch.
- Fix: in src/components/auth-shell.tsx removed the wrapping <Link> and rendered <Logo className="lg:hidden" /> directly (the Logo already links to "/"); removed the now-unused `import Link from "next/link"`. Other Logo usages (navbar, public-header, role-sidebar, site-footer, brand panel) were already standalone and needed no change.
- Verified: `bun run lint` clean. Agent Browser loaded /login and /signup — no hydration error overlay, no page errors, forms render correctly.

Stage Summary:
- Hydration error fixed. Both auth pages (login + signup) now render cleanly with no nested-anchor error.

---
Task ID: 10
Agent: orchestrator (main)
Task: Fix sign-in not working (user reported) + NaN salary bug

Work Log:
- Diagnosis: read dev.log → found NextAuth warnings `[NO_SECRET]` and `[NEXTAUTH_URL]`. Checked .env → it had been reset to ONLY `DATABASE_URL` (NEXTAUTH_SECRET, NEXTAUTH_URL, ZAI_API_KEY were gone). Without NEXTAUTH_SECRET, NextAuth can't sign/verify JWTs → authorize() succeeds but the session is immediately invalid → user stays on /login.
- Verified backend was fine: seeded users exist and bcrypt.compare('password123', hash) = true for all 3 demo accounts (student/college/recruiter). So the bug was purely the missing env var, NOT the auth logic.
- Fix 1 (root cause): restored .env with all 4 vars (DATABASE_URL, NEXTAUTH_SECRET, NEXTAUTH_URL, ZAI_API_KEY).
- Fix 2 (dev server): original `bun run dev` (which pipes through `tee`) kept dying when backgrounded. Restarted with double-fork daemon pattern: `( setsid node_modules/.bin/next dev -p 3000 > dev.log 2>&1 & ) &` — server now persists (PID 3352, stable, HTTP 200). No more NextAuth warnings in dev.log.
- Fix 3 (NaN bug): student dashboard + settings declared `avgSalary: number` but seed stores it as a string ("₹8–18 LPA"); `string/100000` → NaN → "₹NaN LPA". Fixed type to `string | null` and render `{data.career.avgSalary}` directly in page.tsx, settings/page.tsx, roadmap/page.tsx, skill-gap/page.tsx. Now shows "Avg. package ₹8–18 LPA".
- Agent Browser end-to-end verification (all 3 roles + signup):
  - Student login (student@cursus.ai) → /dashboard/student, session {role:STUDENT, name:Aarav Sharma}, dashboard renders (66% readiness, no NaN). ✓
  - College login (college@cursus.ai) → /dashboard/college, session {role:COLLEGE, name:Dr. Meera Iyer}, 6 students, 65% readiness. ✓
  - Recruiter login (recruiter@cursus.ai) → /dashboard/recruiter, session {role:RECRUITER, name:Karan Mehta}, 5 candidates. ✓
  - Signup (new student) → POST /api/auth/signup 201 → auto-signin → redirect to /onboarding. ✓
  - Cleaned up the test user afterward.
- `bun run lint` clean. dev.log shows real Prisma queries, no auth warnings, no errors.

Stage Summary:
- Sign-in now works for all 3 roles + signup. Root cause was .env missing NEXTAUTH_SECRET.
- NaN salary bug fixed. Dev server stable.
- Demo logins (password password123): student@cursus.ai, college@cursus.ai, recruiter@cursus.ai.

---
Task ID: 11
Agent: orchestrator (main)
Task: Fix ERR_TOO_MANY_REDIRECTS after signup (user-reported screenshot)

Work Log:
- Analyzed user screenshot (Screenshot 2026-10-24 200040.png) with VLM: showed "This page isn't working — preview-chat...space-z.ai redirected you too many times. ERR_TOO_MANY_REDIRECTS".
- Root cause: middleware.ts used the bare NextAuth middleware (export default from "next-auth/middleware") with matcher ["/dashboard/:path*", "/onboarding/:path*"]. For a freshly signed-up STUDENT (session cookie just set, no stage/career yet), the redirect chain looped:
    signup -> router.push("/dashboard") -> middleware allows (has token) -> /dashboard index sees student without onboarding -> redirect("/onboarding") -> middleware on /onboarding bounces unauthenticated/role-check -> /login -> ... loop.
  The bare middleware had no role-awareness and no custom redirect, so mismatches bounced back to /login repeatedly.
- Fix 1 (middleware.ts): rewrote with `withAuth` + custom `authorized` + custom `redirect` callbacks:
    * authorized: token required; /onboarding only for STUDENT role; /dashboard/<role> must match user's role; /dashboard index allowed for all roles.
    * redirect: if authenticated but bounced (mismatch), send to their own role dashboard instead of /login; only unauthenticated go to /login.
    * Added "/dashboard" (exact) to matcher.
- Fix 2 (signup/page.tsx): after successful signup+signin, route per role — STUDENT -> /onboarding (since they can't enter /dashboard/student until onboarding complete); COLLEGE/RECRUITER -> /dashboard. Added a 200ms delay before router.push to let the just-set session cookie settle (prevents a race where the protected route sees no cookie yet).
- Verified end-to-end with Agent Browser (real DB, fresh users):
    * Student signup (testloop@example.com) -> /onboarding (stage picker) -> complete onboarding -> /dashboard/student (session STUDENT). ✓ No loop.
    * Login as that same new student -> /dashboard/student. ✓
    * Recruiter signup (recruitertest@example.com) -> /dashboard/recruiter (candidates page). ✓ No loop.
    * ERR_TOO_MANY_REDIRECTS check: "no redirect loop" on both paths.
- Cleaned up test users. `bun run lint` clean. Dev server stable (HTTP 200).

Stage Summary:
- ERR_TOO_MANY_REDIRECTS after signup is fixed. Role-aware middleware + per-role signup routing eliminate the loop. All three roles' signup+login flows verified end-to-end.

---
Task ID: 12
Agent: orchestrator (main)
Task: Fix sign-in (hard navigation) + build AI onboarding foundation + new schema/careers/APIs

Work Log:
- Sign-in fix: login + signup now use window.location.assign (hard navigation) after signIn instead of client router.push — eliminates the cookie-settling race that caused ERR_TOO_MANY_REDIRECTS. Verified: student login → /dashboard/student, no loop.
- Schema extended (db:push done): OnboardingResult, Certificate, Notification, ProblemAssignment models; User gained streakCount + lastActiveDate; back-refs added on Career/Problem/User.
- careers-data.ts: all 14 software paths (AI Engineer, ML Engineer, Data Analyst, Data Scientist, Data Engineer, Full-Stack, Frontend, Backend, Mobile App, DevOps/Cloud, Cybersecurity, QA Automation, UI/UX, Embedded/IoT) + 2 foundation careers, each with skills/roadmap/problems/tags.
- onboarding-engine.ts: 12 adaptive questions (interests, fav subject, math/coding comfort, projects, work style, goals, industry, team role, learning pref, satisfaction, time commit) + tag-based scoring → top career recommendations with match % + reasons; saveOnboardingResult persists + sets chosen career on user.
- New API routes (auth-protected, zod-validated): /api/onboarding/questions, /api/onboarding/recommend, /api/onboarding/choose, /api/student/career-match, /api/student/plan (weekly plan + today's problems engine), /api/certificates (GET/POST with file upload + rate limiting), /api/certificates/[id]/review (college approve/reject), /api/notifications (GET + PATCH mark-read).
- weekly-plan.ts: generates a per-week problem plan biased to weakest skills, 2/day across 6 days, with reasons; exposes today's items + progress.
- Seed rewritten to use careers-data.ts: 16 careers + 6 students + sample pending certificate + notification. Re-seeded successfully.
- Onboarding UI rewritten (onboarding-client.tsx): chat-style 12-question conversation → loading → top 3 career recommendations with match % + reasons → confirm path → hard-redirect to dashboard. Supports ?retake=1.
- `bun run lint` clean.

Stage Summary:
- Sign-in bulletproof. AI onboarding conversation built (flagship). 14 careers + new models + APIs in place.
- Next: dispatch parallel subagents for certificates UI (student + college) and dashboard enhancements (career match, skill radar, streak, today's problems, weekly plan, retake button).

---
Task ID: 13-a
Agent: certificates-ui
Task: Build the Certificates UI for Cursus AI — student upload + college T&P approval queue.

Work Log:
- Read worklog.md to confirm the existing foundation (Task 1-12): dashboard chrome, role layouts, shared components (PageHeader, EmptyState/LoadingState/ErrorState, full shadcn/ui set, api<T>() helper, sonner toast), and the two certificate API routes (`/api/certificates` GET+POST, `/api/certificates/[id]/review` POST). Read both route files to lock the exact contract (Certificate shape, multipart upload, 8MB+PDF/PNG/JPG/WEBP server rules, 422/429 error responses, college batch scoping via collegeCode).
- Created `src/app/dashboard/student/certificates/page.tsx` (client):
  - PageHeader "Certificates" + description "Upload your certificates for your college to verify."
  - **Upload card** (the single primary action): form with Title, Issuer, IssuedDate (`type=date`, max=today), Credential URL (optional, `type=url`), and File (`type=file` accept=".pdf,.png,.jpg,.jpeg,.webp"). Uses raw `fetch` + `FormData` (NOT the `api()` helper — the helper hardcodes `Content-Type: application/json` which would break the multipart boundary) so the browser sets the correct multipart/form-data Content-Type. Submit button "Upload certificate" (primary, shows spinner + "Uploading…" while submitting, disabled during submit). "Clear" ghost button appears when the form is dirty.
  - Client-side validation mirrors server rules (title ≥2 chars, issuer ≥2 chars, issuedDate YYYY-MM-DD, file required, ≤8MB). All errors surfaced via toast.
  - On success: toast "Certificate uploaded." + prepend the returned cert to the list + reset the form.
  - **List** of certs as cards: title, status badge (PENDING=amber, APPROVED=emerald, REJECTED=red), issuer / issuedDate / fileType+sizeKb meta row, "View file" outline button (opens `filePath` in new tab), "Credential" ghost button (if `credentialUrl` present), reviewer-note callout (if any) with reviewedAt. Container uses `max-h-[28rem] overflow-y-auto scrollbar-thin pr-1`.
  - Empty state: "No certificates yet" with Award icon + description encouraging first upload. Loading state + Error state with "Try again" (calls standalone `load()`).
- Created `src/app/dashboard/college/certificates/page.tsx` (client):
  - PageHeader "Certificate verification" + description "Review certificates submitted by students in your batch." Header right slot shows a "N pending" Badge when pending count > 0.
  - **Filter bar**: shadcn `Select` (All / Pending / Approved / Rejected) defaulting to `PENDING`; shows "Showing X of Y" hint.
  - Filtered list is sorted PENDING-first, then by createdAt desc (so pending items always surface to the top within any filter).
  - **Queue cards**: student avatar (initials), name, email, status badge; cert title; meta row (issuer / issuedDate / fileType+sizeKb); "View file" + "Credential URL" links (open in new tab); reviewer-note callout for already-reviewed certs with reviewedAt; reviewedAt timestamp shown standalone if no note.
  - For PENDING certs: two action buttons — "Approve" (primary) and "Reject" (outline). Both open a small `Dialog` with an optional reviewer-note `Textarea` (280 char limit + counter), then POST `/api/certificates/[id]/review` with `{ status, reviewerNote? }`. Approve button shows spinner while submitting; Reject button is `variant="destructive"` in the dialog footer.
  - On success: toast (different copy for approve vs reject) + update local state by merging the returned certificate into the existing row (preserving the nested `user` object, since the review API only returns the certificate). Dialog auto-closes.
  - Empty state: "No certificates to review 🎉" (when batch has no certs) or "No {filter} certificates" (when filter has no matches, with a "Show all" action). Loading state + Error state with "Try again".
- Lint fix: initial `bun run lint` flagged one `react-hooks/set-state-in-effect` error on the college page (the helper `load()` synchronously called `setLoading(true)` inside the effect body). Refactored BOTH pages to match the existing college dashboard pattern: initial-load effect inlines the `api()` call and only calls setState inside the `.then()` callback (initial state is already `loading:true / error:null`); the standalone `load()` function (which DOES call `setLoading(true)` synchronously) is kept only for the "Try again" event handler.
- Verification:
  - `bun run lint` → 0 errors (clean across the whole project for my files).
  - `bunx tsc --noEmit` → 0 errors in either certificates file (all remaining project-wide TS errors are pre-existing in other files: middleware.ts, notifications/route.ts, weekly-plan.ts, onboarding-engine.ts, student/page.tsx — all outside my scope).
  - All imports resolve (shared components from `@/components/*`, shadcn/ui from `@/components/ui/*`, `api` from `@/lib/api`, `toast` from `sonner`, lucide-react icons).
  - No navbar/sidebar/footer added — pages render inside the existing `<main>` from `dashboard/layout.tsx`; role gating already done by the per-role layouts.

Stage Summary:
- Delivered two new pages under `src/app/dashboard/{student,college}/certificates/page.tsx`. Both are "use client" with single deep-blue primary action, semantic status colors (amber/emerald/red) only on status badges, full Loading/Empty/Error states, responsive (grid collapses, lists scroll with `max-h-* overflow-y-auto scrollbar-thin`).
- Real API integrations: GET/POST `/api/certificates` (FormData upload with raw fetch — NOT the json-content-type `api()` helper, so the multipart boundary is set correctly by the browser), POST `/api/certificates/[id]/review` (with optional reviewer note). Toasts on every success/error; new uploads prepend; reviews update local state in place.
- Files written this task: `src/app/dashboard/student/certificates/page.tsx`, `src/app/dashboard/college/certificates/page.tsx`. Worklog agent-ctx file written at `/agent-ctx/13-a-certificates-ui.md`.
- Did NOT touch any other files (shared components, API routes, lib, other dashboards). Lint + TypeScript clean for the certificates scope.

---
Task ID: 13-b
Agent: student-dashboard-enhancer
Task: Enhance the Student dashboard overview (src/app/dashboard/student/page.tsx) — add career match, skill radar, streak/today's-goal chip, today's problems + weekly plan cards, retake-onboarding button.

Work Log:
- Read worklog.md + existing page.tsx to confirm scope (page.tsx + new _components/ only). Confirmed the three consumed APIs already exist (/api/student/summary, /api/student/career-match, /api/student/plan) and that the dashboard chrome is rendered by the dashboard layout.
- Created 4 helper components under src/app/dashboard/student/_components/:
  * types.ts — shared PlanItem / DayGroup / PlanProgress / PlanData types (single source of truth; avoids TS "two unrelated types" errors between page.tsx and the components).
  * skill-radar.tsx — recharts RadarChart with two series (Current = primary blue filled, Target = muted gray outline). Falls back to EmptyState "Take assessment" CTA when !hasAssessment.
  * career-match-card.tsx — shows top AI recommendation (match % + reasons) and student's chosen career; notes the mismatch if chosen.slug !== top.slug; "Retake career quiz" outline button → /onboarding?retake=1. Falls back to EmptyState "Take the career quiz" when both are empty.
  * today-problems-card.tsx — today's problems with day progress bar, per-item difficulty/platform/topic badges + assignment reason, external "Solve" link (<a target=_blank rel=noopener>), "Open weekly plan" outline button → /dashboard/student/problems. "Rest day ☕" empty state when nothing assigned.
  * weekly-plan-card.tsx — 7-day grid (MON..SUN) with overall weekly progress bar; today's day highlighted (primary tint + "Today" badge); each item shows difficulty dot + truncated title + done check; max-h-96 overflow-y-auto scrollbar-thin.
- Rewrote page.tsx:
  * Parallel fetch via Promise.all on mount: /api/student/summary (critical — bails to ErrorState on failure) + /api/student/career-match + /api/student/plan (both gracefully degrade — their cards show empty fallbacks if they fail).
  * Greeting "Hi, {firstName}" from useSession(); today's-goal chip in PageHeader children (flame icon + "Goal complete! 🎉" / "Rest day ☕" / "N problems left today").
  * Top row (lg:2-col): Hero (career badges, title, summary, salary, readiness ring, primary CTA) | CareerMatchCard.
  * 5 StatCards: Avg score, Readiness, Skills to improve, Problems solved, **Weekly progress** (NEW = plan.progress.pct).
  * 2-col body: Left = TodayProblemsCard + WeeklyPlanCard stacked; Right = SkillRadar + Top skill gaps card stacked.
  * Next milestone full-width card (title + description + skill chips + "View full roadmap").
  * Single primary button per state: hero CTA switches between "Take assessment" (no assessment) ↔ "Solve today's problems" (assessment done, links to /dashboard/student/problems). All other actions (Retake assessment, Ask AI mentor, Retake career quiz, View full skill gap, View full roadmap, Open weekly plan, per-item Solve) are outline.
- Verified: `bun run lint` clean (0 errors). `bunx tsc --noEmit` clean for all files under src/app/dashboard/student/. dev.log shows page compiles cleanly (GET /dashboard/student 200).
- Pre-existing out-of-scope issue noted: /api/student/career-match depends on src/lib/onboarding-engine.ts which imports "@/prisma/careers-data" — the file actually lives at prisma/careers-data.ts (tsconfig maps @/* to ./src/*). When called, the route 500s. Dashboard degrades gracefully (CareerMatchCard shows "Take the career quiz" EmptyState). Out of scope to fix per task constraints.

Stage Summary:
- Delivered: enhanced src/app/dashboard/student/page.tsx + 4 new helper components + 1 shared types file under src/app/dashboard/student/_components/ (career-match-card, skill-radar, today-problems-card, weekly-plan-card, types).
- All 7 spec items implemented: (1) greeting + today's-goal chip; (2) career match card with retake CTA; (3) today's problems card with progress + per-item Solve; (4) weekly plan 7-day grid; (5) recharts skill radar; (6) stat cards row incl. weekly progress; (7) top skill gaps + next milestone preserved.
- One primary button per state. Loading/Error/Empty states wired. Responsive (mobile-first, lg:2-col grids). Single deep-blue accent + semantic status colors only.
- Lint + TypeScript clean for all in-scope files. Worklog agent-ctx file written at /agent-ctx/13-b-student-dashboard-enhancer.md.

---
Task ID: 13-14
Agent: orchestrator (main)
Task: Build + verify AI onboarding, certificates, enhanced dashboard, notifications; fix sign-in

Work Log:
- Sign-in root-cause fix: login + signup now use window.location.assign (hard navigation) after signIn instead of client router.push — eliminates the session-cookie race that caused ERR_TOO_MANY_REDIRECTS. Verified: all 3 demo logins + fresh signup land correctly, no loop.
- AI onboarding conversation (FLAGSHIP): 12 adaptive questions (interests, fav subject, math/coding comfort, projects, work style, goals, industry, team role, learning pref, satisfaction, time commit) → tag-based scoring engine → top 3 career recommendations with match % + reasons, chosen from all 14 software paths (AI Engineer, ML Engineer, Data Analyst, Data Scientist, Data Engineer, Full-Stack, Frontend, Backend, Mobile App, DevOps/Cloud, Cybersecurity, QA Automation, UI/UX, Embedded/IoT). Student confirms one path; retake anytime via ?retake=1. Verified end-to-end: signup → 12 Qs → 98% Full Stack / 86% AI Engineer → choose → dashboard.
- Certificates: student upload (PDF/PNG/JPG/WEBP, max 8MB, title/issuer/date/credentialUrl, rate-limited 10/10min) + college T&P approval queue (approve/reject with reviewer note, notifies student). Both pages verified rendering with seeded pending cert.
- Today's Problems + weekly plan: weekly-plan.ts engine generates a per-week plan (2/day × 6 days) biased to weakest skills, each with a "why assigned" reason. Dashboard shows today's items + 7-day grid + progress bar. External links open LeetCode/GFG/CodeChef in new tab. Verified: week 2026-W43, 4 problems, 3 done, 75%.
- Enhanced student dashboard: career-match card (top AI match + chosen + retake quiz), skill radar (recharts RadarChart current vs target), today's problems card, weekly plan card, 5 stat cards (incl. weekly progress %), today's-goal chip. All from real DB data.
- Notifications: model + API (GET/PATCH mark-read) + NotificationBell in navbar (polls every 30s, unread badge, popover list, mark-read on open). Verified: college sees "Certificate needs review" badge.
- Fixed bugs: careers-data moved to src/lib (was @/prisma/careers-data which didn't resolve); createMany+skipDuplicates not supported on SQLite → replaced with individual creates.
- Sidebar updated: Certificates links added for Student + College.
- `bun run lint` clean. Dev server stable (HTTP 200). All flows verified with Agent Browser.

Stage Summary:
- Sign-in FIXED. AI onboarding + certificates + weekly plan + enhanced dashboard + notifications all DELIVERED and verified end-to-end on real DB.
- Deferred (genuinely large, multi-day features, flagged to user): company jobs/pipeline, online exams with Judge0, interview scheduling, email reminders, full Express-backend monorepo split. The existing recruiter candidates/shortlist + college dashboards/CSV export remain fully working.

---
Task ID: 15-a
Agent: exams-ui
Task: Build the Exams UI for Cursus AI — recruiter creates exams from a question bank, students take them with timer, randomized questions, tab-switch warnings, auto-grading.

Work Log:
- Read worklog.md to confirm foundation (Task 1-14): dashboard chrome via dashboard/layout.tsx, role layouts already gate /dashboard/<role>/*, shared components (PageHeader, EmptyState/LoadingState/ErrorState, full shadcn/ui set incl. button/card/input/label/textarea/badge/select/radio-group/separator/progress/switch/table/alert-dialog, api<T>() helper, sonner toast). Sidebar already has "Exams" link wired for both STUDENT and RECRUITER.
- Read every exam API route to lock the exact contract (GET/POST /api/recruiter/exams, GET/PATCH/DELETE /api/recruiter/exams/[id], GET /api/exams/available, POST /api/exams/[id]/start, POST /api/exams/[id]/submit, GET /api/exams/[id]/result). Verified Prisma schema for Exam/ExamQuestion/ExamAttempt.

Files created (4 pages, no other files touched):

1. src/app/dashboard/recruiter/exams/page.tsx (recruiter list + create):
   - PageHeader "Exams" + description + primary "Create exam" toggle button.
   - Create exam card (toggleable): title, description, durationMin (default 60), questionsToPick (default 10), passScorePct (default 60). Dynamic question builder — each row has type Select (MCQ/SHORT_ANSWER/CODING), prompt Input, difficulty Select (EASY/MEDIUM/HARD), points (1-10), optional skillSlug.
     - MCQ: 4 option Inputs + RadioGroup to pick correct option (index sent as string answer).
     - SHORT_ANSWER: expected-answer Input (sent as answer).
     - CODING: prompt-only; answer defaults to "PENDING_MANUAL_REVIEW".
   - Submit uses RAW fetch (not api()) so the 422 response's `fields` map can be read — the api() helper drops everything except `error`. On 422: field errors surfaced inline + as toasts. On 201: toast + prepend to list + reset form + collapse card.
   - Exam list cards: title + active/inactive badge, optional job badge, description, duration / question bank+picks / attempts / pass % / created date, "View & results" outline link to detail.
   - Loading/Empty/Error states.

2. src/app/dashboard/recruiter/exams/[id]/page.tsx (detail + results):
   - Fetch GET /api/recruiter/exams/[id].
   - Settings summary card with 4 stat blocks + inline active/inactive Switch (optimistic PATCH; rollback+toast on failure).
   - 3 quick-stat cards: Submitted attempts, Passed n/total, Avg score.
   - Question bank view: type icon, difficulty badge (semantic colors), skill slug, points, prompt, answer reveal — MCQ lists options with correct one highlighted (emerald), SHORT_ANSWER shows expected-answer callout (emerald monospace), CODING shows manual-review note.
   - Attempts table: student name/email, score %, pass/fail badge (emerald/red with icon), time spent, submitted at.
   - Delete via AlertDialog confirm → DELETE → redirect to list.
   - Loading/Error/Empty states.

3. src/app/dashboard/student/exams/page.tsx (available + results):
   - Fetch GET /api/exams/available.
   - "Available to you" section: cards with title + job badge, company, description, duration/questions/pass mark. Not-yet-attempted → primary "Start exam" link. In-progress (hasAttempted && !submitted) → amber badge + "Resume" primary button.
   - "My results" section: grid of cards with title, company, big score %, pass/fail badge, progress bar, pass mark, duration.
   - Empty states for both sections.

4. src/app/dashboard/student/exams/[id]/page.tsx — TAKE THE EXAM (critical):
   - On mount POST /api/exams/[id]/start via api(). If 409 → "You've already taken this exam" card + link back. If success → enter taking phase with attemptId + randomized questions + secondsLeft=durationMin*60.
   - Phase state machine: starting → taking → submitting → done | error | alreadyAttempted.
   - Sticky timer header: exam title, pass mark, total questions, tab-switch badge (amber), large mm:ss countdown (amber ≤60s, red at 0).
   - Progress bar: "Question X of N answered" + %.
   - Timer: setInterval in useEffect keyed ONLY on phase.kind (not recreated every tick). At 0: triggers autoSubmitRef.current() and holds at 0 (no re-fire). Cleared on cleanup.
   - Tab-switch: visibilitychange listener (added/removed on mount/unmount of taking phase). When document.hidden → increment counter + toast.warning("Please don't switch tabs — this is recorded.").
   - Leave guard: beforeunload (refresh/close) + document-level capture-phase click listener intercepting same-origin anchor clicks → window.confirm("Your exam progress will be lost."). Active only in taking phase.
   - Question rendering (no crash on missing options): MCQ → RadioGroup (selected index sent as string); SHORT_ANSWER → Input; CODING → monospace Textarea, spellCheck off. Per-question type/difficulty/skill/points badges + "Answered" tick.
   - Submit button (primary) → AlertDialog confirm ("You've only answered X of N…") → doSubmit() sets phase to submitting + POST /api/exams/[id]/submit with {attemptId, responses:[{questionId,answer}], timeSpentSec, tabSwitches}. submitRef guard prevents double-submit.
   - Auto-submit at timer 0: same path + "Time's up — submitting…" banner.
   - Done screen: pass/fail icon, score %, correct count / total, pass mark, time spent. Primary "Back to exams" link.

Verification:
- `bun run lint` → 0 errors (clean across whole project for my files).
- `bunx tsc --noEmit` → 0 errors in my files. (Only remaining project-wide TS error is pre-existing in src/app/api/recruiter/exams/route.ts:81 — Prisma typing quirk on `options: q.options ?? null`; out of scope, lint passes, route works at runtime.)
- All 4 pages compiled successfully via dev server (HEAD requests returned 307 → /login because no session, but compile succeeded in 600-1200ms each, no compile errors in dev.log).
- All imports resolve. No navbar/sidebar/footer added — pages render inside existing <main> from dashboard/layout.tsx. Role gating done by per-role layouts.
- Did NOT touch any other files (shared components, API routes, lib, middleware, other dashboards).

Stage Summary:
- Delivered 4 exam pages: recruiter list+create, recruiter detail+results, student list+results, student take-exam. Lint + TypeScript clean for the exams scope.
- Student take-exam page is robust: phase state machine, sticky timer with auto-submit at 0, tab-switch visibility listener + toast warning + counter, full leave guard (beforeunload + click-intercept for in-app navigation), question-type-aware rendering (MCQ radio / SHORT_ANSWER input / CODING monospace textarea — none crash on missing options), confirm dialog before submit, results screen with pass/fail + score + correct count. submitRef guard prevents double-submit.
- Recruiter create-exam flow uses raw fetch so 422 field errors are surfaced inline + as toasts.
- Files written this task: src/app/dashboard/recruiter/exams/page.tsx, src/app/dashboard/recruiter/exams/[id]/page.tsx, src/app/dashboard/student/exams/page.tsx, src/app/dashboard/student/exams/[id]/page.tsx. Worklog agent-ctx file written at /agent-ctx/15-a-exams-ui.md.
