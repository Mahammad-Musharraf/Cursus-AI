import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

// Stable fallback secret for local development ONLY. This ensures the app
// never crashes with a JWT decryption error even if .env is missing or reset.
// In production you MUST set NEXTAUTH_SECRET (the fallback is ignored when
// NODE_ENV=production).
const DEV_FALLBACK_SECRET =
  "cursus-ai-dev-fallback-secret-do-not-use-in-prod-9f3k2l5m8n1q7r4t6w0y";

function resolveSecret(): string {
  const env = process.env.NEXTAUTH_SECRET;
  if (env && env.length > 10) return env;
  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "NEXTAUTH_SECRET must be set in production. Copy .env.example and set a strong secret."
    );
  }
  // dev fallback so the app keeps working if .env is missing
  return DEV_FALLBACK_SECRET;
}

export const NEXTAUTH_SECRET = resolveSecret();

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  },
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const email = credentials?.email?.trim().toLowerCase();
        const password = credentials?.password ?? "";
        if (!email || !password) return null;

        const user = await db.user.findUnique({ where: { email } });
        if (!user || !user.passwordHash) return null;

        const ok = await bcrypt.compare(password, user.passwordHash);
        if (!ok) return null;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = (user as { role?: string }).role ?? token.role;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as { id?: string }).id = token.id as string;
        (session.user as { role?: string }).role = token.role as string;
      }
      return session;
    },
  },
  secret: NEXTAUTH_SECRET,
};
