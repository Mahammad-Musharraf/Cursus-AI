"use client";

import { useState } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { toast } from "sonner";
import { Loader2, GraduationCap, Building2, Briefcase } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api } from "@/lib/api";
import type { Role } from "@/lib/constants";

type RoleOption = {
  value: Role;
  label: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
};

const ROLES: RoleOption[] = [
  {
    value: "STUDENT",
    label: "Student",
    desc: "Take assessments & get a roadmap",
    icon: GraduationCap,
  },
  {
    value: "COLLEGE",
    label: "College T&P",
    desc: "Track batch readiness",
    icon: Building2,
  },
  {
    value: "RECRUITER",
    label: "Recruiter",
    desc: "Find placement-ready talent",
    icon: Briefcase,
  },
];

export default function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("STUDENT");
  const [collegeName, setCollegeName] = useState("");
  const [collegeCode, setCollegeCode] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [collegeCodeRef, setCollegeCodeRef] = useState("");
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErrors({});
    setLoading(true);

    const { error, status, data } = await api<{
      ok?: boolean;
      error?: string;
      fields?: Record<string, string[]>;
    }>("/api/auth/signup", {
      method: "POST",
      body: JSON.stringify({
        name,
        email,
        password,
        role,
        collegeName: role === "COLLEGE" ? collegeName : undefined,
        collegeCode: role === "COLLEGE" ? collegeCode : undefined,
        companyName: role === "RECRUITER" ? companyName : undefined,
        collegeCodeRef: role === "STUDENT" ? collegeCodeRef : undefined,
      }),
    });

    if (error) {
      setLoading(false);
      if (data?.fields) setErrors(data.fields);
      toast.error(data?.error || error);
      return;
    }

    // Auto sign-in after successful signup
    const res = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });
    if (res?.error) {
      setLoading(false);
      toast.success("Account created. Please sign in.");
      window.location.assign("/login");
      return;
    }
    toast.success("Account created!");
    // HARD navigation so the just-set session cookie is guaranteed to be sent.
    // /dashboard index routes per role: students without onboarding -> /onboarding,
    // college/recruiter -> their dashboard.
    window.location.assign("/dashboard");
  }

  return (
    <AuthShell
      title="Create your account"
      subtitle="Choose how you'll use Cursus AI."
      footer={
        <>
          Already have an account?{" "}
          <Link href="/login" className="font-medium text-primary hover:underline">
            Sign in
          </Link>
        </>
      }
    >
      <form onSubmit={onSubmit} className="space-y-4">
        {/* Role selector */}
        <div className="space-y-2">
          <Label>I am a</Label>
          <div className="grid grid-cols-1 gap-2">
            {ROLES.map((r) => {
              const Icon = r.icon;
              const active = role === r.value;
              return (
                <button
                  key={r.value}
                  type="button"
                  onClick={() => setRole(r.value)}
                  className={`flex items-center gap-3 rounded-lg border p-3 text-left transition-colors ${
                    active
                      ? "border-primary bg-primary/5 ring-1 ring-primary"
                      : "border-border hover:bg-secondary/60"
                  }`}
                >
                  <span
                    className={`inline-flex size-9 items-center justify-center rounded-md ${
                      active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    <Icon className="size-4" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-sm font-medium text-foreground">
                      {r.label}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {r.desc}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="name">Full name</Label>
          <Input
            id="name"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Aarav Sharma"
          />
          {errors.name && <p className="text-xs text-destructive">{errors.name[0]}</p>}
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
          {errors.email && <p className="text-xs text-destructive">{errors.email[0]}</p>}
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 6 characters"
          />
          {errors.password && <p className="text-xs text-destructive">{errors.password[0]}</p>}
        </div>

        {role === "COLLEGE" && (
          <>
            <div className="space-y-1.5">
              <Label htmlFor="collegeName">College name</Label>
              <Input
                id="collegeName"
                required
                value={collegeName}
                onChange={(e) => setCollegeName(e.target.value)}
                placeholder="e.g. National Institute of Technology"
              />
              {errors.collegeName && (
                <p className="text-xs text-destructive">{errors.collegeName[0]}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="collegeCode">
                College join code{" "}
                <span className="text-muted-foreground">(auto-generated if blank)</span>
              </Label>
              <Input
                id="collegeCode"
                value={collegeCode}
                onChange={(e) => setCollegeCode(e.target.value.toUpperCase())}
                placeholder="e.g. NIT-AB12"
              />
            </div>
          </>
        )}

        {role === "RECRUITER" && (
          <div className="space-y-1.5">
            <Label htmlFor="companyName">Company name</Label>
            <Input
              id="companyName"
              required
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="e.g. Turing Labs"
            />
            {errors.companyName && (
              <p className="text-xs text-destructive">{errors.companyName[0]}</p>
            )}
          </div>
        )}

        {role === "STUDENT" && (
          <div className="space-y-1.5">
            <Label htmlFor="collegeCodeRef">
              College join code{" "}
              <span className="text-muted-foreground">(optional)</span>
            </Label>
            <Input
              id="collegeCodeRef"
              value={collegeCodeRef}
              onChange={(e) => setCollegeCodeRef(e.target.value.toUpperCase())}
              placeholder="e.g. NIT-AB12"
            />
            <p className="text-xs text-muted-foreground">
              Enter the code from your college&apos;s T&P cell to join their batch.
            </p>
          </div>
        )}

        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="size-4 animate-spin" />}
          Create account
        </Button>
      </form>
    </AuthShell>
  );
}
