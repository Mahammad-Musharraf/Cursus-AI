"use client";

import * as React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  AlertTriangle,
  ArrowLeft,
  Award,
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  MapPin,
  Package,
  Send,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { api } from "@/lib/api";

import {
  JOB_TYPE_LABELS,
  JobTypeBadge,
  SkillChips,
  StageBadge,
  formatDate,
  parseSkills,
  type ApplicationStage,
  type JobType,
} from "../_shared";

// ---- Types ----

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: JobType;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  companyName: string;
  createdAt: string;
  hasApplied: boolean;
  applicationStage: ApplicationStage | null;
  eligible: boolean;
};

type JobsResponse = { studentAvg: number; jobs: Job[] };

type Application = {
  id: string;
  stage: ApplicationStage;
  coverNote: string | null;
  createdAt: string;
  updatedAt: string;
};

type ApplyResponse = { ok: boolean; application: Application };

export default function StudentJobDetailPage() {
  const params = useParams<{ id: string }>();
  const jobId = params?.id;

  const [job, setJob] = React.useState<Job | null>(null);
  const [studentAvg, setStudentAvg] = React.useState(0);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshKey, setRefreshKey] = React.useState(0);

  // Apply form
  const [coverNote, setCoverNote] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  // Local applied state — flips to true right after a successful apply.
  const [appliedStage, setAppliedStage] = React.useState<ApplicationStage | null>(null);

  React.useEffect(() => {
    if (!jobId) return;
    let cancelled = false;
    api<JobsResponse>("/api/jobs").then((res) => {
      if (cancelled) return;
      setLoading(false);
      if (res.data) {
        const found = res.data.jobs.find((j) => j.id === jobId);
        if (found) {
          setJob(found);
          setStudentAvg(res.data.studentAvg);
          setAppliedStage(found.applicationStage);
          setError(null);
        } else {
          setError("This job is no longer available.");
        }
      } else {
        setError(res.error || "Failed to load this job.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [jobId, refreshKey]);

  function retry() {
    setLoading(true);
    setError(null);
    setRefreshKey((k) => k + 1);
  }

  async function onApply(e: React.FormEvent) {
    e.preventDefault();
    if (submitting || !job) return;
    const note = coverNote.trim();
    setSubmitting(true);

    const res = await api<ApplyResponse>(
      `/api/jobs/${encodeURIComponent(job.id)}/apply`,
      {
        method: "POST",
        body: JSON.stringify(note ? { coverNote: note } : {}),
      }
    );
    setSubmitting(false);

    if (res.data?.ok) {
      toast.success("Application submitted!", {
        description: `You applied to ${job.title}. The recruiter will be in touch.`,
      });
      setAppliedStage(res.data.application.stage);
      setJob((prev) =>
        prev ? { ...prev, hasApplied: true, applicationStage: res.data!.application.stage } : prev
      );
    } else if (res.status === 409) {
      toast.error("You've already applied to this job.");
      setAppliedStage("APPLIED");
      setJob((prev) =>
        prev ? { ...prev, hasApplied: true, applicationStage: "APPLIED" } : prev
      );
    } else {
      toast.error(res.error || "Could not apply. Please try again.");
    }
  }

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-3xl">
        <BackLink />
        <PageHeader title="Job details" description="Loading…" />
        <LoadingState label="Loading job…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto w-full max-w-3xl">
        <BackLink />
        <PageHeader title="Job details" description="Something went wrong." />
        <ErrorState
          message={error}
          action={
            <Button variant="outline" size="sm" onClick={retry}>
              Try again
            </Button>
          }
        />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="mx-auto w-full max-w-3xl">
        <BackLink />
        <PageHeader title="Job details" description="Not found." />
        <EmptyState
          icon={BriefcaseBusiness}
          title="Job not found"
          description="This job may have been closed or removed by the recruiter."
          action={
            <Button asChild variant="outline" size="sm">
              <Link href="/dashboard/student/jobs">Back to jobs</Link>
            </Button>
          }
        />
      </div>
    );
  }

  const skills = parseSkills(job.requiredSkills);
  const hasApplied = job.hasApplied || appliedStage !== null;
  const eligible = job.eligible;

  return (
    <div className="mx-auto w-full max-w-3xl">
      <BackLink />
      <PageHeader
        title={job.title}
        description={`Posted ${formatDate(job.createdAt)}`}
      />

      <div className="grid grid-cols-1 gap-6">
        {/* Job info card */}
        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-center gap-2">
              <JobTypeBadge jobType={job.jobType} />
              {hasApplied && appliedStage && (
                <StageBadge stage={appliedStage} />
              )}
            </div>
            <CardTitle className="text-xl">{job.title}</CardTitle>
            <CardDescription className="flex items-center gap-1.5">
              <Building2 className="size-4" />
              {job.companyName}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Meta icon={MapPin} label="Location" value={job.location} />
              <Meta
                icon={Package}
                label="Package"
                value={job.packageLpa || "Not specified"}
              />
              <Meta
                icon={BriefcaseBusiness}
                label="Type"
                value={JOB_TYPE_LABELS[job.jobType]}
              />
              <Meta
                icon={Award}
                label="Min avg score"
                value={`${job.minAvgScore}/100`}
              />
            </div>

            <div className="mt-5">
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                Job description
              </p>
              <p className="whitespace-pre-line text-sm leading-relaxed text-foreground">
                {job.description}
              </p>
            </div>

            {skills.length > 0 && (
              <div className="mt-5">
                <p className="mb-2 text-xs font-medium text-muted-foreground">
                  Required skills
                </p>
                <SkillChips skills={skills} max={12} />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Eligibility warning (only when not yet applied + below requirement) */}
        {!hasApplied && !eligible && job.minAvgScore > 0 && (
          <Alert variant="default" className="border-amber-300 bg-amber-50 text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
            <AlertTriangle className="text-amber-600" />
            <AlertTitle>Below the score requirement</AlertTitle>
            <AlertDescription className="text-amber-800 dark:text-amber-300">
              You don&apos;t meet the minimum score requirement (
              {job.minAvgScore}/100) but can still apply. Your average is{" "}
              <span className="font-medium">{studentAvg}/100</span>. Consider
              improving your skills first to stand out.
            </AlertDescription>
          </Alert>
        )}

        {/* Apply / applied card */}
        {hasApplied ? (
          <Card className="border-emerald-200/60">
            <CardContent className="flex flex-col items-start gap-3 p-5 sm:flex-row sm:items-center">
              <span className="inline-flex size-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                <CheckCircle2 className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-base font-semibold text-foreground">
                  You&apos;ve applied to this job
                </p>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  Current status:{" "}
                  {appliedStage ? (
                    <StageBadge stage={appliedStage} />
                  ) : (
                    "Applied"
                  )}
                  . You&apos;ll be notified when the recruiter moves you forward.
                </p>
              </div>
              <Button asChild variant="outline" size="sm">
                <Link href="/dashboard/student/jobs">Back to jobs</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Apply to this job</CardTitle>
              <CardDescription>
                Add an optional cover note to stand out — share what makes you a
                great fit.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={onApply} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="coverNote">Cover note (optional)</Label>
                  <Textarea
                    id="coverNote"
                    value={coverNote}
                    onChange={(e) => setCoverNote(e.target.value)}
                    placeholder="e.g. I've been working through your React roadmap and recently built a capstone project…"
                    rows={5}
                    maxLength={500}
                  />
                  <p className="text-right text-xs text-muted-foreground">
                    {coverNote.length}/500
                  </p>
                </div>

                <Button type="submit" className="w-full sm:w-auto" disabled={submitting}>
                  {submitting ? (
                    <>
                      <span className="size-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                      Submitting…
                    </>
                  ) : (
                    <>
                      <Send className="size-4" />
                      Apply now
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function BackLink() {
  return (
    <Button
      asChild
      variant="ghost"
      size="sm"
      className="mb-3 -ml-2 text-muted-foreground"
    >
      <Link href="/dashboard/student/jobs">
        <ArrowLeft className="size-4" />
        Back to jobs
      </Link>
    </Button>
  );
}

function Meta({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-2.5">
      <span className="mt-0.5 inline-flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary text-muted-foreground">
        <Icon className="size-3.5" />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <p className="truncate text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}
