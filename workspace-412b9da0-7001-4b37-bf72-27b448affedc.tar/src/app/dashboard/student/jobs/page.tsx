"use client";

import * as React from "react";
import Link from "next/link";
import {
  BriefcaseBusiness,
  Building2,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  MapPin,
  Package,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@/lib/api";

import {
  JOB_TYPE_LABELS,
  JobTypeBadge,
  SkillChips,
  StageBadge,
  STAGE_LABELS,
  formatDate,
  parseSkills,
  relativeTime,
  type ApplicationStage,
  type JobType,
} from "./_shared";

// ---- Types matching the student jobs API contract ----

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: JobType;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  companyName: string;
  createdAt: string;
  hasApplied: boolean;
  applicationStage: ApplicationStage | null;
  eligible: boolean;
};

type JobsResponse = { studentAvg: number; jobs: Job[] };

type StudentApplication = {
  id: string;
  stage: ApplicationStage;
  coverNote: string | null;
  createdAt: string;
  updatedAt: string;
  job: {
    id: string;
    title: string;
    location: string;
    jobType: JobType;
    packageLpa: string | null;
    companyName: string;
  };
};

type ApplicationsResponse = { applications: StudentApplication[] };

export default function StudentJobsPage() {
  const [jobsData, setJobsData] = React.useState<JobsResponse | null>(null);
  const [jobsLoading, setJobsLoading] = React.useState(true);
  const [jobsError, setJobsError] = React.useState<string | null>(null);

  const [apps, setApps] = React.useState<StudentApplication[]>([]);
  const [appsLoading, setAppsLoading] = React.useState(true);
  const [appsError, setAppsError] = React.useState<string | null>(null);

  const [jobsRefresh, setJobsRefresh] = React.useState(0);
  const [appsRefresh, setAppsRefresh] = React.useState(0);

  React.useEffect(() => {
    let cancelled = false;
    api<JobsResponse>("/api/jobs").then((res) => {
      if (cancelled) return;
      setJobsLoading(false);
      if (res.data) {
        setJobsData(res.data);
        setJobsError(null);
      } else {
        setJobsError(res.error || "Failed to load jobs.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [jobsRefresh]);

  React.useEffect(() => {
    let cancelled = false;
    api<ApplicationsResponse>("/api/student/applications").then((res) => {
      if (cancelled) return;
      setAppsLoading(false);
      if (res.data) {
        setApps(res.data.applications);
        setAppsError(null);
      } else {
        setAppsError(res.error || "Failed to load applications.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [appsRefresh]);

  function retryJobs() {
    setJobsLoading(true);
    setJobsError(null);
    setJobsRefresh((k) => k + 1);
  }

  function retryApps() {
    setAppsLoading(true);
    setAppsError(null);
    setAppsRefresh((k) => k + 1);
  }

  const studentAvg = jobsData?.studentAvg ?? 0;
  const jobs = jobsData?.jobs ?? [];
  const appliedCount = apps.length;

  return (
    <div className="mx-auto w-full max-w-6xl">
      <PageHeader
        title="Jobs"
        description="Browse openings and track your applications."
      >
        <span className="hidden items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-xs sm:inline-flex">
          <Sparkles className="size-3.5 text-primary" />
          <span className="text-muted-foreground">Your avg</span>
          <span className="font-semibold text-foreground">{studentAvg}/100</span>
        </span>
      </PageHeader>

      <Tabs defaultValue="browse" className="w-full">
        <TabsList>
          <TabsTrigger value="browse">
            Browse jobs
            {jobs.length > 0 && (
              <span className="ml-1 text-xs text-muted-foreground">
                {jobs.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="applied">
            My applications
            {appliedCount > 0 && (
              <span className="ml-1 text-xs text-muted-foreground">
                {appliedCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* -------- Browse jobs tab -------- */}
        <TabsContent value="browse">
          {jobsLoading ? (
            <LoadingState label="Loading jobs…" />
          ) : jobsError ? (
            <ErrorState
              message={jobsError}
              action={
                <Button variant="outline" size="sm" onClick={retryJobs}>
                  Try again
                </Button>
              }
            />
          ) : jobs.length === 0 ? (
            <EmptyState
              icon={BriefcaseBusiness}
              title="No open jobs yet"
              description="Recruiters' openings will show up here as soon as they're posted. Check back soon."
            />
          ) : (
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              {jobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  studentAvg={studentAvg}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* -------- My applications tab -------- */}
        <TabsContent value="applied">
          {appsLoading ? (
            <LoadingState label="Loading your applications…" />
          ) : appsError ? (
            <ErrorState
              message={appsError}
              action={
                <Button variant="outline" size="sm" onClick={retryApps}>
                  Try again
                </Button>
              }
            />
          ) : apps.length === 0 ? (
            <EmptyState
              icon={ClipboardList}
              title="No applications yet"
              description="Apply to jobs from the Browse tab and you'll see their status here as recruiters move you through their pipeline."
              action={
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const el = document.querySelector<HTMLButtonElement>(
                      '[role="tab"][data-value="browse"]'
                    );
                    el?.click();
                  }}
                >
                  Browse jobs
                </Button>
              }
            />
          ) : (
            <div className="space-y-3">
              {apps.map((app) => (
                <ApplicationRow key={app.id} application={app} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function JobCard({ job, studentAvg }: { job: Job; studentAvg: number }) {
  const skills = parseSkills(job.requiredSkills);
  const eligible = job.eligible;

  return (
    <Card className="flex flex-col overflow-hidden transition-shadow hover:shadow-md">
      <CardHeader>
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <CardTitle className="text-base">{job.title}</CardTitle>
            <CardDescription className="mt-1 flex items-center gap-1.5">
              <Building2 className="size-3.5" />
              {job.companyName}
            </CardDescription>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <JobTypeBadge jobType={job.jobType} />
            {job.hasApplied && (
              <span className="inline-flex items-center gap-1 rounded-md border border-transparent bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                <CheckCircle2 className="size-3" />
                Applied
              </span>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-3">
        <p className="line-clamp-2 text-sm text-muted-foreground">
          {job.description}
        </p>

        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <MapPin className="size-3.5" />
            {job.location}
          </span>
          {job.packageLpa && (
            <span className="inline-flex items-center gap-1">
              <Package className="size-3.5" />
              {job.packageLpa}
            </span>
          )}
          <span>Posted {relativeTime(job.createdAt)}</span>
        </div>

        {skills.length > 0 && <SkillChips skills={skills} max={5} />}

        {job.minAvgScore > 0 && (
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              Min avg required:{" "}
              <span className="font-medium text-foreground">
                {job.minAvgScore}/100
              </span>
            </p>
            <span
              className={`inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-medium ${
                eligible
                  ? "border border-transparent bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400"
                  : "border border-transparent bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400"
              }`}
            >
              {eligible ? "Eligible" : "Below requirement"}
            </span>
          </div>
        )}

        <div className="mt-auto pt-2">
          {job.hasApplied && job.applicationStage ? (
            <div className="flex items-center justify-between gap-2">
              <StageBadge stage={job.applicationStage} />
              <Button asChild variant="outline" size="sm">
                <Link href={`/dashboard/student/jobs/${job.id}`}>
                  View status
                  <ChevronRight className="size-4" />
                </Link>
              </Button>
            </div>
          ) : (
            <Button asChild size="sm" className="w-full sm:w-auto">
              <Link href={`/dashboard/student/jobs/${job.id}`}>
                View &amp; apply
                <ChevronRight className="size-4" />
              </Link>
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function ApplicationRow({ application }: { application: StudentApplication }) {
  const job = application.job;
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate text-base font-semibold text-foreground">
                {job.title}
              </h3>
              <StageBadge stage={application.stage} />
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Building2 className="size-3.5" />
                {job.companyName}
              </span>
              <span className="inline-flex items-center gap-1">
                <MapPin className="size-3.5" />
                {job.location}
              </span>
              <span className="inline-flex items-center gap-1">
                <BriefcaseBusiness className="size-3.5" />
                {JOB_TYPE_LABELS[job.jobType]}
              </span>
              {job.packageLpa && (
                <span className="inline-flex items-center gap-1">
                  <Package className="size-3.5" />
                  {job.packageLpa}
                </span>
              )}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              Applied {formatDate(application.createdAt)} · Updated{" "}
              {relativeTime(application.updatedAt)}
            </p>
            {application.coverNote && (
              <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                <span className="font-medium text-foreground/80">Note:</span>{" "}
                {application.coverNote}
              </p>
            )}
          </div>

          <div className="flex shrink-0 items-center gap-2 self-end sm:self-start">
            <Button asChild size="sm">
              <Link href={`/dashboard/student/jobs/${job.id}`}>
                View
                <ChevronRight className="size-4" />
              </Link>
            </Button>
          </div>
        </div>

        {/* Pipeline progress hint */}
        <div className="mt-4 flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Pipeline:</span>
          {(
            ["APPLIED", "SHORTLISTED", "EXAM", "INTERVIEW", "OFFER"] as ApplicationStage[]
          ).map((st, idx, arr) => {
            const isCurrent = application.stage === st;
            const isPast =
              arr.indexOf(application.stage as ApplicationStage) > idx;
            const isRejected = application.stage === "REJECTED";
            return (
              <React.Fragment key={st}>
                <span
                  className={`inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-medium ${
                    isCurrent
                      ? "bg-primary/10 text-primary"
                      : isPast && !isRejected
                      ? "bg-secondary text-secondary-foreground"
                      : "bg-secondary/40 text-muted-foreground/70"
                  }`}
                >
                  {STAGE_LABELS[st]}
                </span>
                {idx < arr.length - 1 && (
                  <span className="text-muted-foreground/40">›</span>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
