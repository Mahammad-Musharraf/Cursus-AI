"use client";

import * as React from "react";
import {
  Mail,
  Award,
  Filter,
  KanbanSquare,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { api } from "@/lib/api";

import {
  STAGE_LABELS,
  STAGE_ORDER,
  StageSelect,
  initialsOf,
  relativeTime,
  statusFromScore,
  STATUS_BADGE_CLASS,
  STATUS_LABELS,
  type ApplicationStage,
} from "../jobs/_shared";

type Certificate = { id: string; title: string; issuer: string };

type PipelineStudent = {
  id: string;
  name: string;
  email: string;
  careerTitle: string | null;
  avgScore: number;
  readinessPct: number;
  status: ReturnType<typeof statusFromScore>;
  solvedProblems: number;
  certificates: Certificate[];
};

type PipelineApplication = {
  id: string;
  stage: ApplicationStage;
  coverNote: string | null;
  createdAt: string;
  updatedAt: string;
  job: { id: string; title: string };
  student: PipelineStudent;
};

type PipelineResponse = {
  stages: ApplicationStage[];
  applications: PipelineApplication[];
};

export default function RecruiterPipelinePage() {
  const [data, setData] = React.useState<PipelineResponse | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshKey, setRefreshKey] = React.useState(0);

  const [jobFilter, setJobFilter] = React.useState<string>("all");
  const [pendingId, setPendingId] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    api<PipelineResponse>("/api/recruiter/pipeline").then((res) => {
      if (cancelled) return;
      setLoading(false);
      if (res.data) {
        setData(res.data);
        setError(null);
      } else {
        setError(res.error || "Failed to load pipeline.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  function retry() {
    setLoading(true);
    setError(null);
    setRefreshKey((k) => k + 1);
  }

  // Build the list of distinct jobs for the filter Select.
  const jobOptions = React.useMemo(() => {
    if (!data) return [];
    const map = new Map<string, string>();
    for (const a of data.applications) {
      if (!map.has(a.job.id)) map.set(a.job.id, a.job.title);
    }
    return Array.from(map.entries()).map(([id, title]) => ({ id, title }));
  }, [data]);

  const filteredApps = React.useMemo(() => {
    if (!data) return [];
    if (jobFilter === "all") return data.applications;
    return data.applications.filter((a) => a.job.id === jobFilter);
  }, [data, jobFilter]);

  // Group by stage.
  const byStage = React.useMemo(() => {
    const map = new Map<ApplicationStage, PipelineApplication[]>();
    for (const stage of STAGE_ORDER) map.set(stage, []);
    for (const a of filteredApps) {
      map.get(a.stage)?.push(a);
    }
    return map;
  }, [filteredApps]);

  async function onMove(application: PipelineApplication, next: ApplicationStage) {
    if (next === application.stage) return;
    // Optimistic: move the card to the new column immediately.
    setData((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        applications: prev.applications.map((a) =>
          a.id === application.id
            ? { ...a, stage: next, updatedAt: new Date().toISOString() }
            : a
        ),
      };
    });
    setPendingId(application.id);
    const res = await api<{ ok: boolean; stage: ApplicationStage }>(
      "/api/recruiter/pipeline",
      {
        method: "PATCH",
        body: JSON.stringify({ applicationId: application.id, stage: next }),
      }
    );
    setPendingId(null);
    if (res.data?.ok) {
      toast.success("Moved candidate", {
        description: `${application.student.name} → ${STAGE_LABELS[next]}.`,
      });
    } else {
      // Revert
      setData((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          applications: prev.applications.map((a) =>
            a.id === application.id ? { ...a, stage: application.stage } : a
          ),
        };
      });
      toast.error(res.error || "Could not move candidate.");
    }
  }

  const totalApps = data?.applications.length ?? 0;

  return (
    <div className="mx-auto w-full max-w-7xl">
      <PageHeader
        title="Hiring pipeline"
        description="Move candidates across stages — Applied → Shortlisted → Exam → Interview → Offer."
      >
        {totalApps > 0 && (
          <span className="hidden text-sm text-muted-foreground sm:inline">
            <span className="font-semibold text-foreground">{totalApps}</span>{" "}
            {totalApps === 1 ? "candidate" : "candidates"}
          </span>
        )}
      </PageHeader>

      {/* Job filter */}
      {jobOptions.length > 1 && (
        <div className="mb-4 flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground">
            <Filter className="size-4" />
            Filter by job
          </span>
          <Select value={jobFilter} onValueChange={setJobFilter}>
            <SelectTrigger className="h-9 w-[16rem]" aria-label="Filter by job">
              <SelectValue placeholder="All jobs" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All jobs</SelectItem>
              {jobOptions.map((j) => (
                <SelectItem key={j.id} value={j.id}>
                  {j.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {jobFilter !== "all" && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setJobFilter("all")}
              className="text-muted-foreground"
            >
              Clear
            </Button>
          )}
        </div>
      )}

      {loading ? (
        <LoadingState label="Loading pipeline…" />
      ) : error ? (
        <ErrorState
          message={error}
          action={
            <Button variant="outline" size="sm" onClick={retry}>
              Try again
            </Button>
          }
        />
      ) : totalApps === 0 ? (
        <EmptyState
          icon={KanbanSquare}
          title="No applications yet"
          description="Once students apply to your jobs, you'll see them here grouped by their stage in your hiring pipeline."
          action={
            <Button asChild variant="outline" size="sm">
              <a href="/dashboard/recruiter/jobs">View your jobs</a>
            </Button>
          }
        />
      ) : (
        <div className="overflow-x-auto pb-3">
          <div className="grid min-w-[64rem] grid-cols-6 gap-4 lg:min-w-0 lg:grid-cols-6">
            {STAGE_ORDER.map((stage) => {
              const list = byStage.get(stage) ?? [];
              return (
                <PipelineColumn
                  key={stage}
                  stage={stage}
                  applications={list}
                  pendingId={pendingId}
                  onMove={onMove}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function PipelineColumn({
  stage,
  applications,
  pendingId,
  onMove,
}: {
  stage: ApplicationStage;
  applications: PipelineApplication[];
  pendingId: string | null;
  onMove: (a: PipelineApplication, next: ApplicationStage) => void;
}) {
  return (
    <div className="flex min-w-[14rem] flex-col gap-3">
      <div className="flex items-center justify-between gap-2 rounded-md border border-border bg-card px-3 py-2">
        <div className="flex min-w-0 items-center gap-2">
          <span
            className={`inline-flex size-2.5 shrink-0 rounded-full ${
              STAGE_BADGE_DOT[stage]
            }`}
          />
          <span className="truncate text-sm font-medium text-foreground">
            {STAGE_LABELS[stage]}
          </span>
        </div>
        <span className="shrink-0 text-xs font-semibold text-muted-foreground">
          {applications.length}
        </span>
      </div>

      <div className="flex flex-col gap-3">
        {applications.length === 0 ? (
          <div className="rounded-md border border-dashed border-border bg-card/50 px-3 py-6 text-center">
            <p className="text-xs text-muted-foreground">No candidates</p>
          </div>
        ) : (
          applications.map((app) => (
            <PipelineCard
              key={app.id}
              application={app}
              pending={pendingId === app.id}
              onMove={(next) => onMove(app, next)}
            />
          ))
        )}
      </div>
    </div>
  );
}

// Tailwind-friendly dot colors per stage (kept here so the column header is simple).
const STAGE_BADGE_DOT: Record<ApplicationStage, string> = {
  APPLIED: "bg-muted-foreground/60",
  SHORTLISTED: "bg-primary",
  EXAM: "bg-amber-500",
  INTERVIEW: "bg-purple-500",
  OFFER: "bg-emerald-500",
  REJECTED: "bg-red-500",
};

function PipelineCard({
  application,
  pending,
  onMove,
}: {
  application: PipelineApplication;
  pending: boolean;
  onMove: (next: ApplicationStage) => void;
}) {
  const s = application.student;
  const hasAssessment = s.avgScore > 0 || s.status !== "no-assessment";
  const certs = s.certificates ?? [];

  return (
    <Card
      className={`transition-shadow hover:shadow-md ${
        pending ? "opacity-60" : ""
      }`}
    >
      <CardContent className="p-4">
        {/* Identity */}
        <div className="flex items-start gap-2.5">
          <Avatar className="size-9 shrink-0">
            <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">
              {initialsOf(s.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-foreground">
              {s.name}
            </p>
            <p className="truncate text-xs text-muted-foreground">
              {application.job.title}
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-md bg-secondary/60 px-2 py-1.5">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Avg
            </p>
            <p className="font-semibold text-foreground">
              {hasAssessment ? s.avgScore : "—"}
              {hasAssessment && (
                <span className="text-[10px] font-normal text-muted-foreground">
                  /100
                </span>
              )}
            </p>
          </div>
          <div className="rounded-md bg-secondary/60 px-2 py-1.5">
            <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
              Readiness
            </p>
            <p className="font-semibold text-foreground">
              {hasAssessment ? `${s.readinessPct}%` : "—"}
            </p>
          </div>
        </div>

        {/* Status + readiness bar */}
        <div className="mt-2.5 flex items-center justify-between gap-2">
          <span
            className={`inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-medium ${STATUS_BADGE_CLASS[s.status]}`}
          >
            {STATUS_LABELS[s.status]}
          </span>
          <span className="text-[10px] text-muted-foreground">
            {relativeTime(application.updatedAt)}
          </span>
        </div>
        {hasAssessment && (
          <Progress value={s.readinessPct} className="mt-1.5 h-1" />
        )}

        {/* Career + certificates quick row */}
        {s.careerTitle && (
          <p className="mt-2.5 truncate text-xs text-muted-foreground">
            <span className="text-foreground/80">{s.careerTitle}</span>
            {certs.length > 0 && (
              <>
                {" "}
                ·{" "}
                <span className="inline-flex items-center gap-0.5">
                  <Award className="size-3 text-emerald-600" />
                  {certs.length}
                </span>
              </>
            )}
          </p>
        )}

        {/* Stage move control */}
        <div className="mt-3 flex items-center gap-2">
          <StageSelect
            value={application.stage}
            onChange={onMove}
            disabled={pending}
            className="h-8 w-full flex-1"
          />
          <a
            href={`mailto:${s.email}`}
            className="inline-flex size-8 shrink-0 items-center justify-center rounded-md border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
            title={`Email ${s.name}`}
            aria-label={`Email ${s.name}`}
          >
            <Mail className="size-3.5" />
          </a>
        </div>
      </CardContent>
    </Card>
  );
}
