"use client";

import * as React from "react";
import Link from "next/link";
import {
  BriefcaseBusiness,
  ChevronRight,
  MapPin,
  Package,
  Plus,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { api } from "@/lib/api";

import {
  JOB_TYPE_LABELS,
  JobTypeBadge,
  SkillChips,
  formatDate,
  parseSkills,
  type JobType,
} from "./_shared";

type Job = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: JobType;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  isActive: boolean;
  createdAt: string;
  applicationCount: number;
};

type JobsResponse = { jobs: Job[] };

type FieldErrors = Partial<Record<keyof NewJobPayload, string[]>>;

type NewJobPayload = {
  title: string;
  description: string;
  location: string;
  jobType: JobType;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa?: string;
};

const EMPTY_FORM: NewJobPayload = {
  title: "",
  description: "",
  location: "Remote",
  jobType: "FULL_TIME",
  requiredSkills: "",
  minAvgScore: 0,
  packageLpa: "",
};

export default function RecruiterJobsPage() {
  const [jobs, setJobs] = React.useState<Job[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshKey, setRefreshKey] = React.useState(0);

  // Form state
  const [form, setForm] = React.useState<NewJobPayload>(EMPTY_FORM);
  const [submitting, setSubmitting] = React.useState(false);
  const [fieldErrors, setFieldErrors] = React.useState<FieldErrors>({});

  // Delete confirmation
  const [deleteTarget, setDeleteTarget] = React.useState<Job | null>(null);
  const [deleting, setDeleting] = React.useState(false);

  React.useEffect(() => {
    let cancelled = false;
    api<JobsResponse>("/api/recruiter/jobs").then((res) => {
      if (cancelled) return;
      setLoading(false);
      if (res.data) {
        setJobs(res.data.jobs);
        setError(null);
      } else {
        setError(res.error || "Failed to load jobs.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  function retry() {
    setLoading(true);
    setError(null);
    setRefreshKey((k) => k + 1);
  }

  function update<K extends keyof NewJobPayload>(
    key: K,
    value: NewJobPayload[K]
  ) {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (fieldErrors[key]) {
      setFieldErrors((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;

    // Light client validation — server is the source of truth.
    if (form.title.trim().length < 2) {
      setFieldErrors({ title: ["Title must be at least 2 characters."] });
      return;
    }
    if (form.description.trim().length < 10) {
      setFieldErrors({
        description: ["Description must be at least 10 characters."],
      });
      return;
    }

    setSubmitting(true);
    setFieldErrors({});
    const payload: NewJobPayload = {
      ...form,
      location: form.location.trim() || "Remote",
      requiredSkills: parseSkills(form.requiredSkills).join(", "),
      packageLpa: form.packageLpa?.trim() ? form.packageLpa.trim() : undefined,
    };

    try {
      const resp = await fetch("/api/recruiter/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const text = await resp.text();
      const body = text ? JSON.parse(text) : null;
      setSubmitting(false);

      if (resp.ok && body?.ok) {
        toast.success("Job posted.", {
          description: `${body.job.title} is now live for students.`,
        });
        setJobs((prev) => [body.job as Job, ...prev]);
        setForm(EMPTY_FORM);
      } else if (resp.status === 422 && body?.fields) {
        setFieldErrors(body.fields as FieldErrors);
      } else {
        toast.error(body?.error || "Could not post job.");
      }
    } catch {
      setSubmitting(false);
      toast.error("Network error. Please try again.");
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    const target = deleteTarget;
    const res = await api<{ ok: boolean }>(
      `/api/recruiter/jobs/${encodeURIComponent(target.id)}`,
      { method: "DELETE" }
    );
    setDeleting(false);
    if (res.data?.ok) {
      toast.success("Job deleted.", {
        description: `${target.title} and its applications were removed.`,
      });
      setJobs((prev) => prev.filter((j) => j.id !== target.id));
      setDeleteTarget(null);
    } else {
      toast.error(res.error || "Could not delete job.");
    }
  }

  return (
    <div className="mx-auto w-full max-w-6xl">
      <PageHeader
        title="Jobs"
        description="Post openings and track applicants."
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1.4fr]">
        {/* Post a job card (primary action) */}
        <Card className="lg:sticky lg:top-4 lg:self-start">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="inline-flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary">
                <Plus className="size-4" />
              </span>
              Post a job
            </CardTitle>
            <CardDescription>
              Fill in the details and your opening goes live instantly.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="title">
                  Title <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="title"
                  value={form.title}
                  onChange={(e) => update("title", e.target.value)}
                  placeholder="e.g. Frontend Engineer (React)"
                  required
                  minLength={2}
                  aria-invalid={!!fieldErrors.title}
                />
                {fieldErrors.title && (
                  <p className="text-xs text-destructive">
                    {fieldErrors.title[0]}
                  </p>
                )}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="description">
                  Description <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="description"
                  value={form.description}
                  onChange={(e) => update("description", e.target.value)}
                  placeholder="What will the candidate do? What are the day-to-day responsibilities?"
                  rows={4}
                  required
                  minLength={10}
                  aria-invalid={!!fieldErrors.description}
                />
                {fieldErrors.description && (
                  <p className="text-xs text-destructive">
                    {fieldErrors.description[0]}
                  </p>
                )}
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={form.location}
                    onChange={(e) => update("location", e.target.value)}
                    placeholder="Remote / Bangalore / Hybrid"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="jobType">Job type</Label>
                  <Select
                    value={form.jobType}
                    onValueChange={(v) => update("jobType", v as JobType)}
                  >
                    <SelectTrigger id="jobType" className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.keys(JOB_TYPE_LABELS) as JobType[]).map(
                        (jt) => (
                          <SelectItem key={jt} value={jt}>
                            {JOB_TYPE_LABELS[jt]}
                          </SelectItem>
                        )
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="skills">Required skills</Label>
                <Input
                  id="skills"
                  value={form.requiredSkills}
                  onChange={(e) => update("requiredSkills", e.target.value)}
                  placeholder="React, TypeScript, REST APIs"
                />
                <p className="text-xs text-muted-foreground">
                  Comma-separated. These show up as chips on the job card.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="minAvg">Min avg score (0–100)</Label>
                  <Input
                    id="minAvg"
                    type="number"
                    min={0}
                    max={100}
                    value={form.minAvgScore}
                    onChange={(e) =>
                      update(
                        "minAvgScore",
                        Math.max(
                          0,
                          Math.min(100, Number(e.target.value || 0))
                        )
                      )
                    }
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="packageLpa">Package (optional)</Label>
                  <Input
                    id="packageLpa"
                    value={form.packageLpa ?? ""}
                    onChange={(e) => update("packageLpa", e.target.value)}
                    placeholder="₹8–14 LPA"
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting ? "Posting…" : "Post job"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Jobs list */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-medium text-muted-foreground">
              {loading ? (
                "Loading your jobs…"
              ) : (
                <>
                  <span className="font-semibold text-foreground">
                    {jobs.length}
                  </span>{" "}
                  {jobs.length === 1 ? "job" : "jobs"}
                </>
              )}
            </h2>
          </div>

          {loading ? (
            <LoadingState label="Loading jobs…" />
          ) : error ? (
            <ErrorState
              message={error}
              action={
                <Button variant="outline" size="sm" onClick={retry}>
                  Try again
                </Button>
              }
            />
          ) : jobs.length === 0 ? (
            <EmptyState
              icon={BriefcaseBusiness}
              title="No jobs yet"
              description="Post your first opening and it will appear here. Students will see it on their jobs board."
            />
          ) : (
            <div className="max-h-[42rem] space-y-3 overflow-y-auto scrollbar-thin pr-1">
              {jobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  onView={() => {}}
                  onDelete={() => setDeleteTarget(job)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Delete confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this job?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes{" "}
              <span className="font-medium text-foreground">
                {deleteTarget?.title}
              </span>{" "}
              and all {deleteTarget?.applicationCount ?? 0} applicant records.
              This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                confirmDelete();
              }}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "Deleting…" : "Delete job"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function JobCard({
  job,
  onView,
  onDelete,
}: {
  job: Job;
  onView: () => void;
  onDelete: () => void;
}) {
  const skills = parseSkills(job.requiredSkills);
  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-md">
      <CardContent className="p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="truncate text-base font-semibold text-foreground">
                {job.title}
              </h3>
              <JobTypeBadge jobType={job.jobType} />
              {job.isActive ? (
                <span className="inline-flex items-center rounded-md border border-transparent bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                  Active
                </span>
              ) : (
                <span className="inline-flex items-center rounded-md border border-transparent bg-secondary px-2 py-0.5 text-xs font-medium text-muted-foreground">
                  Inactive
                </span>
              )}
            </div>

            <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <MapPin className="size-3.5" />
                {job.location}
              </span>
              {job.packageLpa && (
                <span className="inline-flex items-center gap-1">
                  <Package className="size-3.5" />
                  {job.packageLpa}
                </span>
              )}
              <span className="inline-flex items-center gap-1">
                <Users className="size-3.5" />
                {job.applicationCount}{" "}
                {job.applicationCount === 1 ? "applicant" : "applicants"}
              </span>
              <span>Posted {formatDate(job.createdAt)}</span>
            </div>

            <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
              {job.description}
            </p>

            {skills.length > 0 && (
              <div className="mt-3">
                <SkillChips skills={skills} />
              </div>
            )}

            {job.minAvgScore > 0 && (
              <p className="mt-3 text-xs text-muted-foreground">
                Min avg score required:{" "}
                <span className="font-medium text-foreground">
                  {job.minAvgScore}/100
                </span>
              </p>
            )}
          </div>

          <div className="flex shrink-0 items-center gap-2 self-end sm:self-start">
            <Button asChild size="sm">
              <Link
                href={`/dashboard/recruiter/jobs/${job.id}`}
                onClick={onView}
              >
                View applicants
                <ChevronRight className="size-4" />
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-muted-foreground hover:text-destructive"
              aria-label={`Delete ${job.title}`}
              title="Delete job"
              onClick={onDelete}
            >
              <Trash2 className="size-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
