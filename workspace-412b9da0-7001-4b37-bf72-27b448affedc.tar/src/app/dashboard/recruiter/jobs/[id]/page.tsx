"use client";

import * as React from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  Award,
  BriefcaseBusiness,
  CheckCircle2,
  Mail,
  MapPin,
  Package,
  Trash2,
  Users,
} from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/page-header";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { api } from "@/lib/api";

import {
  JOB_TYPE_LABELS,
  JobTypeBadge,
  SkillChips,
  StageBadge,
  StageSelect,
  avgScoreFromAssessments,
  formatDate,
  initialsOf,
  parseSkills,
  statusFromScore,
  STATUS_BADGE_CLASS,
  STATUS_LABELS,
  type ApplicationStage,
  type JobType,
} from "../_shared";

// ---- Types matching the recruiter job-detail API contract ----

type Certificate = { id: string; title: string; issuer: string };

type ApplicantStudent = {
  id: string;
  name: string;
  email: string;
  targetCareer?: { title: string } | null;
  assessments?: { scores?: Record<string, number> | null }[];
  problemProgress?: { done: boolean }[];
  certificates?: Certificate[];
};

type Application = {
  id: string;
  stage: ApplicationStage;
  coverNote: string | null;
  createdAt: string;
  student: ApplicantStudent;
};

type JobDetail = {
  id: string;
  title: string;
  description: string;
  location: string;
  jobType: JobType;
  requiredSkills: string;
  minAvgScore: number;
  packageLpa: string | null;
  isActive: boolean;
  createdAt: string;
  applications: Application[];
};

type JobDetailResponse = { job: JobDetail };

export default function RecruiterJobDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const jobId = params?.id;

  const [job, setJob] = React.useState<JobDetail | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [refreshKey, setRefreshKey] = React.useState(0);

  // Stage-change in-flight tracker (per application id)
  const [pendingStageId, setPendingStageId] = React.useState<string | null>(
    null
  );

  // Delete confirmation
  const [deleteOpen, setDeleteOpen] = React.useState(false);
  const [deleting, setDeleting] = React.useState(false);

  React.useEffect(() => {
    if (!jobId) return;
    let cancelled = false;
    api<JobDetailResponse>(
      `/api/recruiter/jobs/${encodeURIComponent(jobId)}`
    ).then((res) => {
      if (cancelled) return;
      setLoading(false);
      if (res.data) {
        setJob(res.data.job);
        setError(null);
      } else {
        setError(res.error || "Failed to load this job.");
      }
    });
    return () => {
      cancelled = true;
    };
  }, [jobId, refreshKey]);

  function retry() {
    setLoading(true);
    setError(null);
    setRefreshKey((k) => k + 1);
  }

  async function onStageChange(application: Application, next: ApplicationStage) {
    if (next === application.stage) return;
    // Optimistic update
    setJob((prev) =>
      prev
        ? {
            ...prev,
            applications: prev.applications.map((a) =>
              a.id === application.id ? { ...a, stage: next } : a
            ),
          }
        : prev
    );
    setPendingStageId(application.id);
    const res = await api<{ ok: boolean; stage: ApplicationStage }>(
      "/api/recruiter/pipeline",
      {
        method: "PATCH",
        body: JSON.stringify({
          applicationId: application.id,
          stage: next,
        }),
      }
    );
    setPendingStageId(null);
    if (res.data?.ok) {
      toast.success("Stage updated", {
        description: `${application.student.name} → ${
          next === "OFFER" ? "Offer" : next === "REJECTED" ? "Rejected" : next
        }.`,
      });
    } else {
      // Revert
      setJob((prev) =>
        prev
          ? {
              ...prev,
              applications: prev.applications.map((a) =>
                a.id === application.id ? { ...a, stage: application.stage } : a
              ),
            }
          : prev
      );
      toast.error(res.error || "Could not update stage.");
    }
  }

  async function confirmDelete() {
    if (!job) return;
    setDeleting(true);
    const res = await api<{ ok: boolean }>(
      `/api/recruiter/jobs/${encodeURIComponent(job.id)}`,
      { method: "DELETE" }
    );
    setDeleting(false);
    if (res.data?.ok) {
      toast.success("Job deleted.");
      router.push("/dashboard/recruiter/jobs");
    } else {
      toast.error(res.error || "Could not delete job.");
    }
  }

  if (loading) {
    return (
      <div className="mx-auto w-full max-w-5xl">
        <BackLink />
        <PageHeader title="Job" description="Loading…" />
        <LoadingState label="Loading job…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto w-full max-w-5xl">
        <BackLink />
        <PageHeader title="Job" description="Something went wrong." />
        <ErrorState
          message={error}
          action={
            <Button variant="outline" size="sm" onClick={retry}>
              Try again
            </Button>
          }
        />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="mx-auto w-full max-w-5xl">
        <BackLink />
        <PageHeader title="Job" description="Not found." />
        <EmptyState
          icon={BriefcaseBusiness}
          title="Job not found"
          description="This job may have been deleted, or you don't have access to view it."
          action={
            <Button asChild variant="outline" size="sm">
              <Link href="/dashboard/recruiter/jobs">Back to jobs</Link>
            </Button>
          }
        />
      </div>
    );
  }

  const skills = parseSkills(job.requiredSkills);

  return (
    <div className="mx-auto w-full max-w-5xl">
      <BackLink />
      <PageHeader
        title={job.title}
        description={`Posted ${formatDate(job.createdAt)} • ${job.applications.length} ${
          job.applications.length === 1 ? "applicant" : "applicants"
        }`}
      >
        <Button
          variant="outline"
          size="sm"
          onClick={() => setDeleteOpen(true)}
          className="text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" />
          Delete
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <div className="flex flex-wrap items-center gap-2">
              <JobTypeBadge jobType={job.jobType} />
              {job.isActive ? (
                <span className="inline-flex items-center rounded-md border border-transparent bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                  Active
                </span>
              ) : (
                <span className="inline-flex items-center rounded-md border border-transparent bg-secondary px-2 py-0.5 text-xs font-medium text-muted-foreground">
                  Inactive
                </span>
              )}
            </div>
            <CardTitle className="text-xl">{job.title}</CardTitle>
            <CardDescription className="whitespace-pre-line">
              {job.description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Meta icon={MapPin} label="Location" value={job.location} />
              <Meta
                icon={Package}
                label="Package"
                value={job.packageLpa || "Not specified"}
              />
              <Meta
                icon={BriefcaseBusiness}
                label="Type"
                value={JOB_TYPE_LABELS[job.jobType]}
              />
              <Meta
                icon={Award}
                label="Min avg score"
                value={`${job.minAvgScore}/100`}
              />
            </div>

            {skills.length > 0 && (
              <div className="mt-4">
                <p className="mb-2 text-xs font-medium text-muted-foreground">
                  Required skills
                </p>
                <SkillChips skills={skills} max={12} />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Applicants */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-base font-semibold text-foreground">
              <Users className="size-4 text-muted-foreground" />
              Applicants
              <Badge variant="secondary" className="font-semibold">
                {job.applications.length}
              </Badge>
            </h2>
          </div>

          {job.applications.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No applicants yet"
              description="Students who apply to this job will appear here. You'll be able to advance them through your hiring pipeline."
            />
          ) : (
            <div className="max-h-[40rem] space-y-3 overflow-y-auto scrollbar-thin pr-1">
              {job.applications.map((app) => (
                <ApplicantCard
                  key={app.id}
                  application={app}
                  pending={pendingStageId === app.id}
                  onStageChange={(next) => onStageChange(app, next)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this job?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes{" "}
              <span className="font-medium text-foreground">{job.title}</span>{" "}
              and all{" "}
              <span className="font-medium text-foreground">
                {job.applications.length}
              </span>{" "}
              applicant records. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                confirmDelete();
              }}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "Deleting…" : "Delete job"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function BackLink() {
  return (
    <Button
      asChild
      variant="ghost"
      size="sm"
      className="mb-3 -ml-2 text-muted-foreground"
    >
      <Link href="/dashboard/recruiter/jobs">
        <ArrowLeft className="size-4" />
        Back to jobs
      </Link>
    </Button>
  );
}

function Meta({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-2.5">
      <span className="mt-0.5 inline-flex size-7 shrink-0 items-center justify-center rounded-md bg-secondary text-muted-foreground">
        <Icon className="size-3.5" />
      </span>
      <div className="min-w-0">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <p className="truncate text-sm font-medium text-foreground">{value}</p>
      </div>
    </div>
  );
}

function ApplicantCard({
  application,
  pending,
  onStageChange,
}: {
  application: Application;
  pending: boolean;
  onStageChange: (next: ApplicationStage) => void;
}) {
  const s = application.student;
  const hasAssessment = !!s.assessments && s.assessments.length > 0;
  const avg = avgScoreFromAssessments(s.assessments);
  const solved = s.problemProgress?.filter((p) => p.done).length ?? 0;
  const totalProblems = s.problemProgress?.length ?? 0;
  const status = statusFromScore(hasAssessment, avg);
  // Without targetCareer.requiredSkills we can't compute true readiness.
  // Use the avg score (0–100) as a readiness proxy on this page.
  const readinessPct = hasAssessment ? avg : 0;
  const certs = s.certificates ?? [];

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          {/* Identity */}
          <div className="flex min-w-0 items-start gap-3">
            <Avatar className="size-11 shrink-0">
              <AvatarFallback className="bg-primary/10 text-sm font-semibold text-primary">
                {initialsOf(s.name)}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <p className="truncate text-base font-semibold text-foreground">
                  {s.name}
                </p>
                <Badge className={STATUS_BADGE_CLASS[status]}>
                  {STATUS_LABELS[status]}
                </Badge>
              </div>
              <a
                href={`mailto:${s.email}`}
                className="mt-0.5 inline-flex items-center gap-1 truncate text-sm text-muted-foreground hover:text-foreground"
              >
                <Mail className="size-3.5" />
                {s.email}
              </a>
              <p className="mt-1 truncate text-sm text-muted-foreground">
                {s.targetCareer?.title || "No target career"}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Applied {formatDate(application.createdAt)}
              </p>
            </div>
          </div>

          {/* Stage control */}
          <div className="flex shrink-0 flex-col items-end gap-2">
            <StageBadge stage={application.stage} />
            <StageSelect
              value={application.stage}
              onChange={onStageChange}
              disabled={pending}
            />
          </div>
        </div>

        <Separator className="my-4" />

        {/* Metrics */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Metric
            label="Avg score"
            value={hasAssessment ? `${avg}` : "—"}
            hint="/100"
          />
          <Metric
            label="Readiness"
            value={hasAssessment ? `${readinessPct}%` : "—"}
            progress={hasAssessment ? readinessPct : 0}
          />
          <Metric
            label="Problems solved"
            value={`${solved}`}
            hint={totalProblems > 0 ? `of ${totalProblems}` : "no practice yet"}
          />
          <Metric
            label="Certificates"
            value={`${certs.length}`}
            hint={certs.length === 0 ? "none verified" : "verified"}
          />
        </div>

        {/* Cover note */}
        {application.coverNote && (
          <div className="mt-4 rounded-md border border-border bg-secondary/40 p-3">
            <p className="mb-1 text-xs font-medium text-muted-foreground">
              Cover note
            </p>
            <p className="whitespace-pre-line text-sm text-foreground">
              {application.coverNote}
            </p>
          </div>
        )}

        {/* Verified certificates */}
        {certs.length > 0 && (
          <div className="mt-4">
            <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
              <CheckCircle2 className="size-3.5 text-emerald-600" />
              Verified certificates
            </p>
            <div className="flex flex-wrap gap-2">
              {certs.map((c) => (
                <span
                  key={c.id}
                  className="inline-flex items-center gap-1 rounded-md border border-emerald-200/60 bg-emerald-50 px-2 py-1 text-xs text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400"
                >
                  <Award className="size-3" />
                  <span className="font-medium">{c.title}</span>
                  <span className="text-emerald-600/70">· {c.issuer}</span>
                </span>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Metric({
  label,
  value,
  hint,
  progress,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  progress?: number;
}) {
  return (
    <div className="min-w-0">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-xl font-semibold tracking-tight text-foreground">
        {value}
        {hint && (
          <span className="ml-0.5 text-sm font-normal text-muted-foreground">
            {hint}
          </span>
        )}
      </p>
      {typeof progress === "number" && (
        <Progress value={progress} className="mt-1.5 h-1.5" />
      )}
    </div>
  );
}
