import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import {
  json,
  unauthorized,
  forbidden,
  notFound,
  errorResponse,
  parseBody,
  zodErrors,
} from "@/lib/api";
import {
  studentAggregates,
  type StudentWithRelations,
} from "@/lib/student-stats";

const STAGES = ["APPLIED", "SHORTLISTED", "EXAM", "INTERVIEW", "OFFER", "REJECTED"] as const;

// Recruiter: list all applications across their jobs (pipeline view)
export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const { searchParams } = new URL(req.url);
  const jobFilter = searchParams.get("jobId");
  const stageFilter = searchParams.get("stage");

  const jobs = await db.job.findMany({
    where: { recruiterId: user.id },
    select: { id: true },
  });
  const jobIds = jobs.map((j) => j.id);

  const applications = await db.jobApplication.findMany({
    where: {
      jobId: { in: jobIds },
      ...(jobFilter ? { jobId: jobFilter } : {}),
      ...(stageFilter ? { stage: stageFilter } : {}),
    },
    include: {
      job: { select: { id: true, title: true } },
      student: {
        include: {
          targetCareer: { select: { title: true } },
          assessments: { orderBy: { takenAt: "desc" }, take: 1, select: { scores: true } },
          problemProgress: { select: { done: true } },
          certificates: { where: { status: "APPROVED" }, select: { id: true, title: true, issuer: true } },
        },
      },
    },
    orderBy: { updatedAt: "desc" },
  });

  return json({
    stages: STAGES,
    applications: applications.map((a) => {
      const agg = studentAggregates(a.student as unknown as StudentWithRelations);
      return {
        id: a.id,
        stage: a.stage,
        coverNote: a.coverNote,
        createdAt: a.createdAt,
        updatedAt: a.updatedAt,
        job: a.job,
        student: {
          id: a.student.id,
          name: a.student.name,
          email: a.student.email,
          careerTitle: a.student.targetCareer?.title ?? null,
          avgScore: agg.avgCurrent,
          readinessPct: agg.readinessPct,
          status: agg.status,
          solvedProblems: agg.solvedProblems,
          certificates: a.student.certificates,
        },
      };
    }),
  });
}

const AdvanceSchema = z.object({
  applicationId: z.string(),
  stage: z.enum(STAGES),
});

// Advance an application to a new stage
export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return unauthorized();
  if (user.role !== "RECRUITER") return forbidden();

  const parsed = await parseBody(AdvanceSchema, req);
  if (!parsed.ok) {
    return errorResponse("Invalid input", 422, { fields: zodErrors(parsed.error) });
  }
  const { applicationId, stage } = parsed.data;

  // Verify the application belongs to one of the recruiter's jobs
  const application = await db.jobApplication.findUnique({
    where: { id: applicationId },
    include: { job: true },
  });
  if (!application || application.job.recruiterId !== user.id) {
    return notFound("Application not found.");
  }

  await db.jobApplication.update({
    where: { id: applicationId },
    data: { stage },
  });

  // Notify the student
  const stageLabels: Record<string, string> = {
    APPLIED: "Applied",
    SHORTLISTED: "Shortlisted",
    EXAM: "Selected for exam",
    INTERVIEW: "Interview scheduled",
    OFFER: "Offer extended! 🎉",
    REJECTED: "Application update",
  };
  await db.notification.create({
    data: {
      userId: application.studentId,
      type: stage === "OFFER" ? "success" : stage === "REJECTED" ? "warning" : "info",
      title: stageLabels[stage] ?? "Application update",
      body: `Your application for "${application.job.title}" moved to: ${stage}.`,
      link: "/dashboard/student/jobs",
    },
  });

  return json({ ok: true, stage });
}
